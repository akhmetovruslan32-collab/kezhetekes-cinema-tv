(function () {
    'use strict';
    var style = document.getElementById('cinema-tv-controls');
    if (!style) {
        style = document.createElement('style'); style.id = 'cinema-tv-controls';
        style.textContent = '.vjs-control-bar,.vjs-big-play-button,.vjs-text-track-settings{display:none!important} body{background:#000!important}';
        document.head.appendChild(style);
    }
    function video() { return document.querySelector('video'); }
    function player() { return window.player || (window.videojs && video() && window.videojs.getPlayer(video().id)); }
    function bind() { var v = video(); if (v) { v.controls = false; v.removeAttribute('controls'); } }
    bind();
    if (!window.cinemaTvObserver) { window.cinemaTvObserver = new MutationObserver(bind); window.cinemaTvObserver.observe(document.body, {childList:true, subtree:true}); }
    if (window.videojs && videojs.Vhs) { videojs.Vhs.GOAL_BUFFER_LENGTH = 60; videojs.Vhs.MAX_GOAL_BUFFER_LENGTH = 120; }
    var selectedQuality = 0;
    function levels() { var p = player(); return p && p.qualityLevels ? Array.from(p.qualityLevels()) : []; }
    function qualities() { return Array.from(new Set(levels().map(function (l) { return l.height; }).filter(function (h) { return h > 0; }))).sort(function (a,b) { return b-a; }); }
    function quality(height) {
        var list = levels();
        if (height > 0 && !list.some(function (l) { return l.height === height; })) return false;
        selectedQuality = height;
        list.forEach(function (l) { l.enabled = height === 0 || l.height === height; });
        return true;
    }
    function trackList(kind) {
        var p = player(), v = video();
        var list = kind === 'audio' ? (p && p.audioTracks ? p.audioTracks() : v && v.audioTracks) : (p && p.textTracks ? p.textTracks() : v && v.textTracks);
        return list ? Array.from(list) : [];
    }
    window.CinemaTV = {
        qualities: qualities, quality: quality,
        tracks: function (kind) { return trackList(kind).map(function (t, i) { return {index:i, label:t.label || t.language || ('Дорожка ' + (i+1)), kind:t.kind || ''}; }).filter(function (t) { return kind === 'audio' || t.kind === 'captions' || t.kind === 'subtitles'; }); },
        track: function (kind, index) { trackList(kind).forEach(function (t, i) { if (kind === 'audio') t.enabled = i === index; else if (t.kind === 'captions' || t.kind === 'subtitles') t.mode = i === index ? 'showing' : 'disabled'; }); },
        speed: function (rate) { var v=video(); if (v) v.playbackRate = rate; }
    };
    var p = player();
    if (p && p.on) { p.on('loadedmetadata', function () { bind(); if (selectedQuality) quality(selectedQuality); }); }
})();
