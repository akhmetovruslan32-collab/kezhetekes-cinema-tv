package org.jellyfin.androidtv

import android.content.Context
import java.io.File

/** Local diagnostic copy. Keeps the existing crash reporter as the final handler. */
object CinemaCrashDiagnostics {
	private fun report(context: Context) = File(context.filesDir, "cinema-last-crash.txt")

	fun install(context: Context) {
		val previous = Thread.getDefaultUncaughtExceptionHandler()
		Thread.setDefaultUncaughtExceptionHandler { thread, failure ->
			try {
				val stack = failure.stackTraceToString()
					.replace(Regex("(?i)(token|password|api[_-]?key|authorization)([=:\\s]+)[^\\s&,]+"), "$1$2[hidden]")
				report(context).writeText("CINEMA ${BuildConfig.VERSION_NAME}\nAndroid ${android.os.Build.VERSION.RELEASE}\n${android.os.Build.MODEL}\n\n${stack.take(24_000)}")
			} catch (_: Exception) { /* Never interfere with the original crash handler. */ }
			previous?.uncaughtException(thread, failure)
		}
	}

	fun read(context: Context): String? = try {
		report(context).takeIf { it.exists() }?.readText()?.take(24_000)
	} catch (_: Exception) { null }

	fun clear(context: Context) { report(context).delete() }
}
