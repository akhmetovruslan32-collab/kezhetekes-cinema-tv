package org.jellyfin.androidtv.ui.home

import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.FocusDirection
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import org.jellyfin.androidtv.ui.browsing.MainActivity

internal fun Modifier.cinemaSidebarNavigation(): Modifier = composed {
    val activity = LocalContext.current as? MainActivity
    val focus = LocalFocusManager.current
    onPreviewKeyEvent { event ->
        if (activity != null && event.type == KeyEventType.KeyDown && event.key in listOf(Key.DirectionLeft, Key.DirectionDown, Key.DirectionUp)) {
            when (event.key) {
                Key.DirectionLeft -> if (!focus.moveFocus(FocusDirection.Left)) activity.openCinemaSidebar()
                Key.DirectionDown -> focus.moveFocus(FocusDirection.Down)
                Key.DirectionUp -> focus.moveFocus(FocusDirection.Up)
            }
            true
        } else false
    }
}
