package org.jellyfin.androidtv.ui.background

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.MutableStateFlow
import org.jellyfin.androidtv.data.service.BackgroundService
import org.jellyfin.androidtv.ui.browsing.MainActivity
import org.koin.compose.koinInject

object CinemaBackgroundState { val headerVisible = MutableStateFlow(false) }

@Composable
fun AppBackground() {
    val service = koinInject<BackgroundService>()
    val image by service.currentBackground.collectAsState()
    val headerVisible by CinemaBackgroundState.headerVisible.collectAsState()
    val activity = LocalContext.current
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (activity is MainActivity && headerVisible) {
            Box(Modifier.fillMaxWidth().height(370.dp)) {
                Crossfade(image, label = "cinema-detail-header") { frame ->
                    if (frame != null) Image(frame, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                }
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .35f), Color.Black.copy(alpha = .75f), Color.Black))))
            }
        }
    }
}
