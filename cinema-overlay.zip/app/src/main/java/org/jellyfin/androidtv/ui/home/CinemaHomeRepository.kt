package org.jellyfin.androidtv.ui.home

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.first
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemRepository
import org.jellyfin.androidtv.data.repository.UserViewsRepository
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.api.client.extensions.libraryApi
import org.jellyfin.sdk.api.client.extensions.userViewsApi
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import org.jellyfin.sdk.model.api.ItemFilter
import org.jellyfin.sdk.model.api.ItemSortBy
import org.jellyfin.sdk.model.api.MediaType
import org.jellyfin.sdk.model.api.SortOrder

data class CinemaRow(
	val key: String,
	val title: String,
	val items: List<BaseItemDto>,
	val landscape: Boolean = false,
	val ranked: Boolean = false,
)

data class CinemaHomeData(
	val hero: List<BaseItemDto>,
	val rows: List<CinemaRow>,
	val libraries: List<BaseItemDto>,
	val partialFailure: Boolean,
)

class CinemaHomeRepository(private val api: ApiClient, private val views: UserViewsRepository) {
	suspend fun load(context: Context): CinemaHomeData = coroutineScope {
		val kinds = setOf(BaseItemKind.MOVIE, BaseItemKind.SERIES)
		val fields = ItemRepository.browseFields
		val libraries = async { api.userViewsApi.getUserViews().content.items.filter { views.isSupported(it.collectionType) || it.name?.contains("youtube", ignoreCase = true) == true } }
		val recent = async {
			api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
				sortBy = setOf(ItemSortBy.DATE_CREATED), sortOrder = setOf(SortOrder.DESCENDING), limit = 48).content.items
		}
		val resume = async { optional {
			api.itemsApi.getResumeItems(mediaTypes = setOf(MediaType.VIDEO), fields = fields, limit = 24).content.items
		} }
		val favorites = async { optional {
			api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
				filters = setOf(ItemFilter.IS_FAVORITE), limit = 24).content.items
		} }
		val watched = async { optional {
			api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
				isPlayed = true, sortBy = setOf(ItemSortBy.DATE_PLAYED), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
		} }
		val top = async { optional {
			api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
				sortBy = setOf(ItemSortBy.COMMUNITY_RATING), sortOrder = setOf(SortOrder.DESCENDING), limit = 10).content.items
		} }
		val newReleases = async { optional {
			api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
				sortBy = setOf(ItemSortBy.PREMIERE_DATE), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
		} }
		val latestItems = recent.await()
		val optionalResults = listOf(resume.await(), favorites.await(), watched.await(), top.await(), newReleases.await())
		val rows = mutableListOf<CinemaRow>()
		fun row(key: String, title: Int, result: Result<List<BaseItemDto>>, landscape: Boolean = false, ranked: Boolean = false) {
			val items = result.getOrDefault(emptyList())
			if (items.isNotEmpty()) rows += CinemaRow(key, context.getString(title), items, landscape, ranked)
		}
		row("resume", R.string.lbl_continue_watching, optionalResults[0], landscape = true)
		row("favorites", R.string.cinema_my_list, optionalResults[1])
		row("new", R.string.cinema_new_releases, optionalResults[4])
		row("again", R.string.cinema_watch_again, optionalResults[2])
		var partialFailure = optionalResults.any { it.isFailure }
		val lastWatched = optionalResults[2].getOrNull()?.firstOrNull()
		if (lastWatched != null) {
			val similar = optional { api.libraryApi.getSimilarItems(itemId = lastWatched.id, fields = fields, limit = 24).content.items }
			partialFailure = partialFailure || similar.isFailure
			similar.getOrNull()?.takeIf { it.isNotEmpty() }?.let {
				rows += CinemaRow("because", context.getString(R.string.because_you_watched, lastWatched.name.orEmpty()), it)
			}
		}
		row("top", R.string.cinema_top_rated, optionalResults[3], ranked = true)
		for (genre in latestItems.flatMap { it.genres.orEmpty() }.distinct().take(4)) {
			val result = optional {
				api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
					genres = setOf(genre), sortBy = setOf(ItemSortBy.COMMUNITY_RATING), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
			}
			partialFailure = partialFailure || result.isFailure
			result.getOrNull()?.takeIf { it.isNotEmpty() }?.let { rows += CinemaRow("genre-$genre", genre, it) }
		}
		if (latestItems.isNotEmpty()) rows += CinemaRow("latest", context.getString(R.string.cinema_recently_added), latestItems.take(24))
		CinemaHomeData(latestItems.filter { !it.backdropImageTags.isNullOrEmpty() }.ifEmpty { latestItems }.take(6), rows, libraries.await(), partialFailure)
	}

	private suspend fun optional(block: suspend () -> List<BaseItemDto>): Result<List<BaseItemDto>> = try {
		Result.success(block())
	} catch (error: CancellationException) {
		throw error
	} catch (error: Exception) {
		Result.failure(error)
	}
}
