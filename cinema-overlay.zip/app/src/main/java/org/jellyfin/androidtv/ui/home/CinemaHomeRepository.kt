package org.jellyfin.androidtv.ui.home

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemRepository
import org.jellyfin.androidtv.data.repository.UserViewsRepository
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.api.client.extensions.libraryApi
import org.jellyfin.sdk.api.client.extensions.userViewsApi
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import org.jellyfin.sdk.model.api.ItemFilter
import org.jellyfin.sdk.model.api.ItemSortBy
import org.jellyfin.sdk.model.api.MediaType
import org.jellyfin.sdk.model.api.SortOrder

data class CinemaRow(
	val key: String,
	val title: String,
	val items: List<BaseItemDto>,
	val landscape: Boolean = false,
	val ranked: Boolean = false,
)

data class CinemaHomeData(
	val hero: List<BaseItemDto>,
	val rows: List<CinemaRow>,
	val libraries: List<BaseItemDto>,
	val partialFailure: Boolean,
)

class CinemaHomeRepository(private val api: ApiClient, private val views: UserViewsRepository) {
	suspend fun load(context: Context): CinemaHomeData = withContext(Dispatchers.IO) {
		val kinds = setOf(BaseItemKind.MOVIE, BaseItemKind.SERIES)
		val fields = ItemRepository.browseFields
		val libraries = api.userViewsApi.getUserViews().content.items.filter { views.isSupported(it.collectionType) || it.name?.contains("youtube", ignoreCase = true) == true }
        val cinemaLibraries = libraries.filter { it.collectionType in setOf(org.jellyfin.sdk.model.api.CollectionType.MOVIES, org.jellyfin.sdk.model.api.CollectionType.TVSHOWS) && !it.name.orEmpty().contains("youtube", true) }
		val recent = async {
			cinemaLibraries.map { library -> async {
                api.itemsApi.getItems(parentId = library.id, includeItemTypes = kinds, recursive = true, fields = fields,
                    sortBy = setOf(ItemSortBy.DATE_CREATED), sortOrder = setOf(SortOrder.DESCENDING), limit = 48).content.items
            } }.flatMap { it.await() }.distinctBy { it.id }.sortedByDescending { it.dateCreated }.take(48)
		}
		val resume = async { optional {
			api.itemsApi.getResumeItems(mediaTypes = setOf(MediaType.VIDEO), fields = fields, limit = 24).content.items
		} }
		val watched = async { optional {
			api.itemsApi.getItems(includeItemTypes = kinds, recursive = true, fields = fields,
				isPlayed = true, sortBy = setOf(ItemSortBy.DATE_PLAYED), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
		} }
		val latestItems = recent.await()
        val resumeItems = resume.await()
        val watchedItems = watched.await()
        var partialFailure = resumeItems.isFailure || watchedItems.isFailure
        val rows = mutableListOf(
            CinemaRow("resume", "Продолжить просмотр", resumeItems.getOrDefault(emptyList()), landscape = true),
            CinemaRow("latest", "Недавно добавленные", latestItems.take(24)),
            CinemaRow("again", "Посмотреть снова", watchedItems.getOrDefault(emptyList()))
        )
        val genres = listOf(
            "Фантастика" to setOf("Фантастика", "Science Fiction", "Sci-Fi", "Sci-Fi & Fantasy"),
            "Приключения" to setOf("Приключения", "Adventure", "Action & Adventure"),
            "Триллеры" to setOf("Триллер", "Триллеры", "Thriller"),
            "Мелодрамы" to setOf("Мелодрама", "Мелодрамы", "Romance"),
            "Комедии" to setOf("Комедия", "Комедии", "Comedy")
        )
        for ((label, aliases) in genres) {
            val result = optional { kotlinx.coroutines.supervisorScope {
                cinemaLibraries.map { library -> async {
                    api.itemsApi.getItems(parentId = library.id, includeItemTypes = kinds, recursive = true, fields = fields,
                        genres = aliases, sortBy = setOf(ItemSortBy.COMMUNITY_RATING), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
                } }.flatMap { it.await() }.distinctBy { it.id }.sortedByDescending { it.communityRating }.take(24)
            } }
            partialFailure = partialFailure || result.isFailure
            rows += CinemaRow("genre-$label", label, result.getOrDefault(emptyList()))
        }
        CinemaHomeData(latestItems.filter { !it.backdropImageTags.isNullOrEmpty() }.ifEmpty { latestItems }.take(6), rows, libraries, partialFailure)
	}

	private suspend fun optional(block: suspend () -> List<BaseItemDto>): Result<List<BaseItemDto>> = try {
		Result.success(block())
	} catch (error: CancellationException) {
		throw error
	} catch (error: Exception) {
		Result.failure(error)
	}
}
