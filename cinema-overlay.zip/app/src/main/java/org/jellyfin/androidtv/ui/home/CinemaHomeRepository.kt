package org.jellyfin.androidtv.ui.home

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemRepository
import org.jellyfin.androidtv.data.repository.UserViewsRepository
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.liveTvApi
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.api.client.extensions.libraryApi
import org.jellyfin.sdk.api.client.extensions.userViewsApi
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import org.jellyfin.sdk.model.api.ItemFilter
import org.jellyfin.sdk.model.api.ItemSortBy
import org.jellyfin.sdk.model.api.MediaType
import org.jellyfin.sdk.model.api.SortOrder

data class CinemaRow(
	val key: String,
	val title: String,
	val items: List<BaseItemDto>,
	val landscape: Boolean = false,
	val ranked: Boolean = false,
    val youtube: List<org.json.JSONObject> = emptyList(),
)

data class CinemaHomeData(
	val hero: List<BaseItemDto>,
	val rows: List<CinemaRow>,
	val libraries: List<BaseItemDto>,
	val partialFailure: Boolean,
    val youtubeUrl: String? = null,
)

class CinemaHomeRepository(private val api: ApiClient, private val views: UserViewsRepository) {
	suspend fun load(context: Context): CinemaHomeData = withContext(Dispatchers.IO) {
		val kinds = setOf(BaseItemKind.MOVIE, BaseItemKind.SERIES)
		val fields = ItemRepository.browseFields
		val libraries = api.userViewsApi.getUserViews().content.items.filter { views.isSupported(it.collectionType) || it.name?.contains("youtube", ignoreCase = true) == true }
        val cinemaLibraries = libraries.filter { it.collectionType in setOf(org.jellyfin.sdk.model.api.CollectionType.MOVIES, org.jellyfin.sdk.model.api.CollectionType.TVSHOWS) && !it.name.orEmpty().contains("youtube", true) }
		val recent = async {
			cinemaLibraries.map { library -> async {
                api.itemsApi.getItems(parentId = library.id, includeItemTypes = kinds, recursive = true, fields = fields,
                    sortBy = setOf(ItemSortBy.DATE_CREATED), sortOrder = setOf(SortOrder.DESCENDING), limit = 48).content.items
            } }.flatMap { it.await() }.filter { it.type in kinds }.distinctBy { it.id }.sortedByDescending { it.dateCreated }.take(48)
		}
		val resume = async { optional { kotlinx.coroutines.supervisorScope {
            cinemaLibraries.map { library -> async { api.itemsApi.getResumeItems(parentId = library.id, mediaTypes = setOf(MediaType.VIDEO), fields = fields, limit = 24).content.items } }
                .flatMap { it.await() }.filter { it.type in setOf(BaseItemKind.MOVIE, BaseItemKind.SERIES, BaseItemKind.EPISODE) }.distinctBy { it.id }.take(24)
        } } }
        val watched = async { optional { kotlinx.coroutines.supervisorScope {
            cinemaLibraries.map { library -> async {
                api.itemsApi.getItems(parentId = library.id, includeItemTypes = kinds, recursive = true, fields = fields,
                    isPlayed = true, sortBy = setOf(ItemSortBy.DATE_PLAYED), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
            } }.flatMap { it.await() }.distinctBy { it.id }.take(24)
        } } }

		val latestItems = recent.await()
        val resumeItems = resume.await()
        val watchedItems = watched.await()
        var partialFailure = resumeItems.isFailure || watchedItems.isFailure
        val rows = mutableListOf(
            CinemaRow("resume", "Продолжить просмотр", resumeItems.getOrDefault(emptyList()), landscape = true),
            CinemaRow("latest", "Недавно добавленные", latestItems.take(24)),
            CinemaRow("again", "Посмотреть снова", watchedItems.getOrDefault(emptyList()))
        )
        val genres = listOf(
            "Фантастика" to setOf("Фантастика", "Science Fiction", "Sci-Fi", "Sci-Fi & Fantasy"),
            "Приключения" to setOf("Приключения", "Adventure", "Action & Adventure"),
            "Триллеры" to setOf("Триллер", "Триллеры", "Thriller"),
            "Мелодрамы" to setOf("Мелодрама", "Мелодрамы", "Romance"),
            "Комедии" to setOf("Комедия", "Комедии", "Comedy")
        )
        for ((label, aliases) in genres) {
            val result = optional { kotlinx.coroutines.supervisorScope {
                cinemaLibraries.map { library -> async {
                    api.itemsApi.getItems(parentId = library.id, includeItemTypes = kinds, recursive = true, fields = fields,
                        genres = aliases, sortBy = setOf(ItemSortBy.COMMUNITY_RATING), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
                } }.flatMap { it.await() }.distinctBy { it.id }.sortedByDescending { it.communityRating }.take(24)
            } }
            partialFailure = partialFailure || result.isFailure
            rows += CinemaRow("genre-$label", label, result.getOrDefault(emptyList()))
        }
        CinemaHomeData(latestItems.filter { !it.backdropImageTags.isNullOrEmpty() }.ifEmpty { latestItems }.take(6), rows.filter { it.items.isNotEmpty() || it.youtube.isNotEmpty() }, libraries, partialFailure)
	}

    // Load optional services after the cinema screen is already visible.
    suspend fun loadUpdates(data: CinemaHomeData): CinemaHomeData = withContext(Dispatchers.IO) {
        val fields = ItemRepository.browseFields
        val cinemaLibraries = data.libraries.filter { it.collectionType == org.jellyfin.sdk.model.api.CollectionType.TVSHOWS }
        val episodes = async { optional { kotlinx.coroutines.supervisorScope {
            cinemaLibraries.filter { it.collectionType == org.jellyfin.sdk.model.api.CollectionType.TVSHOWS }.map { library -> async {
                api.itemsApi.getItems(parentId = library.id, includeItemTypes = setOf(BaseItemKind.EPISODE), recursive = true, fields = fields,
                    sortBy = setOf(ItemSortBy.DATE_CREATED), sortOrder = setOf(SortOrder.DESCENDING), limit = 24).content.items
            } }.flatMap { it.await() }.distinctBy { it.id }.sortedByDescending { it.dateCreated }.take(24)
        } } }
        val television = async { optional { api.liveTvApi.getLiveTvChannels(limit = 24, addCurrentProgram = true).content.items } }
        val youtube = async {
            try {
                val bridge = CinemaYouTubeApi(api.baseUrl.orEmpty(), api.accessToken.orEmpty())
                val videos = bridge.get("ForYou").youtubeItems().filter { it.text("videoId").isNotBlank() }
                    .distinctBy { it.text("videoId") }.sortedByDescending { it.optLong("published", 0) }.take(24)
                val url = try { (bridge.get("Config") as org.json.JSONObject).text("publicUrl", "PublicUrl") }
                    catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { null }
                videos to url
            } catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { emptyList<org.json.JSONObject>() to null }
        }

        val newEpisodes = episodes.await().getOrDefault(emptyList())
        val channels = television.await().getOrDefault(emptyList()).map { channel ->
            channel.copy(name = channel.currentProgram?.name?.let { "${channel.name} · $it" } ?: channel.name)
        }
        val (newVideos, youtubeUrl) = youtube.await()
        val updates = listOf(
            CinemaRow("new-episodes", "Новые серии", newEpisodes, landscape = true),
            CinemaRow("on-air", "Сейчас в эфире", channels, landscape = true),
            CinemaRow("new-youtube", "Новое в подписках YouTube", emptyList(), landscape = true, youtube = newVideos)
        ).filter { it.items.isNotEmpty() || it.youtube.isNotEmpty() }
        val original = data.rows.filter { it.key !in setOf("new-episodes", "on-air", "new-youtube") }
        val split = original.indexOfFirst { it.key == "latest" }.let { if (it < 0) 0 else it + 1 }
        data.copy(rows = original.take(split) + updates + original.drop(split), youtubeUrl = youtubeUrl)
    }

	private suspend fun optional(block: suspend () -> List<BaseItemDto>): Result<List<BaseItemDto>> = try {
		Result.success(block())
	} catch (error: CancellationException) {
		throw error
	} catch (error: Exception) {
		Result.failure(error)
	}
}
