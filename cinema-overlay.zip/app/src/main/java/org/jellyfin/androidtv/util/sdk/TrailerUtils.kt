package org.jellyfin.androidtv.util.sdk

import android.content.Context
import android.content.Intent
import androidx.core.net.toUri
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.androidtv.ui.home.CinemaCatalogApi
import org.jellyfin.androidtv.ui.home.entries
import kotlinx.coroutines.CancellationException

object TrailerUtils {
	suspend fun getRussianTrailerIntent(api: ApiClient, item: BaseItemDto): Intent {
		val tmdb = item.providerIds?.entries?.firstOrNull { it.key.equals("Tmdb", true) }?.value?.toIntOrNull()
		if (tmdb != null && api.baseUrl != null && api.accessToken != null) try {
			val details = CinemaCatalogApi(api.baseUrl!!, api.accessToken!!).get("details/${if (item.type == BaseItemKind.SERIES) "tv" else "movie"}/$tmdb")
			val videos = details.optJSONObject("videos")?.entries("results").orEmpty() + details.entries("relatedVideos")
			val candidates = videos.filter { it.optString("site").equals("YouTube", true) && it.optString("type").equals("Trailer", true) && (it.optString("iso_639_1") == "ru" || it.optString("language") == "ru") }
			val chosen = candidates.firstOrNull { it.optBoolean("official") } ?: candidates.firstOrNull()
			val key = chosen?.optString("key")
			if (key != null && key.matches(Regex("[A-Za-z0-9_-]{11}"))) return getExternalTrailerIntent("https://www.youtube.com/watch?v=$key")
		} catch (failure: CancellationException) { throw failure } catch (_: Exception) { }
		val query = java.net.URLEncoder.encode("${item.name.orEmpty()} ${item.productionYear ?: ""} официальный трейлер на русском", "UTF-8")
		return Intent(Intent.ACTION_VIEW, "https://www.youtube.com/results?search_query=$query".toUri())
	}
	private const val YOUTUBE_HOST = "youtube.com"
	private const val YOUTUBE_ID_PARAMETER = "v"
	private const val YOUTUBE_URL = "https://youtube.com/watch?v="
	private const val YOUTUBE_ID_LENGTH = 11
	private const val FRAMEWORK_STUB_PACKAGE = "com.android.tv.frameworkpackagestubs"

	@JvmStatic
	fun getExternalTrailerIntent(src: String): Intent {
		val uri = src.toUri()

		// Recreate YouTube urls
		if (uri.host?.endsWith(YOUTUBE_HOST) == true) {
			val id = uri.getQueryParameter(YOUTUBE_ID_PARAMETER).orEmpty()
			if (id.length == YOUTUBE_ID_LENGTH) return Intent(Intent.ACTION_VIEW, "$YOUTUBE_URL$id".toUri())
		}

		return Intent(Intent.ACTION_VIEW, uri)
	}

	@JvmStatic
	fun getExternalTrailerIntent(context: Context, item: BaseItemDto): Intent? = item.remoteTrailers.orEmpty()
		.mapNotNull { it.url?.let(::getExternalTrailerIntent) }
		.firstOrNull {
			val component = it.resolveActivity(context.packageManager)

			// Check if there is an activity to handle the intent
			// exclude the FrameworkPackageStubs module, which only displays a message
			// that there is no app to open the intent
			component != null && component.packageName != FRAMEWORK_STUB_PACKAGE
		}

	@JvmStatic
	fun hasPlayableTrailers(context: Context, item: BaseItemDto): Boolean {
		// Local trailer
		if (item.localTrailerCount != null && item.localTrailerCount!! > 0) return true

		// External trailer
		if (getExternalTrailerIntent(context, item) != null) return true

		// No trailer found
		return false
	}
}
