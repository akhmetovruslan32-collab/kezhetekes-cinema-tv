package org.jellyfin.androidtv.ui.home

import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.ImageView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import org.jellyfin.androidtv.ui.browsing.MainActivity
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.json.JSONObject

@Composable
internal fun CinemaNativeYouTubeRow(items: List<JSONObject>, rowKey: String, screen: CinemaScreenState,
    publicUrl: String?, onVertical: (Boolean) -> Unit, onClick: (JSONObject) -> Unit) {
    val vertical by rememberUpdatedState(onVertical)
    val click by rememberUpdatedState(onClick)
    AndroidView(modifier = Modifier.fillMaxWidth().height(230.dp), factory = { context ->
        val grid = HorizontalGridView(context).apply {
            setNumRows(1)
            val density = resources.displayMetrics.density
            setPadding((28*density).toInt(), (18*density).toInt(), (28*density).toInt(), (18*density).toInt())
            setHorizontalSpacing((24*density).toInt()); clipChildren = false; clipToPadding = false
            setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ITEM)
            windowAlignment = BaseGridView.WINDOW_ALIGN_BOTH_EDGE
        }
        val presenter = object : Presenter() {
            override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(LegacyImageCardView(parent.context, true).apply {
                isFocusable = true; isFocusableInTouchMode = true
                cardType = BaseCardView.CARD_TYPE_INFO_UNDER; infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS
            })
            override fun onBindViewHolder(holder: ViewHolder, item: Any?) {
                val entry = item as JSONObject
                val card = holder.view as LegacyImageCardView
                card.setMainImageDimensions(240, 135, ImageView.ScaleType.CENTER_CROP)
                card.setTitleText(entry.text("title", "author")); card.setContentText(entry.text("author"))
                val id = entry.text("videoId")
                card.mainImageView.load(url = publicUrl?.takeIf { it.isNotBlank() }?.let { "${it.trimEnd('/')}/vi/$id/mqdefault.jpg" } ?: "https://i.ytimg.com/vi/$id/mqdefault.jpg")
                card.setOnClickListener {
                    screen.focusedHomeRow = rowKey; screen.focusedHomeItem = id
                    screen.nativeRowPositions[rowKey] = items.indexOf(entry); screen.restoreHomeFocus = true
                    click(entry)
                }
                card.setOnKeyListener { _, key, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) false else when (key) {
                        KeyEvent.KEYCODE_DPAD_DOWN -> { vertical(true); true }
                        KeyEvent.KEYCODE_DPAD_UP -> { vertical(false); true }
                        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            if (event.repeatCount == 0) {
                                val index = items.indexOf(entry)
                                if (key == KeyEvent.KEYCODE_DPAD_LEFT && index == 0) (context as? MainActivity)?.openCinemaSidebar()
                                else grid.setSelectedPosition((index + if (key == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1).coerceIn(0, items.lastIndex))
                            }; true
                        }
                        else -> false
                    }
                }
            }
            override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null); holder.view.setOnKeyListener(null) }
        }
        val objects = ArrayObjectAdapter(presenter).apply { addAll(0, items) }
        val bridge = ItemBridgeAdapter(objects)
        FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
        grid.adapter = bridge
        grid.setOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
            override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                if (grid.hasFocus() && position in items.indices) { screen.nativeRowPositions[rowKey] = position; screen.focusedHomeRow = rowKey; screen.focusedHomeItem = items[position].text("videoId") }
            }
        })
        grid.setSelectedPosition(screen.nativeRowPositions[rowKey] ?: 0)
        grid
    }, update = { grid ->
        if (screen.pendingHomeRow == rowKey || (screen.restoreHomeFocus && screen.focusedHomeRow == rowKey)) {
            val position = if (screen.restoreHomeFocus) screen.nativeRowPositions[rowKey] ?: 0 else 0
            screen.pendingHomeRow = null; screen.restoreHomeFocus = false
            grid.setSelectedPosition(position)
            grid.post { grid.requestFocus() }
        }
    })
}
