package org.jellyfin.androidtv.ui.home

import android.view.ViewGroup
import android.widget.ImageView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.json.JSONObject

@Composable
internal fun CinemaNativeYouTubeRow(items: List<JSONObject>, rowKey: String, screen: CinemaScreenState,
    publicUrl: String?, onVertical: (Boolean) -> Unit, onClick: (JSONObject) -> Unit) {
    val vertical by rememberUpdatedState(onVertical)
    val click by rememberUpdatedState(onClick)
    val client = org.koin.compose.koinInject<org.jellyfin.sdk.api.client.ApiClient>()
    val context = androidx.compose.ui.platform.LocalContext.current
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    var watched by remember { mutableStateOf(emptySet<String>()) }
    var refresh by remember { mutableIntStateOf(0) }
    DisposableEffect(lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event -> if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) refresh++ }
        lifecycle.addObserver(observer); onDispose { lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(items, refresh) {
        try { watched = CinemaYouTubeApi(client.baseUrl.orEmpty(), client.accessToken.orEmpty()).watched(items) }
        catch (cancel: kotlinx.coroutines.CancellationException) { throw cancel }
        catch (_: Exception) { }
    }
    val currentWatched by rememberUpdatedState(watched)
    val objectsHolder = remember { arrayOfNulls<ArrayObjectAdapter>(1) }
    AndroidView(modifier = Modifier.fillMaxWidth().height(230.dp), factory = { context ->
        val grid = HorizontalGridView(context).apply {
            setNumRows(1)
            val density = resources.displayMetrics.density
            setPadding((28*density).toInt(), (18*density).toInt(), (28*density).toInt(), (18*density).toInt())
            setHorizontalSpacing((24*density).toInt()); clipChildren = false; clipToPadding = false
            setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ALIGNED)
            windowAlignment = BaseGridView.WINDOW_ALIGN_BOTH_EDGE
        }
        val presenter = object : Presenter() {
            override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(LegacyImageCardView(parent.context, true).apply {
                useCinemaTransparentInfo()
                isFocusable = true; isFocusableInTouchMode = true
                cardType = BaseCardView.CARD_TYPE_INFO_UNDER; infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS
            })
            override fun onBindViewHolder(holder: ViewHolder, item: Any?) {
                val entry = item as JSONObject
                val card = holder.view as LegacyImageCardView
                card.setMainImageDimensions(240, 135, ImageView.ScaleType.CENTER_CROP)
                card.setTitleText(entry.text("title", "author")); card.setContentText(entry.text("author"))
                val id = entry.text("videoId")
                card.mainImageView.roundCinemaYouTubeImage()
                card.setUnwatchedCount(if (id in currentWatched) 0 else -1)
                card.mainImageView.load(url = publicUrl?.takeIf { it.isNotBlank() }?.let { "${it.trimEnd('/')}/vi/$id/mqdefault.jpg" } ?: "https://i.ytimg.com/vi/$id/mqdefault.jpg")
                card.setOnClickListener {
                    screen.focusedHomeRow = rowKey; screen.focusedHomeItem = id
                    screen.nativeRowPositions[rowKey] = items.indexOf(entry); screen.restoreHomeFocus = true
                    click(entry)
                }

            }
            override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null); holder.view.setOnKeyListener(null) }
        }
        val objects = ArrayObjectAdapter(presenter).apply { addAll(0, items) }
        objectsHolder[0] = objects
        val bridge = ItemBridgeAdapter(objects)
        FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
        grid.installCinemaShelfKeys({ vertical(false) }, { vertical(true) })
        grid.adapter = bridge
        grid.setOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
            override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                if (grid.hasFocus() && position in items.indices) { screen.nativeRowPositions[rowKey] = position; screen.focusedHomeRow = rowKey; screen.focusedHomeItem = items[position].text("videoId") }
            }
        })
        grid.setSelectedPosition(screen.nativeRowPositions[rowKey] ?: 0)
        grid
    }, update = { grid ->
        if (grid.getTag(org.jellyfin.androidtv.R.id.cinema_watch_marks) != watched) {
            grid.setTag(org.jellyfin.androidtv.R.id.cinema_watch_marks, watched)
            objectsHolder[0]?.notifyArrayItemRangeChanged(0, items.size)
        }
        if (screen.pendingHomeRow == rowKey || (screen.restoreHomeFocus && screen.focusedHomeRow == rowKey)) {
            val position = if (screen.restoreHomeFocus) screen.nativeRowPositions[rowKey] ?: 0 else 0
            screen.pendingHomeRow = null; screen.restoreHomeFocus = false
            grid.focusCinemaItem(position)
        }
    })
}
