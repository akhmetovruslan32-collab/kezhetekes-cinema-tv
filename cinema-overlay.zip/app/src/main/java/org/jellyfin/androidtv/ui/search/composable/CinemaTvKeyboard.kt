package org.jellyfin.androidtv.ui.search.composable

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Compact D-pad keyboard for TVs whose Remote IME suppresses the local keyboard. */
internal fun cinemaTvKeyboard(context: Context, initial: String, onChange: (String) -> Unit, onSubmit: () -> Unit, onDismiss: () -> Unit): Dialog {
    val dialog = Dialog(context)
    dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
    val density = context.resources.displayMetrics.density
    fun dp(value: Int) = (value * density).toInt()
    val width = minOf(dp(570), (context.resources.displayMetrics.widthPixels * .9f).toInt())
    val root = LinearLayout(context).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
        background = GradientDrawable().apply { setColor(Color.rgb(8, 8, 8)); cornerRadius = dp(12).toFloat() }
    }
    var value = initial
    var layout = 0
    val title = TextView(context).apply { text = "Поиск"; textSize = 16f; setTextColor(Color.LTGRAY); setPadding(dp(4), 0, 0, dp(8)) }
    val display = TextView(context).apply {
        textSize = 20f; setTextColor(Color.WHITE); isSingleLine = true
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(10), 0, dp(10), 0)
        background = GradientDrawable().apply { setColor(Color.rgb(30, 30, 30)); cornerRadius = dp(6).toFloat() }
    }
    fun update() { display.text = if (value.isEmpty()) "Введите запрос…" else "$value│"; onChange(value) }
    root.addView(title)
    root.addView(display, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(10) })
    val keys = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
    root.addView(keys)
    val actions = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
    root.addView(actions)
    fun button(label: String, action: () -> Unit) = TextView(context).apply {
        id = View.generateViewId(); text = label; textSize = 18f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE)
        isFocusable = true; isFocusableInTouchMode = true; isClickable = true
        background = GradientDrawable().apply { setColor(Color.rgb(28, 28, 28)); cornerRadius = dp(5).toFloat() }
        setOnFocusChangeListener { _, focused -> setTextColor(if (focused) Color.rgb(226, 182, 91) else Color.WHITE) }
        setOnClickListener { action() }
    }
    val actionButtons = mutableListOf<TextView>()
    var keyRows = listOf<List<TextView>>()
    fun linkRows() {
        val all = keyRows + listOf(actionButtons.toList())
        all.forEachIndexed { r, row -> row.forEachIndexed { c, key ->
            key.nextFocusLeftId = row[(c - 1).coerceAtLeast(0)].id
            key.nextFocusRightId = row[(c + 1).coerceAtMost(row.lastIndex)].id
            key.nextFocusUpId = if (r == 0) key.id else all[r - 1][c.coerceAtMost(all[r - 1].lastIndex)].id
            key.nextFocusDownId = if (r == all.lastIndex) key.id else all[r + 1][c.coerceAtMost(all[r + 1].lastIndex)].id
        } }
    }
    fun renderKeys() {
        keys.removeAllViews()
        val chars = when (layout) { 0 -> "ЙЦУКЕНГШЩЗХФЫВАПРОЛДЖЭЯЧСМИТЬБЮЁЪ"; 1 -> "QWERTYUIOPASDFGHJKLZXCVBNM"; else -> "1234567890.,!?-:()/+@" }
        title.text = "Поиск · ${when (layout) { 0 -> "Русская раскладка"; 1 -> "Английская раскладка"; else -> "Цифры и знаки" }}"
        val rows = mutableListOf<List<TextView>>()
        chars.chunked(11).forEach { letters ->
            val line = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            val row = letters.map { letter -> button(letter.toString()) { value += letter.lowercaseChar(); update() }.also {
                line.addView(it, LinearLayout.LayoutParams((width - dp(28)) / 11 - dp(4), dp(36)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
            } }
            keys.addView(line); rows += row
        }
        keyRows = rows
        linkRows()
    }
    listOf<Pair<String, () -> Unit>>(
        "РУ/EN/123" to { layout = (layout + 1) % 3; renderKeys() },
        "Пробел" to { value += " "; update() },
        "⌫" to { value = value.dropLast(1); update() },
        "Очистить" to { value = ""; update() },
        "Найти" to { onSubmit(); dialog.dismiss() }
    ).forEach { (label, action) ->
        val key = button(label, action)
        actionButtons += key
        actions.addView(key, LinearLayout.LayoutParams(0, dp(40), if (label == "⌫") .65f else 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
    }
    renderKeys(); display.text = if (value.isEmpty()) "Введите запрос…" else "$value│"
    dialog.setContentView(root)
    dialog.setOnDismissListener { onDismiss() }
    dialog.setOnShowListener {
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)
            attributes = attributes.apply { y = dp(16); dimAmount = .35f }
            addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        }
        keyRows.firstOrNull()?.firstOrNull()?.requestFocus()
    }
    return dialog
}
