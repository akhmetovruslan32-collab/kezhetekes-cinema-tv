package org.jellyfin.androidtv.ui.home

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import org.jellyfin.sdk.api.client.util.AuthorizationHeaderBuilder
import org.jellyfin.androidtv.BuildConfig

/** Uses the same SeerrFin bridge as this installation's web client, with the TV user's Jellyfin session. */
class CinemaCatalogApi(private val server: String, private val token: String) {
	suspend fun get(path: String): JSONObject = call(path)
	suspend fun request(type: String, id: Int, option: JSONObject, seasons: List<Int>): JSONObject {
		val body = JSONObject().put("MediaType", type).put("MediaId", id).put("Is4k", option.optBoolean("is4k", option.optBoolean("Is4k")))
		for (key in listOf("ServerId", "ProfileId", "RootFolder")) {
			val lower = key.replaceFirstChar { it.lowercase() }
			val value = option.opt(key) ?: option.opt(lower)
			if (value != null && value != JSONObject.NULL) body.put(key, value)
		}
		if (type == "tv") body.put("Seasons", org.json.JSONArray(seasons))
		val result = call("request", body)
		check(result.optJSONArray("errors")?.length()?.let { it > 0 } != true)
		check(!(result.has("message") && !result.has("id")))
		return result
	}
	private suspend fun call(path: String, body: JSONObject? = null): JSONObject = withContext(Dispatchers.IO) {
		require(token.isNotBlank())
		val base = server.trim().trimEnd('/').let { if (it.startsWith("http://") || it.startsWith("https://")) it else "http://$it" }
		val connection = URL("$base/SeerrFin/$path").openConnection() as HttpURLConnection
		try {
			connection.connectTimeout = 15_000
			connection.readTimeout = 20_000
			connection.instanceFollowRedirects = false
			connection.setRequestProperty("X-Emby-Token", token)
			connection.setRequestProperty("Authorization", AuthorizationHeaderBuilder.buildHeader(
				clientName = "Kezhetekes Cinema", clientVersion = BuildConfig.VERSION_NAME,
				deviceId = "cinema-tv", deviceName = android.os.Build.MODEL, accessToken = token,
			))
			connection.setRequestProperty("Accept", "application/json")
			if (body != null) {
				connection.requestMethod = "POST"
				connection.doOutput = true
				connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
				connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
			}
			check(connection.responseCode in 200..299) {
				when (connection.responseCode) {
					401 -> "HTTP 401: сервер не принял вход. Выйдите и войдите в CINEMA повторно."
					403 -> "HTTP 403: каталог запрещён для этого пользователя."
					404 -> "HTTP 404: SeerrFin не найден на выбранном сервере Jellyfin."
					else -> "HTTP ${connection.responseCode}: сервер каталога вернул ошибку."
				}
			}
			val bytes = connection.inputStream.use { input ->
				val output = java.io.ByteArrayOutputStream()
				val buffer = ByteArray(8192)
				while (true) {
					val count = input.read(buffer)
					if (count < 0) break
					check(output.size() + count <= 4 * 1024 * 1024)
					output.write(buffer, 0, count)
				}
				output.toByteArray()
			}
			JSONObject(bytes.toString(Charsets.UTF_8))
		} finally { connection.disconnect() }
	}
}

internal fun JSONObject.text(vararg names: String): String = names.firstNotNullOfOrNull { name ->
	optString(name).takeIf { it.isNotBlank() && it != "null" }
}.orEmpty()

internal fun JSONObject.entries(vararg names: String): List<JSONObject> {
	val array = names.firstNotNullOfOrNull { optJSONArray(it) } ?: return emptyList()
	return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
}
