package org.jellyfin.androidtv.ui.base

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

fun colorScheme(): ColorScheme = ColorScheme(
	background = Color(0xFF080B0F),
	onBackground = Color(0xFFFFFFFF),
	button = Color(0xFF303847),
	onButton = Color(0xFFF5F7FA),
	buttonFocused = Color(0xFFE2B65B),
	onButtonFocused = Color(0xFF080B0F),
	buttonDisabled = Color(0xFF252B35),
	onButtonDisabled = Color(0xFFABB3C0),
	buttonActive = Color(0x4DE2B65B),
	onButtonActive = Color(0xFFE2B65B),
	input = Color(0xFF384252),
	onInput = Color(0xFFF5F7FA),
	inputFocused = Color(0xFFE2B65B),
	onInputFocused = Color(0xFF080B0F),
	recording = Color(0xB3FF7474),
	onRecording = Color(0xFFF5F7FA),
	popover = Color(0xF0181C24),
)

@Immutable
data class ColorScheme(
	val background: Color,
	val onBackground: Color,

	val button: Color,
	val onButton: Color,
	val buttonFocused: Color,
	val onButtonFocused: Color,
	val buttonDisabled: Color,
	val onButtonDisabled: Color,
	val buttonActive: Color,
	val onButtonActive: Color,

	val input: Color,
	val onInput: Color,
	val inputFocused: Color,
	val onInputFocused: Color,

	val recording: Color,
	val onRecording: Color,

	val popover: Color,
)

val LocalColorScheme = staticCompositionLocalOf { colorScheme() }
