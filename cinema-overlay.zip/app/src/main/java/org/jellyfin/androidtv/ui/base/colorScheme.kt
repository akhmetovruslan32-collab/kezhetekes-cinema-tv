package org.jellyfin.androidtv.ui.base

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

fun colorScheme(): ColorScheme = ColorScheme(
	background = Color(0xFF000000),
	onBackground = Color(0xFFFFFFFF),
	button = Color(0xFF252525),
	onButton = Color(0xFFF5F7FA),
	buttonFocused = Color(0xFF252525),
	onButtonFocused = Color(0xFFE2B65B),
	buttonDisabled = Color(0xFF191919),
	onButtonDisabled = Color(0xFFABB3C0),
	buttonActive = Color(0xFF252525),
	onButtonActive = Color.White,
	input = Color(0xFF252525),
	onInput = Color(0xFFF5F7FA),
	inputFocused = Color(0xFF252525),
	onInputFocused = Color.White,
	recording = Color(0xB3FF7474),
	onRecording = Color(0xFFF5F7FA),
	popover = Color(0xFA111111),
)

@Immutable
data class ColorScheme(
	val background: Color,
	val onBackground: Color,

	val button: Color,
	val onButton: Color,
	val buttonFocused: Color,
	val onButtonFocused: Color,
	val buttonDisabled: Color,
	val onButtonDisabled: Color,
	val buttonActive: Color,
	val onButtonActive: Color,

	val input: Color,
	val onInput: Color,
	val inputFocused: Color,
	val onInputFocused: Color,

	val recording: Color,
	val onRecording: Color,

	val popover: Color,
)

val LocalColorScheme = staticCompositionLocalOf { colorScheme() }
