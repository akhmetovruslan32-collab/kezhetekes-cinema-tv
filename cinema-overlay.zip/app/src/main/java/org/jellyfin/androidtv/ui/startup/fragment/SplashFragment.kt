package org.jellyfin.androidtv.ui.startup.fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import android.media.MediaPlayer
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.layout.ContentScale
import org.jellyfin.androidtv.ui.base.Text
import androidx.fragment.app.Fragment
import androidx.fragment.compose.content
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.base.JellyfinTheme

@Composable
fun SplashScreen() {
    val context = LocalContext.current
    var revealed by remember { mutableStateOf(false) }
    val logoAlpha by animateFloatAsState(if (revealed) 1f else 0f, tween(1000), label = "cinema-logo-reveal")
    val scale by animateFloatAsState(if (revealed) 1f else .85f, tween(1000), label = "cinema-logo-scale")
    DisposableEffect(context) {
        val sound = MediaPlayer.create(context, R.raw.cinema_hooves)
        sound?.start()
        onDispose { sound?.release() }
    }
    LaunchedEffect(Unit) { delay(1100); revealed = true }
	Box(
		modifier = Modifier.fillMaxSize().background(colorResource(id = R.color.cinema_background)),
	) {
		Column(
			horizontalAlignment = Alignment.CenterHorizontally,
			verticalArrangement = Arrangement.Center,
			modifier = Modifier.fillMaxSize().graphicsLayer { alpha = logoAlpha; scaleX = scale; scaleY = scale },
		) {
			Image(
				painter = painterResource(R.drawable.cinema_goat),
				contentDescription = stringResource(R.string.app_name),
				contentScale = ContentScale.Fit,
				modifier = Modifier
					.width(210.dp)
					.height(200.dp)
			)
			Text(stringResource(R.string.cinema_brand), fontSize = 34.sp, color = colorResource(R.color.cinema_gold))
			Text(stringResource(R.string.cinema_subtitle), fontSize = 20.sp, letterSpacing = 8.sp, color = colorResource(R.color.cinema_gold))
		}
	}
}

class SplashFragment : Fragment() {
	override fun onCreateView(
		inflater: LayoutInflater,
		container: ViewGroup?,
		savedInstanceState: Bundle?
	) = content {
		JellyfinTheme {
			SplashScreen()
		}
	}
}
