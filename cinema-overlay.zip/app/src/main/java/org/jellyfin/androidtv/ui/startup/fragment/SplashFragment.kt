package org.jellyfin.androidtv.ui.startup.fragment

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.Fragment
import androidx.fragment.compose.content
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.base.JellyfinTheme

/** Completion comes from the supplied film, rather than a timer that cuts off its ending. */
internal object CinemaIntroPlayback {
    val completed = MutableStateFlow(false)
}

@Composable
fun SplashScreen() {
    var failed by remember { mutableStateOf(false) }
    var video by remember { mutableStateOf<VideoView?>(null) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> video?.pause()
                Lifecycle.Event.ON_RESUME -> if (!CinemaIntroPlayback.completed.value) video?.start()
                else -> Unit
            }
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer); video?.stopPlayback(); video = null }
    }
    if (failed) {
        Image(painterResource(R.drawable.cinema_goat), "КӘҖӘТӘКӘС CINEMA",
            Modifier.fillMaxSize().background(Color.Black), contentScale = ContentScale.Fit)
    } else AndroidView(modifier = Modifier.fillMaxSize().background(Color.Black), factory = { context ->
        FrameLayout(context).apply {
            setBackgroundColor(android.graphics.Color.BLACK)
            // VideoView measures its original aspect ratio inside these bounds: no cropping.
            val player = VideoView(context).apply {
                isFocusable = false; isFocusableInTouchMode = false
                setOnPreparedListener { media ->
                    media.isLooping = false
                    if (lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) start()
                }
                setOnCompletionListener { CinemaIntroPlayback.completed.value = true }
                setOnErrorListener { _, _, _ ->
                    failed = true; CinemaIntroPlayback.completed.value = true; true
                }
                setVideoURI(Uri.parse("android.resource://${context.packageName}/${R.raw.cinema_intro}"))
            }
            addView(player, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
            video = player
        }
    })
}

class SplashFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) = content { JellyfinTheme { SplashScreen() } }
}
