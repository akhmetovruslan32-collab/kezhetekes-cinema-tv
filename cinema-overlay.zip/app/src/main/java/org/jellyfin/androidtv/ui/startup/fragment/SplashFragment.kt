package org.jellyfin.androidtv.ui.startup.fragment

import android.media.MediaPlayer
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.fragment.app.Fragment
import androidx.fragment.compose.content
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.base.JellyfinTheme
import org.jellyfin.androidtv.ui.base.Text
import kotlin.math.sin
import kotlin.random.Random

private data class Spark(val x: Float, val y: Float, val radius: Float, val phase: Float)

/** Original emblem and separate typography, composed without cropping. */
@Composable
fun SplashScreen() {
    val context = LocalContext.current
    val time = remember { Animatable(0f) }
    val sparks = remember { val random = Random(17); List(64) { Spark(random.nextFloat(), random.nextFloat(), .7f + random.nextFloat() * 1.5f, random.nextFloat() * 6.28f) } }
    LaunchedEffect(Unit) { time.animateTo(1f, tween(6800, easing = LinearEasing)) }
    DisposableEffect(context) {
        val sound = MediaPlayer.create(context, R.raw.cinema_hooves)
        sound?.start()
        onDispose { sound?.release() }
    }
    val t = time.value
    val reveal = ((t - .12f) / .36f).coerceIn(0f, 1f)
    val textAlpha = ((t - .58f) / .18f).coerceIn(0f, 1f)
    val gold = Color(0xFFE2B65B)
    BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
        val logoHeight = minOf(maxHeight * .51f, 275.dp)
        Canvas(Modifier.fillMaxSize()) {
            sparks.forEach { spark ->
                val shimmer = (.5f + .5f * sin(t * 12f + spark.phase)) * reveal * .45f
                val y = spark.y - t * .07f
                drawCircle(gold.copy(alpha = shimmer), spark.radius * density, Offset(spark.x * size.width, (if (y < 0) y + 1 else y) * size.height))
            }
        }
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.cinema_goat), stringResource(R.string.app_name),
                Modifier.width(logoHeight * 1.1f).height(logoHeight)
                    .graphicsLayer { alpha = reveal; compositingStrategy = CompositingStrategy.Offscreen }
                    .drawWithContent {
                        drawContent()
                        val sweep = ((t - .30f) / .38f).coerceIn(0f, 1f) * size.width * 2 - size.width * .5f
                        val strength = if (t in .30f.. .68f) .30f else 0f
                        drawRect(Brush.linearGradient(listOf(Color.Transparent, Color.White.copy(alpha = strength), Color.Transparent), Offset(sweep - size.width * .2f, 0f), Offset(sweep + size.width * .2f, size.height)), blendMode = BlendMode.SrcAtop)
                    }, contentScale = ContentScale.Fit)
            Spacer(Modifier.height(28.dp))
            Text(stringResource(R.string.cinema_brand), Modifier.graphicsLayer { alpha = textAlpha }, color = gold, fontSize = 32.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Text(stringResource(R.string.cinema_subtitle), Modifier.graphicsLayer { alpha = textAlpha }, color = gold, fontSize = 19.sp, letterSpacing = 7.sp)
        }
    }
}

class SplashFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) = content { JellyfinTheme { SplashScreen() } }
}
