package org.jellyfin.androidtv.ui.startup.fragment

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import androidx.fragment.app.Fragment
import androidx.fragment.compose.content
import kotlinx.coroutines.flow.MutableStateFlow
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.base.JellyfinTheme

internal object CinemaIntroPlayback {
    val completed = MutableStateFlow(false)
}

/** The animation ends before its generated lettering appears. Preserve its full 16:9 frame. */
@Composable
fun SplashScreen() {
    AndroidView(
        modifier = Modifier.fillMaxSize().background(Color.Black),
        factory = { context ->
            FrameLayout(context).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                addView(VideoView(context).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    setOnPreparedListener { player ->
                        player.isLooping = false
                        player.setVideoScalingMode(android.media.MediaPlayer.VIDEO_SCALING_MODE_SCALE_TO_FIT)
                        start()
                    }
                    setOnCompletionListener { CinemaIntroPlayback.completed.value = true }
                    setOnErrorListener { _, _, _ -> CinemaIntroPlayback.completed.value = true; true }
                    setVideoURI(Uri.parse("android.resource://${context.packageName}/${R.raw.cinema_intro}"))
                }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, android.view.Gravity.CENTER))
            }
        },
        onRelease = { frame -> (frame.getChildAt(0) as? VideoView)?.stopPlayback() },
    )
}

class SplashFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?) = content { JellyfinTheme { SplashScreen() } }
}
