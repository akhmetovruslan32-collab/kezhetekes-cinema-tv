package org.jellyfin.androidtv.ui.home

import android.view.KeyEvent
import androidx.leanback.widget.BaseGridView
import androidx.leanback.widget.ViewHolderTask
import androidx.recyclerview.widget.RecyclerView
import org.jellyfin.androidtv.ui.browsing.MainActivity

/** Complete focus transfer after the target item has actually been laid out. */
internal fun BaseGridView.focusCinemaItem(position: Int) {
    setSelectedPosition(position, object : ViewHolderTask {
        override fun run(holder: RecyclerView.ViewHolder) { if (this@focusCinemaItem.selectedPosition == position) holder.itemView.requestFocus() }
    })
}

internal fun BaseGridView.installCinemaGridKeys(columns: Int, onTop: () -> Unit, onBottom: () -> Unit = {}) {
    setOnKeyInterceptListener { event ->
        val key = event.keyCode
        if (key !in listOf(KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN)) false
        else {
            if (event.action == KeyEvent.ACTION_DOWN) {
                val size = adapter?.itemCount ?: 0
                val index = selectedPosition.coerceIn(0, (size - 1).coerceAtLeast(0))
                when (key) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (index % columns == 0) {
                        if (event.repeatCount == 0) (context as? MainActivity)?.openCinemaSidebar()
                    } else focusCinemaItem(index - 1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> if (index % columns != columns - 1 && index + 1 < size) focusCinemaItem(index + 1)
                    KeyEvent.KEYCODE_DPAD_UP -> if (index < columns) {
                        if (event.repeatCount == 0) post { clearFocus(); onTop() }
                    } else focusCinemaItem(index - columns)
                    KeyEvent.KEYCODE_DPAD_DOWN -> if ((index / columns + 1) * columns < size) focusCinemaItem((index + columns).coerceAtMost(size - 1)) else onBottom()
                }
            }
            true
        }
    }
}
