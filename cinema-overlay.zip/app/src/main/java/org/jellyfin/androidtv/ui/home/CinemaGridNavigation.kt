package org.jellyfin.androidtv.ui.home

import android.view.KeyEvent
import android.view.View
import androidx.leanback.widget.BaseGridView
import androidx.leanback.widget.ViewHolderTask
import androidx.recyclerview.widget.RecyclerView
import org.jellyfin.androidtv.ui.browsing.MainActivity

/** Complete focus transfer after the target item has actually been laid out. */
internal fun BaseGridView.focusCinemaItem(position: Int) {
    // Leanback executes attached-holder tasks before changing its selected position.
    setSelectedPosition(position)
    setSelectedPosition(position, object : ViewHolderTask {
        override fun run(holder: RecyclerView.ViewHolder) { if (this@focusCinemaItem.selectedPosition == position) holder.itemView.requestFocus() }
    })
}

/** Scroll beyond the attached viewport before handing focus to the new card. */
internal fun BaseGridView.focusCinemaScrollableItem(position: Int) {
    if (position !in 0 until (adapter?.itemCount ?: 0)) return
    val targetId = org.jellyfin.androidtv.R.id.cinema_grid_target
    setTag(targetId, position)
    // Keep the adjacent viewport prepared so a remote press can cross its boundary.
    if (extraLayoutSpace == 0) setExtraLayoutSpace(maxOf(width, height, (480 * resources.displayMetrics.density).toInt()))
    setSelectedPositionSmooth(position, object : ViewHolderTask {
        override fun run(holder: RecyclerView.ViewHolder) {
            if (getTag(targetId) == position && holder.itemView.requestFocus()) setTag(targetId, null)
        }
    })
}

internal fun BaseGridView.cinemaNavigationPosition(): Int =
    getTag(org.jellyfin.androidtv.R.id.cinema_grid_target) as? Int ?: selectedPosition

internal fun BaseGridView.installCinemaGridKeys(columns: Int, onTop: () -> Unit, onBottom: () -> Unit = {}) {
    val handler: (KeyEvent) -> Boolean = { event ->
        val key = event.keyCode
        if (key !in listOf(KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN)) false
        else {
            if (event.action == KeyEvent.ACTION_DOWN) {
                val size = adapter?.itemCount ?: 0
                // Selection includes a pending offscreen move; the old attached holder can lag behind it.
                val index = cinemaNavigationPosition().coerceIn(0, (size - 1).coerceAtLeast(0))
                when (key) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (index % columns == 0) {
                        if (event.repeatCount == 0) (context as? MainActivity)?.openCinemaSidebar()
                    } else focusCinemaScrollableItem(index - 1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> if (index % columns != columns - 1 && index + 1 < size) focusCinemaScrollableItem(index + 1)
                    KeyEvent.KEYCODE_DPAD_UP -> if (index < columns) {
                        if (event.repeatCount == 0) post { clearFocus(); onTop() }
                    } else focusCinemaScrollableItem(index - columns)
                    KeyEvent.KEYCODE_DPAD_DOWN -> if ((index / columns + 1) * columns < size) focusCinemaScrollableItem((index + columns).coerceAtMost(size - 1)) else onBottom()
                }
            }
            true
        }
    }
    setTag(org.jellyfin.androidtv.R.id.cinema_grid_key_handler, handler)
    setOnKeyInterceptListener { handler(it) }
}

/** Deliver native-grid keys before Compose's automatic focus traversal. */
internal fun View.dispatchCinemaGridKey(event: KeyEvent): Boolean {
    val grid = generateSequence(this) { it.parent as? View }.filterIsInstance<BaseGridView>().firstOrNull() ?: return false
    @Suppress("UNCHECKED_CAST")
    val handler = grid.getTag(org.jellyfin.androidtv.R.id.cinema_grid_key_handler) as? ((KeyEvent) -> Boolean)
    return handler?.invoke(event) ?: false
}
