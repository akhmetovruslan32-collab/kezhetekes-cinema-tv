package org.jellyfin.androidtv.ui.home

import android.view.KeyEvent
import android.view.View
import androidx.leanback.widget.BaseGridView
import androidx.leanback.widget.ViewHolderTask
import androidx.recyclerview.widget.RecyclerView
import org.jellyfin.androidtv.ui.browsing.MainActivity

/** Complete focus transfer after the target item has actually been laid out. */
internal fun BaseGridView.focusCinemaItem(position: Int) {
    // Leanback executes attached-holder tasks before changing its selected position.
    setSelectedPosition(position)
    setSelectedPosition(position, object : ViewHolderTask {
        override fun run(holder: RecyclerView.ViewHolder) { if (this@focusCinemaItem.selectedPosition == position) holder.itemView.requestFocus() }
    })
}

internal fun BaseGridView.installCinemaGridKeys(columns: Int, onTop: () -> Unit, onBottom: () -> Unit = {}) {
    val handler: (KeyEvent) -> Boolean = { event ->
        val key = event.keyCode
        if (key !in listOf(KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN)) false
        else {
            if (event.action == KeyEvent.ACTION_DOWN) {
                val size = adapter?.itemCount ?: 0
                val focused = findFocus()?.let { findContainingViewHolder(it)?.bindingAdapterPosition }?.takeIf { it >= 0 }
                val index = (focused ?: selectedPosition).coerceIn(0, (size - 1).coerceAtLeast(0))
                when (key) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> if (index % columns == 0) {
                        if (event.repeatCount == 0) (context as? MainActivity)?.openCinemaSidebar()
                    } else focusCinemaItem(index - 1)
                    KeyEvent.KEYCODE_DPAD_RIGHT -> if (index % columns != columns - 1 && index + 1 < size) focusCinemaItem(index + 1)
                    KeyEvent.KEYCODE_DPAD_UP -> if (index < columns) {
                        if (event.repeatCount == 0) post { clearFocus(); onTop() }
                    } else focusCinemaItem(index - columns)
                    KeyEvent.KEYCODE_DPAD_DOWN -> if ((index / columns + 1) * columns < size) focusCinemaItem((index + columns).coerceAtMost(size - 1)) else onBottom()
                }
            }
            true
        }
    }
    setTag(org.jellyfin.androidtv.R.id.cinema_grid_key_handler, handler)
    setOnKeyInterceptListener { handler(it) }
}

/** Deliver native-grid keys before Compose's automatic focus traversal. */
internal fun View.dispatchCinemaGridKey(event: KeyEvent): Boolean {
    val grid = generateSequence(this) { it.parent as? View }.filterIsInstance<BaseGridView>().firstOrNull() ?: return false
    @Suppress("UNCHECKED_CAST")
    val handler = grid.getTag(org.jellyfin.androidtv.R.id.cinema_grid_key_handler) as? ((KeyEvent) -> Boolean)
    return handler?.invoke(event) ?: false
}
