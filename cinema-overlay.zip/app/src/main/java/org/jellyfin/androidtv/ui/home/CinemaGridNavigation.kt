package org.jellyfin.androidtv.ui.home

import android.view.KeyEvent
import android.view.View
import androidx.leanback.widget.BaseGridView
import androidx.leanback.widget.ViewHolderTask
import androidx.recyclerview.widget.RecyclerView
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.browsing.MainActivity

/** Only for entering/restoring a row. Arrow repeats must use Leanback's own focus search. */
internal fun BaseGridView.focusCinemaItem(position: Int) {
    if (position !in 0 until (adapter?.itemCount ?: 0)) return
    stopScroll()
    val ticket = Any()
    setTag(R.id.cinema_grid_target, ticket)
    setSelectedPosition(position, object : ViewHolderTask {
        override fun run(holder: RecyclerView.ViewHolder) {
            if (getTag(R.id.cinema_grid_target) === ticket && holder.itemView.isAttachedToWindow) {
                holder.itemView.requestFocus()
                setTag(R.id.cinema_grid_target, null)
            }
        }
    })
}

/** Use the item that actually owns focus, not a scroll destination queued off screen. */
private fun BaseGridView.focusedCinemaPosition(): Int = findFocus()?.let { findContainingViewHolder(it)?.bindingAdapterPosition }
    ?.takeIf { it != RecyclerView.NO_POSITION } ?: selectedPosition.coerceAtLeast(0)

/** Horizontal rows use the same native key/focus path as ListRowPresenter's actor rows. */
internal fun BaseGridView.installCinemaShelfKeys(onTop: () -> Unit, onBottom: () -> Unit) {
    val handler: (KeyEvent) -> Boolean = { event ->
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> if (focusedCinemaPosition() == 0) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) (context as? MainActivity)?.openCinemaSidebar()
                true
            } else false
            KeyEvent.KEYCODE_DPAD_RIGHT -> focusedCinemaPosition() >= (adapter?.itemCount ?: 0) - 1
            KeyEvent.KEYCODE_DPAD_UP -> { if (event.action == KeyEvent.ACTION_DOWN) onTop(); true }
            KeyEvent.KEYCODE_DPAD_DOWN -> { if (event.action == KeyEvent.ACTION_DOWN) onBottom(); true }
            else -> false
        }
    }
    setTag(R.id.cinema_grid_key_handler, handler)
    setOnKeyInterceptListener { handler(it) }
}

/** Guard section boundaries; movement between cards is owned by GridLayoutManager. */
internal fun BaseGridView.installCinemaGridKeys(columns: Int, onTop: () -> Unit, onBottom: () -> Unit = {}) {
    val handler: (KeyEvent) -> Boolean = { event ->
        val size = adapter?.itemCount ?: 0
        val index = focusedCinemaPosition()
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> if (index % columns == 0) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) (context as? MainActivity)?.openCinemaSidebar()
                true
            } else false
            KeyEvent.KEYCODE_DPAD_RIGHT -> index % columns == columns - 1 || index + 1 >= size
            KeyEvent.KEYCODE_DPAD_UP -> if (index < columns) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) onTop()
                true
            } else false
            KeyEvent.KEYCODE_DPAD_DOWN -> if ((index / columns + 1) * columns >= size) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) onBottom()
                true
            } else false
            else -> false
        }
    }
    setTag(R.id.cinema_grid_key_handler, handler)
    setOnKeyInterceptListener { handler(it) }
}

/**
 * Give embedded native rows the ViewRoot focus-search path before Compose can move focus
 * into a different AndroidView. No selected-position commands or per-key holder tasks.
 */
internal fun View.dispatchCinemaGridKey(event: KeyEvent): Boolean {
    val grid = generateSequence(this) { it.parent as? View }.filterIsInstance<BaseGridView>().firstOrNull() ?: return false
    @Suppress("UNCHECKED_CAST")
    val boundary = grid.getTag(R.id.cinema_grid_key_handler) as? ((KeyEvent) -> Boolean) ?: return false
    val direction = when (event.keyCode) {
        KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> View.FOCUS_RIGHT
        KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
        KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
        else -> return false
    }
    // A key from the user supersedes a delayed restore request.
    if (event.action == KeyEvent.ACTION_DOWN) grid.setTag(R.id.cinema_grid_target, null)
    if (boundary(event)) return true
    if (!grid.dispatchKeyEvent(event) && event.action == KeyEvent.ACTION_DOWN) {
        val focused = grid.findFocus()
        if (focused != null) {
            val next = grid.focusSearch(focused, direction)
            if (next != null && next !== grid && next !== focused &&
                generateSequence(next) { it.parent as? View }.any { it === grid }) next.requestFocus(direction)
        }
    }
    return true
}
