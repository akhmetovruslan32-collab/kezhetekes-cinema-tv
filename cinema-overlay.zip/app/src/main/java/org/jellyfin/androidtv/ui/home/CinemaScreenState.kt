package org.jellyfin.androidtv.ui.home

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.*
import androidx.lifecycle.ViewModel
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.ItemSortBy

/** Owned by the retained HomeFragment, so opening details does not reset its lists. */
class CinemaScreenState : ViewModel() {
    var data by mutableStateOf<CinemaHomeData?>(null)
    var activeLibrary by mutableStateOf<BaseItemDto?>(null)
    var catalog by mutableStateOf(false)
    var searchOnOpen by mutableStateOf(false)
    var sectionApplied by mutableStateOf(false)
    val homeScroll = LazyListState()
    val rowScrolls = mutableMapOf<String, LazyListState>()
    var focusedHomeItem by mutableStateOf<String?>(null)
    var focusedHomeRow by mutableStateOf<String?>(null)
    var restoreHomeFocus by mutableStateOf(false)
    var heroSelected by mutableIntStateOf(0)
    var heroMuted by mutableStateOf(true)
    val catalogState = CinemaCatalogState()
    val libraries = mutableMapOf<String, CinemaLibraryState>()
}

class CinemaLibraryState(library: BaseItemDto) {
    var stack by mutableStateOf(listOf(library))
    var sort by mutableStateOf(ItemSortBy.SORT_NAME)
    var filter by mutableIntStateOf(0)
    val pages = mutableMapOf<String, CinemaLibraryPage>()
}

class CinemaLibraryPage {
    var entries by mutableStateOf<List<BaseItemDto>>(emptyList())
    var total by mutableIntStateOf(0)
    var nextOffset = 0
    val scroll = LazyGridState()
    var focusedId by mutableStateOf<String?>(null)
    var restoreFocus by mutableStateOf(false)
}

class CinemaCatalogState {
    var tab by mutableStateOf("movie")
    val scroll = LazyListState()
    val matchesScroll = LazyListState()
    var searchVisible by mutableStateOf(false)
    var query by mutableStateOf("")
    var submittedQuery by mutableStateOf("")
    var selected by mutableStateOf<org.json.JSONObject?>(null)
    var response by mutableStateOf<org.json.JSONObject?>(null)
    var entries by mutableStateOf<List<org.json.JSONObject>>(emptyList())
    var libraryMatches by mutableStateOf<List<BaseItemDto>>(emptyList())
    var loadedKey: String? = null
    var nextPage = 0
    var hasMore = true
    var focusedId by mutableStateOf<String?>(null)
    var restoreFocus by mutableStateOf(false)
}
