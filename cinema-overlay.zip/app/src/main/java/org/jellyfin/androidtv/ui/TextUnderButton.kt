package org.jellyfin.androidtv.ui

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import androidx.annotation.DrawableRes
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import org.jellyfin.androidtv.databinding.TextUnderButtonBinding
import org.jellyfin.androidtv.util.dp

class TextUnderButton @JvmOverloads constructor(
	context: Context,
	attrs: AttributeSet? = null,
	defStyleAttr: Int = 0,
	defStyleRes: Int = 0,
) : FrameLayout(context, attrs, defStyleAttr, defStyleRes) {
	val binding = TextUnderButtonBinding.inflate(LayoutInflater.from(context), this, true)
	private var baseLabel: String? = null

	init {
		binding.imageButton.background = androidx.core.content.ContextCompat.getDrawable(context, org.jellyfin.androidtv.R.drawable.cinema_detail_button)
        isFocusable = true
		binding.imageButton.imageTintList = android.content.res.ColorStateList(
			arrayOf(intArrayOf(android.R.attr.state_focused), intArrayOf(android.R.attr.state_activated), intArrayOf()),
			intArrayOf(android.graphics.Color.WHITE, android.graphics.Color.WHITE, android.graphics.Color.WHITE))
		isFocusableInTouchMode = true
		descendantFocusability = FOCUS_BLOCK_DESCENDANTS
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) defaultFocusHighlightEnabled = false
	}

	fun setLabel(text: String?) {
		baseLabel = text
		binding.label.isVisible = text != null
		binding.label.text = if (isActivated && text != null) "✓ $text" else text
		binding.label.setTextColor(if (hasFocus()) android.graphics.Color.rgb(226, 182, 91) else android.graphics.Color.WHITE)
		binding.label.alpha = 1f
		binding.imageButton.contentDescription = text
	}

	override fun setActivated(activated: Boolean) {
		super.setActivated(activated)
		binding.label.text = if (activated && baseLabel != null) "✓ $baseLabel" else baseLabel
	}

    override fun onFocusChanged(focused: Boolean, direction: Int, previous: android.graphics.Rect?) {
        super.onFocusChanged(focused, direction, previous)
        binding.label.setTextColor(if (focused) android.graphics.Color.rgb(226, 182, 91) else android.graphics.Color.WHITE)
    }

    fun makePrimary() {
        binding.imageButton.layoutParams = binding.imageButton.layoutParams.apply { width = 120.dp(context); height = 50.dp(context) }
        binding.label.layoutParams = binding.label.layoutParams.apply { width = 130.dp(context) }
        binding.label.textSize = 20f
    }

	fun setIcon(@DrawableRes resource: Int, maxHeight: Int? = null) {
		binding.imageButton.setImageResource(resource)
		binding.imageButton.maxHeight = maxHeight ?: Int.MAX_VALUE
	}

	fun setPadding(padding: Int?) {
		binding.imageButton.setPadding(padding?.dp(context) ?: 0)
	}

	companion object {
		@JvmStatic
		@Suppress("LongParameterList")
		fun create(
			context: Context,
			@DrawableRes icon: Int,
			maxHeight: Int? = null,
			padding: Int? = null,
			label: String? = null,
			onClickListener: OnClickListener
		) = TextUnderButton(context).apply {
			setLabel(label)
			setIcon(icon, maxHeight)
			setPadding(padding)
			setOnClickListener(onClickListener)
		}
	}
}
