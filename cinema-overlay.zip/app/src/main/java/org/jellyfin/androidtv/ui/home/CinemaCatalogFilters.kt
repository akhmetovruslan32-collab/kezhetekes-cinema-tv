package org.jellyfin.androidtv.ui.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.CancellationException
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.search.composable.SearchTextInput
import org.json.JSONObject
import java.net.URLEncoder
import java.net.URLDecoder

private data class FilterChoice(val id: String, val name: String)
private data class FilterPicker(val key: String, val title: String, val options: List<FilterChoice>, val multiple: Boolean = false, val separator: String = "|", val searchKind: String? = null)
private fun List<JSONObject>.filterChoices() = map { FilterChoice(it.text("id", "Id"), it.text("name", "Name")) }.filter { it.id.isNotBlank() }

/** The same combined discovery query and options as the installed SeerrFin web filter. */
@Composable
internal fun CinemaCatalogFilters(api: CinemaCatalogApi, type: String, initial: String?, onClose: () -> Unit, onApply: (String) -> Unit) {
    val values = remember(initial, type) { mutableStateMapOf<String, String>().apply {
        initial.orEmpty().split('&').filter { it.contains('=') }.forEach { pair ->
            val parts = pair.split('=', limit = 2); put(URLDecoder.decode(parts[0], "UTF-8"), URLDecoder.decode(parts[1], "UTF-8"))
        }
    } }
    var options by remember { mutableStateOf<JSONObject?>(null) }
    var providers by remember { mutableStateOf<List<FilterChoice>>(emptyList()) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var picker by remember { mutableStateOf<FilterPicker?>(null) }
    val base = "discover/filter-options/$type"
    LaunchedEffect(api, type, retry) {
        try { options = api.get(base); if (!values.containsKey("watchRegion")) values["watchRegion"] = options?.text("region")?.ifBlank { "RU" } ?: "RU"; error = "" }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { error = "Не удалось загрузить фильтры. Попробуйте ещё раз." }
    }
    val region = values["watchRegion"] ?: "RU"
    LaunchedEffect(region, options, retry) {
        if (options != null) try { providers = api.choices("$base?kind=providers&region=${URLEncoder.encode(region, "UTF-8")}").filterChoices() }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { providers = emptyList(); error = "Не удалось загрузить сервисы выбранного региона." }
    }
    fun choose(key: String, title: String, choices: List<FilterChoice>, multiple: Boolean = false, separator: String = "|", searchKind: String? = null) {
        picker = FilterPicker(key, title, choices, multiple, separator, searchKind)
    }
    val dateKey = if (type == "movie") "primaryReleaseDate" else "firstAirDate"
    val dateSort = if (type == "movie") "release_date" else "first_air_date"
    val titleSort = if (type == "movie") "original_title" else "original_name"
    val sorts = listOf("popularity.desc" to "Популярность: по убыванию", "popularity.asc" to "Популярность: по возрастанию",
        "$dateSort.desc" to "Сначала новые", "$dateSort.asc" to "Сначала старые", "vote_average.desc" to "Рейтинг: по убыванию",
        "vote_average.asc" to "Рейтинг: по возрастанию", "$titleSort.asc" to "Название: А–Я", "$titleSort.desc" to "Название: Я–А").map { FilterChoice(it.first, it.second) }
    fun label(key: String, choices: List<FilterChoice>): String = values[key]?.split('|', ',')?.filter { it.isNotBlank() }?.joinToString(", ") { id -> choices.firstOrNull { it.id == id }?.name ?: id }?.ifBlank { "Любой" } ?: "Любой"
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.width(510.dp).fillMaxHeight(.78f).background(Color(0xFF101010), RoundedCornerShape(20.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Фильтры · ${if (type == "movie") "Фильмы" else "Сериалы"}", fontSize = 23.sp)
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (options == null) item { Text(if (error.isBlank()) "Загрузка…" else error); if (error.isNotBlank()) Button(onClick = { retry++ }) { Text("Повторить") } }
                item { Button(onClick = { choose("sortBy", "Сортировка", sorts) }) { Text("Сортировка: ${sorts.firstOrNull { it.id == (values["sortBy"] ?: "popularity.desc") }?.name}") } }
                item { Text("${if (type == "movie") "Дата выхода" else "Первый эфир"} · ГГГГ-ММ-ДД") }
                item { FilterInput("От", values[dateKey + "Gte"].orEmpty()) { values[dateKey + "Gte"] = it } }
                item { FilterInput("До", values[dateKey + "Lte"].orEmpty()) { values[dateKey + "Lte"] = it } }
                val genres = options?.entries("genres").orEmpty().filterChoices()
                item { Button(onClick = { choose("genre", "Жанры", genres, true, ",") }) { Text("Жанры: ${label("genre", genres)}") } }
                if (type == "movie") item { Button(onClick = { choose("studio", "Студия", emptyList(), searchKind = "company") }) { Text("Студия: ${if (values["studio"].isNullOrBlank()) "Любая" else "Выбрана"}") } }
                else {
                    val statuses = listOf("Продолжается", "Запланирован", "В производстве", "Завершён", "Отменён", "Пилот").mapIndexed { i, name -> FilterChoice(i.toString(), name) }
                    item { Button(onClick = { choose("status", "Статус сериала", statuses, true) }) { Text("Статус: ${label("status", statuses)}") } }
                }
                item { Button(onClick = { choose("keywords", "Ключевые слова", emptyList(), true, ",", "keyword") }) { Text("Ключевые слова: ${values["keywords"]?.split(',')?.size ?: 0}") } }
                item { Button(onClick = { choose("excludeKeywords", "Исключить ключевые слова", emptyList(), true, ",", "keyword") }) { Text("Исключённые слова: ${values["excludeKeywords"]?.split(',')?.size ?: 0}") } }
                val languages = listOf(FilterChoice("", "По умолчанию"), FilterChoice("all", "Все языки")) + options?.entries("languages").orEmpty().filterChoices()
                item { Button(onClick = { choose("language", "Язык оригинала", languages, true) }) { Text("Язык оригинала: ${label("language", languages)}") } }
                val certificates = (if (type == "movie") listOf("NR", "G", "PG", "PG-13", "R", "NC-17") else listOf("NR", "TV-Y", "TV-Y7", "TV-G", "TV-PG", "TV-14", "TV-MA")).map { FilterChoice(it, it) }
                item { Button(onClick = { choose("certification", "Возрастной рейтинг (US)", certificates, true) }) { Text("Возрастной рейтинг: ${label("certification", certificates)}") } }
                listOf("withRuntime" to "Длительность, минут (0–400)", "voteAverage" to "Рейтинг TMDB (1–10)", "voteCount" to "Число оценок TMDB (0–1000)").forEach { (key, title) ->
                    item { Text(title) }
                    item { FilterInput("Минимум", values[key + "Gte"].orEmpty()) { values[key + "Gte"] = it } }
                    item { FilterInput("Максимум", values[key + "Lte"].orEmpty()) { values[key + "Lte"] = it } }
                }
                val regions = options?.entries("regions").orEmpty().filterChoices()
                item { Button(onClick = { choose("watchRegion", "Регион сервисов", regions) }) { Text("Регион сервисов: ${label("watchRegion", regions)}") } }
                item { Button(onClick = { choose("watchProviders", "Стриминговые сервисы", providers, true) }) { Text("Сервисы: ${label("watchProviders", providers)}") } }
                if (error.isNotBlank()) item { Text(error, color = Color(0xFFFFD48A)) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { values.clear(); values["watchRegion"] = options?.text("region")?.ifBlank { "RU" } ?: "RU" }) { Text("Сбросить") }
                Button(enabled = options != null, onClick = {
                    val dates = listOf(values[dateKey + "Gte"], values[dateKey + "Lte"])
                    val ranges = listOf(Triple("withRuntime", 0.0, 400.0), Triple("voteAverage", 1.0, 10.0), Triple("voteCount", 0.0, 1000.0))
                    val valid = dates.all { it.isNullOrBlank() || runCatching { java.time.LocalDate.parse(it); true }.getOrDefault(false) } &&
                        (dates.any { it.isNullOrBlank() } || dates[0]!! <= dates[1]!!) && ranges.all { (key, min, max) ->
                            val low = values[key + "Gte"].orEmpty(); val high = values[key + "Lte"].orEmpty()
                            listOf(low, high).all { it.isBlank() || it.toDoubleOrNull()?.let { n -> n.isFinite() && n in min..max } == true } &&
                                (low.isBlank() || high.isBlank() || (low.toDoubleOrNull() ?: max + 1) <= (high.toDoubleOrNull() ?: min - 1))
                        }
                    if (!valid) error = "Проверьте даты и диапазоны: минимум не должен превышать максимум."
                    else onApply(values.filter { (key, value) -> value.isNotBlank() && !(key == "sortBy" && value == "popularity.desc") && !(key == "watchRegion" && values["watchProviders"].isNullOrBlank()) }
                        .entries.joinToString("&") { "${URLEncoder.encode(it.key, "UTF-8")}=${URLEncoder.encode(it.value, "UTF-8")}" })
                }) { Text("Применить") }
                Button(onClick = onClose) { Text("Закрыть") }
            }
        }
    }
    picker?.let { active ->
        var term by remember(active) { mutableStateOf("") }
        var matches by remember(active) { mutableStateOf(active.options) }
        var lookupError by remember(active) { mutableStateOf(false) }
        LaunchedEffect(term, active) {
            if (active.searchKind == null) matches = active.options.filter { term.isBlank() || it.name.contains(term, true) }
            else if (term.trim().length >= 2) {
                try { matches = api.choices("$base?kind=${active.searchKind}&query=${URLEncoder.encode(term.trim(), "UTF-8")}").filterChoices(); lookupError = false }
                catch (e: CancellationException) { throw e }
                catch (_: Exception) { matches = emptyList(); lookupError = true }
            } else matches = emptyList()
        }
        Dialog(onDismissRequest = { picker = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Column(Modifier.width(460.dp).fillMaxHeight(.72f).background(Color(0xFF151515), RoundedCornerShape(20.dp)).padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(active.title, fontSize = 24.sp)
                SearchTextInput(term, { term = it }, {}, Modifier.fillMaxWidth(), autoOpenOnFocus = false)
                if (lookupError) Text("Не удалось загрузить варианты. Измените запрос и попробуйте снова.")
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(matches) { choice ->
                        val selected = choice.id in values[active.key].orEmpty().split(active.separator)
                        Button(onClick = {
                            if (!active.multiple) { values[active.key] = choice.id; if (active.key == "watchRegion") values.remove("watchProviders"); picker = null }
                            else {
                                val previous = values[active.key].orEmpty().split(active.separator).filter { it.isNotBlank() }.toSet()
                                val next = when { choice.id.isBlank() -> emptySet(); choice.id == "all" -> setOf("all"); selected -> previous - choice.id; previous.size < 20 -> previous - "all" + choice.id; else -> previous }
                                values[active.key] = next.joinToString(active.separator)
                            }
                        }) { Text((if (selected) "✓ " else "") + choice.name) }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { values.remove(active.key) }) { Text("Очистить") }
                    Button(onClick = { picker = null }) { Text("Готово") }
                }
            }
        }
    }
}

@Composable
private fun FilterInput(label: String, value: String, onChange: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(label, modifier = Modifier.width(85.dp))
        SearchTextInput(value, onChange, {}, Modifier.weight(1f), autoOpenOnFocus = false)
    }
}
