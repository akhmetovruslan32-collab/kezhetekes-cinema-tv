package org.jellyfin.androidtv.ui.home

import android.view.LayoutInflater
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.auth.repository.ServerRepository
import org.jellyfin.androidtv.auth.repository.SessionRepository
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.userLibraryApi
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import org.jellyfin.sdk.model.api.ItemSortBy
import org.koin.compose.koinInject

/** Home-only preview. Full media playback continues to use the upstream playback helper. */
@Composable
fun CinemaPreview(item: BaseItemDto, api: ApiClient, paused: Boolean, muted: Boolean, modifier: Modifier = Modifier) {
	val context = LocalContext.current
	val owner = LocalLifecycleOwner.current
	val server = koinInject<ServerRepository>().currentServer.value
	val session = koinInject<SessionRepository>().currentSession.value
	var stream by remember(item.id) { mutableStateOf<String?>(null) }
	var clipStart by remember(item.id) { mutableLongStateOf(0L) }
	LaunchedEffect(item.id, server?.address, session?.accessToken) {
		try {
			delay(1800)
			val preview = withContext(Dispatchers.IO) {
				val trailer = try { api.userLibraryApi.getLocalTrailers(itemId = item.id).content.firstOrNull() }
				catch (failure: CancellationException) { throw failure }
				catch (_: Exception) { null }
				val media = trailer ?: if (item.type == BaseItemKind.SERIES) {
					api.itemsApi.getItems(parentId = item.id, recursive = true,
						includeItemTypes = setOf(BaseItemKind.EPISODE), sortBy = setOf(ItemSortBy.SORT_NAME), limit = 1).content.items.firstOrNull()
				} else item.takeIf { it.type == BaseItemKind.MOVIE || it.type == BaseItemKind.EPISODE }
				media?.let { it to (if (trailer != null) 0L else ((it.runTimeTicks ?: 0L) / 10_000L / 5).coerceIn(0L, 300_000L)) }
			}
			if (preview != null && server != null) {
				val base = server.address.trim().trimEnd('/').let { if (it.startsWith("http://") || it.startsWith("https://")) it else "http://$it" }
				clipStart = preview.second
				stream = "$base/Videos/${preview.first.id}/stream?static=true"
			}
		} catch (error: CancellationException) { throw error }
		catch (_: Exception) { /* Keep the backdrop when no playable local trailer exists. */ }
	}
	val url = stream ?: return
	var ready by remember(url) { mutableStateOf(false) }
	var failed by remember(url) { mutableStateOf(false) }
	var resumed by remember(owner) { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
	val player = remember(url, session?.accessToken) {
		val source = DefaultHttpDataSource.Factory().setDefaultRequestProperties(mapOf("X-Emby-Token" to session?.accessToken.orEmpty()))
		ExoPlayer.Builder(context).setMediaSourceFactory(DefaultMediaSourceFactory(source)).build().apply {
			volume = 0f
			repeatMode = Player.REPEAT_MODE_ONE
			setMediaItem(MediaItem.Builder().setUri(url).setClippingConfiguration(
				MediaItem.ClippingConfiguration.Builder().setStartPositionMs(clipStart).setEndPositionMs(clipStart + 30_000L).build()
			).build())
		}
	}
	DisposableEffect(player, owner) {
		val listener = object : Player.Listener {
			override fun onRenderedFirstFrame() { ready = true }
			override fun onPlayerError(error: PlaybackException) { failed = true; player.stop() }
		}
		val observer = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
		player.addListener(listener)
		owner.lifecycle.addObserver(observer)
		player.prepare()
		onDispose { owner.lifecycle.removeObserver(observer); player.removeListener(listener); player.release() }
	}
	SideEffect { player.volume = if (muted) 0f else 1f; player.playWhenReady = resumed && !paused && !failed }
	AndroidView(
		factory = { LayoutInflater.from(it).inflate(R.layout.cinema_preview, null) as PlayerView },
		modifier = modifier.graphicsLayer { alpha = if (ready && !failed) 1f else 0f },
		update = { it.player = player; it.isFocusable = false; it.isFocusableInTouchMode = false },
	)
}
