package org.jellyfin.androidtv.ui.home

import android.view.LayoutInflater
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.auth.repository.ServerRepository
import org.jellyfin.androidtv.auth.repository.SessionRepository
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.userLibraryApi
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.api.client.extensions.mediaInfoApi
import org.jellyfin.sdk.api.client.extensions.videosApi
import org.jellyfin.sdk.api.client.extensions.hlsSegmentApi
import org.jellyfin.sdk.model.api.PlaybackInfoDto
import org.jellyfin.sdk.model.api.DlnaProfileType
import org.jellyfin.sdk.model.api.EncodingContext
import org.jellyfin.sdk.model.api.MediaStreamProtocol
import org.jellyfin.sdk.model.deviceprofile.buildDeviceProfile
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import org.jellyfin.sdk.model.api.ItemSortBy
import org.koin.compose.koinInject

/** A short fragment of the title itself, using the same direct/remux strategy as the web home. */
@Composable
fun CinemaPreview(item: BaseItemDto, api: ApiClient, paused: Boolean, muted: Boolean, modifier: Modifier = Modifier, onStatus: (String?) -> Unit = {}) {
    val context = LocalContext.current
    val owner = LocalLifecycleOwner.current
    var media by remember(item.id) { mutableStateOf<BaseItemDto?>(null) }
    var attempt by remember(item.id) { mutableIntStateOf(0) }
    LaunchedEffect(item.id) {
        try {
            media = withContext(Dispatchers.IO) {
                val selected = if (item.type == BaseItemKind.SERIES) {
                    api.itemsApi.getItems(parentId = item.id, recursive = true, includeItemTypes = setOf(BaseItemKind.EPISODE),
                        sortBy = setOf(ItemSortBy.SORT_NAME), limit = 1).content.items.firstOrNull()
                } else item.takeIf { it.type == BaseItemKind.MOVIE }
                selected?.let { api.userLibraryApi.getItem(itemId = it.id).content }
            }
        } catch (failure: CancellationException) { throw failure }
        catch (_: Exception) { onStatus("Фрагмент недоступен") }
    }
    val title = media ?: return
    val duration = (title.runTimeTicks ?: 0L) / 10_000L
    val start = if (duration >= 90_000L) duration / 5 else 0L
    val source = title.mediaSources?.firstOrNull()
    val address = api.baseUrl?.trimEnd('/') ?: return
    val token = api.accessToken ?: return
    val parameters = "ApiKey=${java.net.URLEncoder.encode(token, "UTF-8")}" + (source?.id?.let { "&mediaSourceId=${java.net.URLEncoder.encode(it, "UTF-8")}" } ?: "")
    val seek = if (attempt == 2) 0L else start
    val url = if (attempt == 0) "$address/Videos/${title.id}/stream?static=true&$parameters"
        else "$address/Videos/${title.id}/stream.mp4?videoCodec=h264&audioCodec=aac&allowVideoStreamCopy=true&allowAudioStreamCopy=true&startTimeTicks=${seek * 10_000L}&$parameters"
    var ready by remember(item.id, attempt) { mutableStateOf(false) }
    var failed by remember(item.id, attempt) { mutableStateOf(false) }
    var resumed by remember(owner) { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    val player = remember(url) {
        val dataSource = DefaultHttpDataSource.Factory().setDefaultRequestProperties(mapOf("X-Emby-Token" to token))
        ExoPlayer.Builder(context).setMediaSourceFactory(DefaultMediaSourceFactory(dataSource)).build().apply {
            volume = 0f
            repeatMode = Player.REPEAT_MODE_ONE
            val clipStart = if (attempt == 0) start else 0L
            setMediaItem(MediaItem.Builder().setUri(url).setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(clipStart).setEndPositionMs(clipStart + 20_000L).build()
            ).build())
        }
    }
    DisposableEffect(player, owner) {
        val listener = object : Player.Listener {
            override fun onRenderedFirstFrame() { ready = true; onStatus(null) }
            override fun onPlayerError(error: PlaybackException) {
                player.stop()
                if (attempt < 2) attempt++ else { failed = true; onStatus("Фрагмент недоступен") }
            }
        }
        val observer = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
        player.addListener(listener); owner.lifecycle.addObserver(observer); player.prepare()
        onDispose { owner.lifecycle.removeObserver(observer); player.removeListener(listener); player.release() }
    }
    LaunchedEffect(player) {
        delay(6000)
        if (!ready && !failed && resumed && attempt < 2) attempt++
    }
    SideEffect { player.volume = if (muted) 0f else 1f; player.playWhenReady = resumed && !paused && !failed }
    AndroidView(
        factory = { LayoutInflater.from(it).inflate(R.layout.cinema_preview, null) as PlayerView },
        modifier = modifier.graphicsLayer { alpha = if (ready && !failed) 1f else 0f },
        update = { it.player = player; it.isFocusable = false; it.isFocusableInTouchMode = false },
    )
}
