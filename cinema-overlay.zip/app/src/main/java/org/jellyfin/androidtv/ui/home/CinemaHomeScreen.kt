package org.jellyfin.androidtv.ui.home

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemMutationRepository
import org.jellyfin.androidtv.data.repository.UserViewsRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.base.button.ButtonDefaults
import org.jellyfin.androidtv.ui.itemhandling.ItemLauncher
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.ActivityDestinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.util.PlaybackHelper
import org.jellyfin.androidtv.util.apiclient.getUrl
import org.jellyfin.androidtv.util.apiclient.itemBackdropImages
import org.jellyfin.androidtv.util.apiclient.itemImages
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.ImageType
import org.jellyfin.sdk.model.api.CollectionType
import org.jellyfin.sdk.model.api.BaseItemKind
import org.koin.compose.koinInject

private val CinemaBackground = Color(0xFF080B0F)
private val CinemaGold = Color(0xFFE2B65B)

@Composable
fun CinemaHomeScreen() {
	val context = LocalContext.current
	val api = koinInject<ApiClient>()
	val views = koinInject<UserViewsRepository>()
	val navigation = koinInject<NavigationRepository>()
	val repository = remember(api, views) { CinemaHomeRepository(api, views) }
	var data by remember { mutableStateOf<CinemaHomeData?>(null) }
	var failed by remember { mutableStateOf(false) }
	var refresh by remember { mutableIntStateOf(0) }
	var catalog by remember { mutableStateOf(false) }
	var activeLibrary by remember { mutableStateOf<BaseItemDto?>(null) }
	var collections by remember { mutableStateOf(false) }
	LaunchedEffect(repository, refresh) {
		failed = false
		try { data = repository.load(context) }
		catch (error: CancellationException) { throw error }
		catch (_: Exception) { failed = true }
	}
	if (catalog) { CinemaCatalogScreen { catalog = false }; return }
	activeLibrary?.let { selected -> CinemaLibraryScreen(selected, collections) { activeLibrary = null }; return }
	LazyColumn(Modifier.fillMaxSize().background(CinemaBackground), contentPadding = PaddingValues(bottom = 28.dp)) {
		item(key = "navigation") {
			LazyRow(Modifier.fillMaxWidth().padding(horizontal = 28.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
				item { Image(painterResource(R.drawable.cinema_goat), null, Modifier.size(44.dp), contentScale = ContentScale.Fit) }
				item { Button(onClick = { refresh++ }) { Text(stringResource(R.string.lbl_home)) } }
				items(data?.libraries.orEmpty(), key = { it.id }) { library ->
					Button(onClick = {
						if (library.collectionType == CollectionType.LIVETV || library.collectionType == CollectionType.MUSIC || library.collectionType == CollectionType.PHOTOS) ItemLauncher().launchUserView(library)
						else { collections = false; activeLibrary = library }
					}) { Text(library.name.orEmpty()) }
				}
				item { Button(onClick = { navigation.navigate(Destinations.liveTvGuide) }) { Text(stringResource(R.string.cinema_live)) } }
				item { Button(onClick = {
					collections = true
					activeLibrary = BaseItemDto(id = java.util.UUID(0L, 0L), name = context.getString(R.string.cinema_collections), type = BaseItemKind.FOLDER)
				}) { Text(stringResource(R.string.cinema_collections)) } }
				item { Button(onClick = { catalog = true }) { Text(stringResource(R.string.cinema_catalog)) } }
				item { Button(onClick = { navigation.navigate(Destinations.search()) }) { Text(stringResource(R.string.lbl_search)) } }
				item { Button(onClick = { context.startActivity(ActivityDestinations.userPreferences(context)) }) { Text(stringResource(R.string.lbl_settings)) } }
			}
		}
		if (failed) item { Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
			Text(stringResource(R.string.cinema_home_error))
			Button(onClick = { refresh++ }) { Text(stringResource(R.string.cinema_retry)) }
		} }
		val loaded = data
		if (loaded != null) {
			if (loaded.hero.isNotEmpty()) item(key = "hero") { CinemaHero(loaded.hero, api) { refresh++ } }
			if (loaded.partialFailure) item { Text(stringResource(R.string.cinema_partial_error), Modifier.padding(horizontal = 28.dp)) }
			if (loaded.rows.isEmpty()) item { Text(stringResource(R.string.cinema_empty_home), Modifier.padding(28.dp)) }
			items(loaded.rows, key = { it.key }) { row ->
				Column(Modifier.padding(top = 16.dp)) {
					Text(row.title, Modifier.padding(start = 28.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
					LazyRow(contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
						itemsIndexed(row.items, key = { _, item -> item.id }) { index, item ->
							CinemaCard(item, api, row.landscape, if (row.ranked) index + 1 else null) { navigation.navigate(Destinations.itemDetails(item.id)) }
						}
					}
				}
			}
		} else if (!failed) item { Text(stringResource(R.string.loading), Modifier.padding(28.dp)) }
	}
}

@Composable
private fun CinemaHero(items: List<BaseItemDto>, api: ApiClient, onFavoritesChanged: () -> Unit) {
	val context = LocalContext.current
	val navigation = koinInject<NavigationRepository>()
	val playback = koinInject<PlaybackHelper>()
	val mutations = koinInject<ItemMutationRepository>()
	val scope = rememberCoroutineScope()
	var selected by remember { mutableIntStateOf(0) }
	var paused by remember { mutableStateOf(false) }
	var muted by remember { mutableStateOf(true) }
	val owner = LocalLifecycleOwner.current
	var resumed by remember(owner) { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
	DisposableEffect(owner) {
		val observer = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
		owner.lifecycle.addObserver(observer)
		onDispose { owner.lifecycle.removeObserver(observer) }
	}
	LaunchedEffect(items, paused, resumed) {
		while (!paused && resumed && items.size > 1) { delay(10_000); selected = (selected + 1) % items.size }
	}
	val item = items[selected.coerceAtMost(items.lastIndex)]
	var favorite by remember(item.id, item.userData?.isFavorite) { mutableStateOf(item.userData?.isFavorite == true) }
	var saving by remember(item.id) { mutableStateOf(false) }
	var saveFailed by remember(item.id) { mutableStateOf(false) }
	Box(Modifier.fillMaxWidth().height(390.dp)) {
		Crossfade(item, animationSpec = tween(700), label = "cinema-backdrop") { slide ->
			AsyncImage(slide.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
		}
		CinemaPreview(item, api, paused, muted, Modifier.fillMaxSize())
		Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(CinemaBackground.copy(alpha = .92f), CinemaBackground.copy(alpha = .12f)))))
		Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, CinemaBackground))))
		Column(Modifier.align(Alignment.BottomStart).padding(28.dp).widthIn(max = 640.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
			val logo = item.itemImages[ImageType.LOGO]?.getUrl(api, maxWidth = 640)
			if (logo != null) AsyncImage(logo, item.name, Modifier.width(260.dp).height(90.dp), contentScale = ContentScale.Fit)
			else Text(item.name.orEmpty(), fontSize = 32.sp, fontWeight = FontWeight.Bold)
			Text(listOfNotNull(item.productionYear?.toString(), item.communityRating?.let { "★ $it" }, item.officialRating, item.genres?.take(2)?.joinToString(" • ")).joinToString("   "))
			item.overview?.let { Text(it, maxLines = 3, fontSize = 16.sp) }
			Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
				Button(onClick = { playback.retrieveAndPlay(item.id, false, item.userData?.playbackPositionTicks, context) }, colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black)) { Text(stringResource(if ((item.userData?.playbackPositionTicks ?: 0L) > 0L) R.string.cinema_resume else R.string.cinema_watch)) }
				Button(onClick = { navigation.navigate(Destinations.itemDetails(item.id)) }) { Text(stringResource(R.string.cinema_more)) }
				Button(enabled = !saving, onClick = {
					scope.launch {
						saving = true; saveFailed = false
						try { favorite = withContext(Dispatchers.IO) { mutations.setFavorite(item.id, !favorite).isFavorite == true }; onFavoritesChanged() }
						catch (error: CancellationException) { throw error }
						catch (_: Exception) { saveFailed = true }
						finally { saving = false }
					}
				}) { Text(stringResource(if (favorite) R.string.cinema_saved else R.string.cinema_my_list)) }
			}
			if (saveFailed) Text(stringResource(R.string.cinema_save_error))
			Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
				Button(onClick = { paused = !paused }) { Text(stringResource(if (paused) R.string.cinema_carousel_resume else R.string.cinema_pause)) }
				Button(onClick = { muted = !muted }) { Text(stringResource(if (muted) R.string.cinema_unmute else R.string.cinema_mute)) }
				items.forEachIndexed { index, _ -> Button(onClick = { selected = index }, modifier = Modifier.size(28.dp), contentPadding = PaddingValues(0.dp)) { Text(if (index == selected) "●" else "○", color = if (index == selected) CinemaGold else Color.White) } }
			}
		}
	}
}

@Composable
internal fun CinemaCard(item: BaseItemDto, api: ApiClient, landscape: Boolean, rank: Int?, square: Boolean = false, onFocus: () -> Unit = {}, onClick: () -> Unit) {
	var focused by remember { mutableStateOf(false) }
	val scale by animateFloatAsState(if (focused) 1.045f else 1f, label = "cinema-card-focus")
	val shape = RoundedCornerShape(8.dp)
	Column(Modifier.width(if (landscape) 240.dp else 150.dp).graphicsLayer { scaleX = scale; scaleY = scale }) {
		Button(onClick, Modifier.onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus() }.border(if (focused) 3.dp else 0.dp, if (focused) CinemaGold else Color.Transparent, shape), shape = shape, contentPadding = PaddingValues(0.dp)) {
			Box(Modifier.fillMaxWidth().height(if (square) 150.dp else if (landscape) 135.dp else 225.dp).clip(shape).background(Color(0xFF20242C))) {
				val image = if (landscape) item.itemBackdropImages.firstOrNull() ?: item.itemImages[ImageType.PRIMARY] else item.itemImages[ImageType.PRIMARY]
				AsyncImage(image?.getUrl(api, maxWidth = 480), item.name, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
				val badge = rank?.toString() ?: item.childCount?.takeIf { it > 0 }?.toString()
				if (badge != null) Text(badge, Modifier.align(Alignment.TopEnd).background(CinemaGold).padding(6.dp), color = Color.Black, fontWeight = FontWeight.Bold)
				if (item.userData?.played == true) Text("✓", Modifier.align(Alignment.TopStart).background(Color.Black.copy(alpha = .7f)).padding(6.dp))
				if (item.userData?.isFavorite == true) Text("♥", Modifier.align(Alignment.BottomEnd).background(Color.Black.copy(alpha = .7f)).padding(6.dp), color = CinemaGold)
				if (item.dateCreated?.isAfter(java.time.LocalDateTime.now(java.time.ZoneOffset.UTC).minusDays(30)) == true) Text(stringResource(R.string.cinema_new_badge), Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha = .7f)).padding(6.dp), color = CinemaGold, fontSize = 11.sp)
				val progress = item.userData?.playedPercentage?.toFloat()?.div(100f)?.coerceIn(0f, 1f) ?: 0f
				if (progress > 0f) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(progress).height(4.dp).background(CinemaGold))
			}
		}
		Text(item.name.orEmpty(), Modifier.padding(top = 6.dp), maxLines = 1, fontSize = 15.sp)
		Text(listOfNotNull(item.productionYear?.toString(), item.communityRating?.let { "★ $it" }).joinToString(" · "), fontSize = 13.sp, color = Color.LightGray)
	}
}
