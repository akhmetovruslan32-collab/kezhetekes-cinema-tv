package org.jellyfin.androidtv.ui.home

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemMutationRepository
import org.jellyfin.androidtv.data.repository.UserViewsRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.base.button.ButtonDefaults
import org.jellyfin.androidtv.ui.itemhandling.ItemLauncher
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.ActivityDestinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.util.PlaybackHelper
import org.jellyfin.androidtv.util.apiclient.getUrl
import org.jellyfin.androidtv.util.apiclient.itemBackdropImages
import org.jellyfin.androidtv.util.apiclient.itemImages
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.userViewsApi
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.ImageType
import org.jellyfin.sdk.model.api.CollectionType
import org.jellyfin.sdk.model.api.BaseItemKind
import org.koin.compose.koinInject

private val CinemaBackground = Color.Black
private val CinemaGold = Color(0xFFE2B65B)

internal fun cinemaLibraryName(library: BaseItemDto): String = if (library.name.orEmpty().contains("youtube", true)) "YouTube" else when (library.collectionType) {
	CollectionType.MOVIES -> "Фильмы"
	CollectionType.TVSHOWS -> "Сериалы"
	CollectionType.LIVETV -> "ТВ-каналы"
	else -> library.name.orEmpty()
}

@Composable
fun CinemaHomeScreen(initialSection: String = "home", screen: CinemaScreenState) {
	val context = LocalContext.current
	val api = koinInject<ApiClient>()
	val views = koinInject<UserViewsRepository>()
	val navigation = koinInject<NavigationRepository>()
	val repository = remember(api, views) { CinemaHomeRepository(api, views) }
	var data by screen::data
	var failed by remember { mutableStateOf(false) }
	var refresh by remember { mutableIntStateOf(0) }
	var catalog by screen::catalog
	var searchOnOpen by screen::searchOnOpen
	var activeLibrary by screen::activeLibrary
	var collections by remember { mutableStateOf(false) }
	LaunchedEffect(repository, refresh) {
		failed = false
		try {
            if (!screen.sectionApplied) { catalog = initialSection in setOf("catalog", "search"); searchOnOpen = initialSection == "search" }
            if (data == null || refresh > 0) data = if (initialSection == "home") repository.load(context)
            else if (initialSection in setOf("catalog", "search")) CinemaHomeData(emptyList(), emptyList(), emptyList(), false)
            else withContext(Dispatchers.IO) { CinemaHomeData(emptyList(), emptyList(), api.userViewsApi.getUserViews().content.items, false) }
        }
		catch (error: CancellationException) { throw error }
		catch (_: Exception) { failed = true }
	}
    var sectionApplied by screen::sectionApplied
    LaunchedEffect(data, initialSection) {
        if (!sectionApplied && data != null) {
            sectionApplied = true
            activeLibrary = data?.libraries?.firstOrNull { library -> when (initialSection) {
                "movies" -> library.collectionType == CollectionType.MOVIES && !library.name.orEmpty().contains("youtube", true)
                "series" -> library.collectionType == CollectionType.TVSHOWS
                "youtube" -> library.name.orEmpty().contains("youtube", true)
                else -> false
            } }
        }
    }
	if (catalog) { CinemaCatalogScreen(screen.catalogState, openSearch = searchOnOpen) { catalog = false; navigation.reset(Destinations.home, clearHistory = true) }; return }
	activeLibrary?.let { selected -> CinemaLibraryScreen(selected, screen, collections, onGlobalSearch = { searchOnOpen = true; catalog = true }) { activeLibrary = null; navigation.reset(Destinations.home, clearHistory = true) }; return }
	LazyColumn(Modifier.cinemaSidebarNavigation().fillMaxSize().background(CinemaBackground), state = screen.homeScroll, contentPadding = PaddingValues(bottom = 28.dp)) {
		if (failed) item { Column(Modifier.padding(28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
			Text(stringResource(R.string.cinema_home_error))
			Button(onClick = { refresh++ }) { Text(stringResource(R.string.cinema_retry)) }
		} }
		val loaded = data
		if (loaded != null) {
			if (loaded.hero.isNotEmpty()) item(key = "hero") { CinemaHero(loaded.hero, api, screen) { refresh++ } }
			if (loaded.partialFailure) item { Text(stringResource(R.string.cinema_partial_error), Modifier.padding(horizontal = 28.dp)) }
			if (loaded.rows.isEmpty()) item { Text(stringResource(R.string.cinema_empty_home), Modifier.padding(28.dp)) }
			items(loaded.rows, key = { it.key }) { row ->
				Column(Modifier.padding(top = 16.dp)) {
					Text(row.title, Modifier.padding(start = 28.dp), fontSize = 21.sp, fontWeight = FontWeight.Bold)
					LazyRow(state = screen.rowScrolls.getOrPut(row.key) { LazyListState() }, contentPadding = PaddingValues(horizontal = 28.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
						itemsIndexed(row.items, key = { _, item -> item.id }) { index, item ->
							CinemaCard(item, api, true, null,
                                restoreFocus = screen.restoreHomeFocus && screen.focusedHomeRow == row.key && screen.focusedHomeItem == item.id.toString(),
                                onRestored = { screen.restoreHomeFocus = false },
                                onFocus = { screen.focusedHomeRow = row.key; screen.focusedHomeItem = item.id.toString() }
                            ) { screen.restoreHomeFocus = true; navigation.navigate(Destinations.itemDetails(item.id)) }
						}
					}
				}
			}
		} else if (!failed) item { Text(stringResource(R.string.loading), Modifier.padding(28.dp)) }
	}
}

@Composable
private fun CinemaHero(items: List<BaseItemDto>, api: ApiClient, screen: CinemaScreenState, onFavoritesChanged: () -> Unit) {
	val context = LocalContext.current
	val navigation = koinInject<NavigationRepository>()
	val playback = koinInject<PlaybackHelper>()
	val mutations = koinInject<ItemMutationRepository>()
	val scope = rememberCoroutineScope()
	var selected by screen::heroSelected
	var paused by remember { mutableStateOf(false) }
	var muted by screen::heroMuted
	val owner = LocalLifecycleOwner.current
	var resumed by remember(owner) { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
	DisposableEffect(owner) {
		val observer = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
		owner.lifecycle.addObserver(observer)
		onDispose { owner.lifecycle.removeObserver(observer) }
	}
	LaunchedEffect(items, paused, resumed) {
		while (!paused && resumed && items.size > 1) { delay(20_000); selected = (selected + 1) % items.size }
	}
	val item = items[selected.coerceAtMost(items.lastIndex)]
	var previewStatus by remember(item.id) { mutableStateOf<String?>(null) }
	var favorite by remember(item.id, item.userData?.isFavorite) { mutableStateOf(item.userData?.isFavorite == true) }
	var saving by remember(item.id) { mutableStateOf(false) }
	var saveFailed by remember(item.id) { mutableStateOf(false) }
	Box(Modifier.fillMaxWidth().height(390.dp)) {
		Crossfade(item, animationSpec = tween(700), label = "cinema-backdrop") { slide ->
			AsyncImage(slide.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
		}
		CinemaPreview(item, api, false, muted, Modifier.fillMaxSize())
		Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(CinemaBackground.copy(alpha = .92f), CinemaBackground.copy(alpha = .12f)))))
		Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, CinemaBackground))))

			Row(Modifier.align(Alignment.TopEnd).padding(24.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
				CinemaIconButton(if (muted) R.drawable.cinema_sound_off else R.drawable.cinema_sound_on, if (muted) "Включить звук" else "Выключить звук") { muted = !muted }
				items.forEachIndexed { index, _ -> Button(onClick = { selected = index }, modifier = Modifier.size(28.dp), contentPadding = PaddingValues(0.dp)) { Text(if (index == selected) "●" else "○") } }
			}
		Column(Modifier.align(Alignment.BottomStart).padding(28.dp).widthIn(max = 640.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
			val logo = item.itemImages[ImageType.LOGO]?.getUrl(api, maxWidth = 640)
			if (logo != null) AsyncImage(logo, item.name, Modifier.width(260.dp).height(90.dp), contentScale = ContentScale.Fit)
			else Text(item.name.orEmpty(), fontSize = 32.sp, fontWeight = FontWeight.Bold)
			Text(listOfNotNull(item.productionYear?.toString(), item.communityRating?.let { "★ $it" }, item.officialRating, item.genres?.take(2)?.joinToString(" • ")).joinToString("   "))
			item.overview?.let { Text(it, maxLines = 3, fontSize = 16.sp) }
			Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
				Button(onClick = { playback.retrieveAndPlay(item.id, false, item.userData?.playbackPositionTicks, context) }, colors = ButtonDefaults.colors(containerColor = Color(0xFF262626), contentColor = Color.White)) { Text(stringResource(if ((item.userData?.playbackPositionTicks ?: 0L) > 0L) R.string.cinema_resume else R.string.cinema_watch)) }
				Button(onClick = { navigation.navigate(Destinations.itemDetails(item.id)) }) { Text(stringResource(R.string.cinema_more)) }
			}

		}
	}
}

@Composable
internal fun CinemaCard(item: BaseItemDto, api: ApiClient, landscape: Boolean, rank: Int?, square: Boolean = false, restoreFocus: Boolean = false, onRestored: () -> Unit = {}, onFocus: () -> Unit = {}, onClick: () -> Unit) {
	var focused by remember { mutableStateOf(false) }
	val focus = remember(item.id) { FocusRequester() }
    LaunchedEffect(restoreFocus) { if (restoreFocus) { withFrameNanos { }; focus.requestFocus(); onRestored() } }
	val shape = RoundedCornerShape(8.dp)
	Column(Modifier.width(if (landscape) 240.dp else 150.dp).padding(5.dp)) {
		Button(onClick, Modifier.focusRequester(focus).onFocusChanged { focused = it.isFocused; if (it.isFocused) onFocus() }, shape = shape, contentPadding = PaddingValues(0.dp)) {
			Box(Modifier.fillMaxWidth().height(if (square) 150.dp else if (landscape) 135.dp else 225.dp).clip(shape).background(Color(0xFF191919))) {
				val image = if (landscape) item.itemBackdropImages.firstOrNull() ?: item.itemImages[ImageType.PRIMARY] else item.itemImages[ImageType.PRIMARY]
				AsyncImage(image?.getUrl(api, maxWidth = 480), item.name, Modifier.fillMaxSize(), contentScale = if (square) ContentScale.Fit else ContentScale.Crop)
				val badge = rank?.toString() ?: item.childCount?.takeIf { it > 0 }?.toString()
				if (badge != null) Text(badge, Modifier.align(Alignment.TopEnd).background(Color(0xDD191919)).padding(6.dp), color = Color.White, fontWeight = FontWeight.Bold)
				if (item.userData?.played == true) Text("✓ Просмотрено", Modifier.align(Alignment.TopStart).background(Color.Black.copy(alpha = .7f)).padding(6.dp))
				if (item.userData?.isFavorite == true) Text("♥", Modifier.align(Alignment.BottomEnd).background(Color.Black.copy(alpha = .7f)).padding(6.dp), color = Color.White)
				if (item.dateCreated?.isAfter(java.time.LocalDateTime.now(java.time.ZoneOffset.UTC).minusDays(30)) == true) Text(stringResource(R.string.cinema_new_badge), Modifier.align(Alignment.BottomStart).background(Color.Black.copy(alpha = .7f)).padding(6.dp), color = Color.White, fontSize = 11.sp)
				val progress = item.userData?.playedPercentage?.toFloat()?.div(100f)?.coerceIn(0f, 1f) ?: 0f
				if (progress > 0f) Box(Modifier.align(Alignment.BottomStart).fillMaxWidth(progress).height(4.dp).background(CinemaGold))
			}
		}
		Text(item.name.orEmpty(), Modifier.padding(top = 10.dp), maxLines = 1, fontSize = 18.sp, color = if (focused) CinemaGold else Color.White)
		Text(listOfNotNull(item.productionYear?.toString(), item.communityRating?.let { "★ $it" }).joinToString(" · "), fontSize = 15.sp, color = Color.LightGray)
	}
}

@Composable
internal fun CinemaIconButton(resource: Int, description: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val caption = when { description.contains("поиск", true) || description == "Найти" -> "Поиск"; description.contains("звук", true) -> "Звук"; else -> description }
    Column(Modifier.width(60.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Button(onClick, modifier = Modifier.size(44.dp).onFocusChanged { focused = it.isFocused }, contentPadding = PaddingValues(10.dp)) {
            org.jellyfin.androidtv.ui.base.Icon(androidx.compose.ui.graphics.vector.ImageVector.vectorResource(resource), contentDescription = description, tint = Color.White)
        }
        Text(caption, color = if (focused) CinemaGold else Color.White, fontSize = 12.sp, maxLines = 1)
    }
}
