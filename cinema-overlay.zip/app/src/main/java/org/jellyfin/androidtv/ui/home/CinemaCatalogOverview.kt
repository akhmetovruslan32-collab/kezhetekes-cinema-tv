package org.jellyfin.androidtv.ui.home

import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.FrameLayout
import android.view.Gravity
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.json.JSONObject

private data class CatalogShelf(val title: String, val path: String, val kind: String? = null, val entries: List<JSONObject> = emptyList(), val failed: Boolean = false)
private data class ShelfCard(val entry: JSONObject?, val more: Boolean = false)

@Composable
internal fun CinemaCatalogOverview(state: CinemaCatalogState, api: CinemaCatalogApi, modifier: Modifier,
    enter: Boolean, onEntered: () -> Unit, onTop: () -> Unit, onOpen: (JSONObject) -> Unit, onMore: (String, String) -> Unit) {
    val type = state.tab
    val prefix = if (type == "movie") "discover/movies" else "discover/tv"
    val definitions = remember(type) {
        val noun = if (type == "movie") "фильмы" else "сериалы"
        listOf(CatalogShelf("Популярные $noun этой недели", "$prefix/trending"),
            CatalogShelf("Популярные $noun", "$prefix/popular"),
            CatalogShelf("${if (type == "movie") "Фильмы" else "Сериалы"} с высоким рейтингом", "$prefix/top-rated"),
            CatalogShelf(if (type == "movie") "Скоро в кино" else "Скоро на экранах", "$prefix/upcoming")) +
            (if (type == "tv") listOf(CatalogShelf("Аниме", "$prefix/anime")) else emptyList()) +
            listOf(CatalogShelf("По жанрам", "genres/$type", "genre"),
                CatalogShelf("По стриминговым сервисам", "providers/$type", "provider"),
                CatalogShelf(if (type == "movie") "По студиям" else "По телеканалам", if (type == "movie") "studios/movie" else "networks/tv", if (type == "movie") "studio" else "network"))
    }
    var shelves by remember(api, type) { mutableStateOf<List<CatalogShelf>>(emptyList()) }
    var revision by remember { mutableIntStateOf(0) }
    LaunchedEffect(api, type, revision) {
        shelves = coroutineScope { definitions.map { shelf -> async {
            try { shelf.copy(entries = api.get(shelf.path + if (shelf.kind == null) "?startIndex=0&limit=10" else "").entries("Items", "items", "Results", "results")) }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { shelf.copy(failed = true) }
        } }.awaitAll() }
    }
    val open by rememberUpdatedState(onOpen)
    val more by rememberUpdatedState(onMore)
    val top by rememberUpdatedState(onTop)
    val grids = remember { mutableListOf<HorizontalGridView>() }
    AndroidView(modifier = modifier, factory = { context ->
        ScrollView(context).apply { clipChildren = true; clipToPadding = true; setBackgroundColor(android.graphics.Color.BLACK); isFocusable = false
            addView(LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }, ViewGroup.LayoutParams(-1, -2)) }
    }, update = { scroll ->
        val column = scroll.getChildAt(0) as LinearLayout
        if (scroll.tag != shelves) {
            scroll.tag = shelves; column.removeAllViews(); grids.clear()
            val density = scroll.resources.displayMetrics.density
            fun dp(value: Int) = (value * density).toInt()
            if (shelves.isEmpty()) column.addView(TextView(scroll.context).apply { text = "Загрузка подборок…"; setTextColor(-1); textSize = 21f })
            shelves.forEachIndexed { row, shelf ->
                column.addView(TextView(scroll.context).apply { text = shelf.title; setTextColor(-1); textSize = 23f; setPadding(dp(18), dp(10), 0, dp(4)) })
                val items = shelf.entries.let { if (shelf.kind == null) it.take(10) else it }.map { ShelfCard(it) } +
                    if (shelf.kind == null || shelf.failed) listOf(ShelfCard(null, true)) else emptyList()
                val grid = HorizontalGridView(scroll.context)
                grids.add(grid)
                val presenter = object : Presenter() {
                    override fun onCreateViewHolder(parent: ViewGroup) = ViewHolder(LegacyImageCardView(parent.context, true).apply {
                        useCinemaTransparentInfo(); isFocusable = true; isFocusableInTouchMode = true
                        cardType = BaseCardView.CARD_TYPE_INFO_UNDER; infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS
                    })
                    override fun onBindViewHolder(holder: ViewHolder, item: Any?) {
                        val value = item as ShelfCard; val entry = value.entry
                        val card = holder.view as LegacyImageCardView
                        val user = entry?.optJSONObject("UserData") ?: entry?.optJSONObject("userData")
                        card.setUnwatchedCount(if (user?.optBoolean("Played", user.optBoolean("played")) == true) 0 else -1)
                        card.showFavIcon(user?.optBoolean("IsFavorite", user.optBoolean("isFavorite")) == true)
                        card.setMainImageDimensions(144, if (shelf.kind == null) 216 else 144, ImageView.ScaleType.FIT_CENTER)
                        card.setTitleText(if (value.more) "" else entry?.text("Name", "name", "title")?.replaceFirstChar { it.titlecase(java.util.Locale.forLanguageTag("ru-RU")) })
                        card.setContentText(if (shelf.kind == null) entry?.cinemaCatalogMeta().orEmpty() else "")
                        if (value.more) {
                            card.mainImageView.load(url = null)
                            card.mainImageView.setImageDrawable(null)
                            card.mainImageView.setBackgroundColor(android.graphics.Color.TRANSPARENT)
                            card.mainImageView.foreground = android.graphics.drawable.ColorDrawable(android.graphics.Color.TRANSPARENT)
                            card.setTitleText(""); card.setContentText("")
                            val label = (card.getTag(R.id.cinema_more_label) as? TextView) ?: TextView(card.context).apply {
                                gravity = Gravity.CENTER; textSize = 23f; setTextColor(-1)
                                card.overlay.add(this); card.setTag(R.id.cinema_more_label, this)
                                card.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> measure(View.MeasureSpec.makeMeasureSpec(card.width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(dp(216), View.MeasureSpec.EXACTLY)); layout(0, 0, card.width, dp(216)) }
                            }
                            label.visibility = View.VISIBLE
                            label.text = if (shelf.failed) "Повторить" else "Ещё  →"
                            label.measure(View.MeasureSpec.makeMeasureSpec(card.width, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(dp(216), View.MeasureSpec.EXACTLY))
                            label.layout(0, 0, card.width, dp(216))
                        }
                        else {
                            (card.getTag(R.id.cinema_more_label) as? TextView)?.visibility = View.GONE
                            val image = if (shelf.kind == null) entry?.cinemaCatalogPoster() else entry?.text("logo", "logoPath", "LogoPath", "imagePath", "backdropPath", "backdrop_path")?.ifBlank { entry?.optJSONArray("backdrops")?.optString(0).orEmpty() }?.takeIf { it.isNotBlank() && it != "not found" }?.let { if (it.startsWith("http")) it else "https://image.tmdb.org/t/p/original$it" }
                            card.mainImageView.load(url = image)
                        }
                        card.setOnClickListener {
                            state.overviewRow = row; state.overviewPositions[row] = grid.selectedPosition
                            when {
                                shelf.failed -> revision++
                                value.more -> more(shelf.title, shelf.path)
                                shelf.kind != null && entry != null -> more(entry.text("Name", "name"), "$prefix/${shelf.kind}/${entry.text("id", "Id")}")
                                entry != null -> open(entry)
                            }
                        }
                    }
                    override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null) }
                }
                val objects = ArrayObjectAdapter(presenter).apply { addAll(0, items) }
                val bridge = ItemBridgeAdapter(objects)
                FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
                grid.apply {
                    adapter = bridge; setNumRows(1); setHorizontalSpacing(dp(20)); setPadding(dp(18), dp(14), dp(18), dp(14))
                    clipChildren = false; clipToPadding = false
                    setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ALIGNED)
                    setSelectedPosition((state.overviewPositions[row] ?: 0).coerceIn(0, items.lastIndex.coerceAtLeast(0)))
                    installCinemaShelfKeys(
                        { if (row == 0) top() else grids.getOrNull(row - 1)?.focusCinemaItem(0) },
                        { grids.getOrNull(row + 1)?.focusCinemaItem(0) }
                    )
                    addOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
                        override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                            if (hasFocus() && position >= 0) { state.overviewRow = row; state.overviewPositions[row] = position }
                        }
                    })
                }
                column.addView(grid, LinearLayout.LayoutParams(-1, dp(if (shelf.kind == null) 300 else 230)))
            }
        }
        if ((enter || state.restoreFocus) && grids.isNotEmpty()) {
            val row = if (enter) 0 else state.overviewRow.coerceIn(0, grids.lastIndex)
            grids[row].focusCinemaItem(if (enter) 0 else state.overviewPositions[row] ?: 0)
            state.restoreFocus = false; onEntered()
        }
    })
}
