package org.jellyfin.androidtv.ui.home;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Observed playing intervals only: seeking to the end is not a completed watch. */
public final class CinemaYouTubeCoverage {
    private final List<double[]> ranges = new ArrayList<>();
    private double previousPosition, previousRate = 1, duration;
    private long previousTime;
    private boolean previousPlaying, previousSeeking, sampled, dirty;
    public void sample(double position, double length, boolean playing, boolean seeking, double rate, long time) {
        if (!Double.isFinite(position) || !Double.isFinite(length) || length <= 0 || length > 604800 || position < 0 || position > length + 1) { sampled = false; return; }
        if (duration > 0 && Math.abs(length - duration) >= 1) reset();
        duration = length;
        double elapsed = (time - previousTime) / 1000.0, delta = position - previousPosition;
        if (sampled && previousPlaying && playing && !previousSeeking && !seeking && elapsed > 0 && elapsed < 10
                && delta > 0 && delta <= elapsed * Math.min(4, Math.max(.25, previousRate)) + 1.2) {
            ranges.add(new double[]{previousPosition, Math.min(position, length)});
            merge(); dirty = true;
        }
        previousPosition = position; previousTime = time; previousRate = rate;
        previousPlaying = playing; previousSeeking = seeking; sampled = true;
    }
    private void merge() {
        ranges.sort(Comparator.comparingDouble(a -> a[0]));
        List<double[]> merged = new ArrayList<>();
        for (double[] range : ranges) {
            if (!merged.isEmpty() && range[0] <= merged.get(merged.size()-1)[1]+.05) {
                double[] last = merged.get(merged.size()-1); last[1] = Math.max(last[1],range[1]);
            } else merged.add(range.clone());
        }
        if (merged.size() > 128) { merged.sort((a,b) -> Double.compare(b[1]-b[0],a[1]-a[0])); merged = new ArrayList<>(merged.subList(0,128)); merged.sort(Comparator.comparingDouble(a -> a[0])); }
        ranges.clear(); ranges.addAll(merged);
    }
    public List<double[]> snapshot() { List<double[]> copy = new ArrayList<>(); for (double[] range : ranges) copy.add(range.clone()); return copy; }
    public boolean isDirty() { return dirty; }
    public void saved() { dirty = false; }
    public void retry() { dirty = true; }
    public void reset() { ranges.clear(); sampled = false; dirty = false; duration = 0; }
}
