package org.jellyfin.androidtv.ui.home

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.BuildConfig
import org.jellyfin.sdk.api.client.util.AuthorizationHeaderBuilder
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL

/** StageFv5 Jellyfin YouTube bridge. Credentials remain the active Jellyfin session. */
internal class CinemaYouTubeApi(private val server: String, private val token: String) {
    suspend fun get(path: String): Any = withContext(Dispatchers.IO) {
        require(token.isNotBlank())
        val connection = URL("${server.trimEnd('/')}/YouTube/Api/$path").openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 25_000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("X-Emby-Token", token)
            connection.setRequestProperty("Authorization", AuthorizationHeaderBuilder.buildHeader(
                clientName = "Kezhetekes Cinema", clientVersion = BuildConfig.VERSION_NAME,
                deviceId = "cinema-tv", deviceName = android.os.Build.MODEL, accessToken = token))
            check(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val bytes = connection.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    check(out.size() + count <= 8 * 1024 * 1024)
                    out.write(buffer, 0, count)
                }
                out.toByteArray()
            }
            JSONTokener(bytes.toString(Charsets.UTF_8)).nextValue()
        } finally { connection.disconnect() }
    }
}

internal fun Any.youtubeItems(): List<JSONObject> {
    val array = when (this) {
        is JSONArray -> this
        is JSONObject -> optJSONArray("Items") ?: optJSONArray("items") ?: optJSONArray("videos") ?: JSONArray()
        else -> JSONArray()
    }
    return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
}
