package org.jellyfin.androidtv.ui.home

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.BuildConfig
import org.jellyfin.sdk.api.client.util.AuthorizationHeaderBuilder
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.net.HttpURLConnection
import java.net.URL

/** StageFv5 Jellyfin YouTube bridge. Credentials remain the active Jellyfin session. */
internal class CinemaYouTubeApi(private val server: String, private val token: String) {
    suspend fun list(path: String): Any = try { get(path) }
    catch (cancel: kotlinx.coroutines.CancellationException) { throw cancel }
    catch (failure: Exception) {
        // Recommendations can be unavailable while the independent subscription feed still works.
        if (path.startsWith("Recommendations") && (failure is java.io.IOException || failure.message?.startsWith("HTTP 5") == true)) get("ForYou")
        else throw failure
    }

    suspend fun get(path: String): Any = call(path)
    suspend fun write(path: String, method: String = "POST", body: JSONObject? = null): Any = call(path, method, body)
    suspend fun watched(items: List<JSONObject>): Set<String> {
        val ids = items.map { it.text("videoId") }.filter { it.matches(Regex("[A-Za-z0-9_-]{11}")) }.distinct()
        return ids.chunked(100).flatMap { batch ->
            (get("Watch?ids=${java.net.URLEncoder.encode(batch.joinToString(","), "UTF-8")}") as JSONObject).entries("items", "Items")
                .filter { it.optBoolean("watched", it.optBoolean("Watched")) }.map { it.text("videoId", "VideoId") }
        }.toSet()
    }
    private suspend fun call(path: String, method: String = "GET", body: JSONObject? = null): Any = withContext(Dispatchers.IO) {
        require(token.isNotBlank())
        val connection = URL("${server.trim().trimEnd('/').let { if (it.startsWith("http://") || it.startsWith("https://")) it else "http://$it" }}/YouTube/Api/$path").openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = 15_000
            connection.readTimeout = 45_000
            connection.instanceFollowRedirects = false
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("X-Emby-Token", token)
            connection.setRequestProperty("Authorization", AuthorizationHeaderBuilder.buildHeader(
                clientName = "Kezhetekes Cinema", clientVersion = BuildConfig.VERSION_NAME,
                deviceId = "cinema-tv", deviceName = android.os.Build.MODEL, accessToken = token))
            connection.requestMethod = method
            if (method == "POST") {
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                connection.outputStream.use { it.write((body?.toString() ?: "{}").toByteArray(Charsets.UTF_8)) }
            }
            check(connection.responseCode in 200..299) { "HTTP ${connection.responseCode}" }
            val bytes = connection.inputStream.use { input ->
                val out = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(8192)
                while (true) {
                    val count = input.read(buffer)
                    if (count < 0) break
                    check(out.size() + count <= 8 * 1024 * 1024)
                    out.write(buffer, 0, count)
                }
                out.toByteArray()
            }
            if (bytes.isEmpty()) JSONObject() else JSONTokener(bytes.toString(Charsets.UTF_8)).nextValue()
        } finally { connection.disconnect() }
    }
}

internal fun android.view.View.roundCinemaYouTubeImage(channel: Boolean = false) {
    clipToOutline = true
    outlineProvider = object : android.view.ViewOutlineProvider() {
        override fun getOutline(view: android.view.View, outline: android.graphics.Outline) {
            if (channel) outline.setOval(0, 0, view.width, view.height)
            else outline.setRoundRect(0, 0, view.width, view.height, 10 * view.resources.displayMetrics.density)
        }
    }
    invalidateOutline()
}

internal fun Any.youtubeItems(): List<JSONObject> {
    val array = when (this) {
        is JSONArray -> this
        is JSONObject -> optJSONArray("Items") ?: optJSONArray("items") ?: optJSONArray("videos") ?: optJSONArray("Videos") ?: optJSONArray("channels") ?: optJSONArray("Channels") ?: error("Неожиданный формат ответа YouTube.")
        else -> JSONArray()
    }
    return (0 until array.length()).mapNotNull { array.optJSONObject(it) }.map { it.normalizeYouTube() }
}

internal fun JSONObject.normalizeYouTube(): JSONObject {
    for (key in listOf("videoId", "title", "author", "authorId", "authorThumbnails", "latestVideos", "lengthSeconds", "published", "viewCount", "description", "isSubscribed", "url", "width")) {
        if (!has(key)) opt(key.replaceFirstChar { it.uppercase() })?.let { put(key, it) }
    }
    for (key in listOf("authorThumbnails", "latestVideos")) optJSONArray(key)?.let { list ->
        for (index in 0 until list.length()) list.optJSONObject(index)?.normalizeYouTube()
    }
    return this
}

internal fun Exception.youtubeFailureMessage(): String = when (this) {
    is java.net.SocketTimeoutException -> "Сервер не ответил вовремя. Можно повторить загрузку."
    is java.net.ConnectException -> "Нет соединения с сервером Jellyfin."
    else -> when {
        message?.startsWith("HTTP 401") == true -> "HTTP 401: войдите в Jellyfin повторно."
        message?.startsWith("HTTP 403") == true -> "HTTP 403: сервер запретил доступ для этого пользователя."
        message?.startsWith("HTTP 5") == true -> "${message}: сервис YouTube временно недоступен."
        message?.startsWith("HTTP") == true -> message.orEmpty()
        message == "Неожиданный формат ответа YouTube." -> message.orEmpty()
        else -> "Проверьте подключение и настройки плагина YouTube."
    }
}
