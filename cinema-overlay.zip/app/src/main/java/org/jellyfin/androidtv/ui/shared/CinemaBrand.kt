package org.jellyfin.androidtv.ui.shared

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.base.Text

@Composable
fun CinemaBrand() {
	Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
		Image(
			painter = painterResource(R.drawable.cinema_goat),
			contentDescription = stringResource(R.string.app_name),
			contentScale = ContentScale.Fit,
			modifier = Modifier.size(64.dp),
		)
		Column {
			Text(stringResource(R.string.cinema_brand), fontSize = 20.sp, color = colorResource(R.color.cinema_gold))
			Text(stringResource(R.string.cinema_subtitle), fontSize = 14.sp, letterSpacing = 3.sp, color = colorResource(R.color.cinema_gold))
		}
	}
}
