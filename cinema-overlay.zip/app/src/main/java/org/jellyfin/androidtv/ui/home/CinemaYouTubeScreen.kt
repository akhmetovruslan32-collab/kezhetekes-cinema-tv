package org.jellyfin.androidtv.ui.home

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.collect
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.search.composable.SearchTextInput
import org.jellyfin.sdk.api.client.ApiClient
import org.json.JSONObject
import org.koin.compose.koinInject
import java.net.URLEncoder

class CinemaYouTubeState {
    var tab by mutableStateOf("Popular")
    var watchMarks by mutableStateOf(emptySet<String>())
    var channel by mutableStateOf<JSONObject?>(null)
    var entries by mutableStateOf<List<JSONObject>>(emptyList())
    var query by mutableStateOf("")
    var submittedQuery by mutableStateOf("")
    var nativePosition by mutableIntStateOf(0)
    var focusedId by mutableStateOf<String?>(null)
    var restoreFocus by mutableStateOf(false)
    var loadedKey: String? = null
    var continuation by mutableStateOf<String?>(null)
}

@Composable
fun CinemaYouTubeScreen(state: CinemaYouTubeState) {
    val client = koinInject<ApiClient>()
    val context = LocalContext.current
    val session by koinInject<org.jellyfin.androidtv.auth.repository.SessionRepository>().currentSession.collectAsState()
    val server by koinInject<org.jellyfin.androidtv.auth.repository.ServerRepository>().currentServer.collectAsState()
    val address = client.baseUrl ?: server?.address.orEmpty()
    val token = session?.accessToken ?: client.accessToken.orEmpty()
    val api = remember(address, token) { CinemaYouTubeApi(address, token) }
    val scope = rememberCoroutineScope()
    val firstFocus = remember { FocusRequester() }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var revision by remember { mutableIntStateOf(0) }
    var publicUrl by remember { mutableStateOf<String?>(null) }
    var channelInfo by remember { mutableStateOf<JSONObject?>(null) }
    var subscriptionBusy by remember { mutableStateOf(false) }
    var channelError by remember { mutableStateOf<String?>(null) }
    var watchRefresh by remember { mutableIntStateOf(0) }
    val lifecycle = androidx.lifecycle.compose.LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event -> if (event == androidx.lifecycle.Lifecycle.Event.ON_RESUME) watchRefresh++ }
        lifecycle.addObserver(observer); onDispose { lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(api, state.entries, watchRefresh) {
        try { state.watchMarks = api.watched(state.entries) }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { }
    }
    LaunchedEffect(api, state.channel?.text("authorId")) {
        channelInfo = null; channelError = null
        val id = state.channel?.text("authorId") ?: return@LaunchedEffect
        try { channelInfo = (api.get("Channel/${URLEncoder.encode(id, "UTF-8")}") as JSONObject).normalizeYouTube() }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { channelError = "Не удалось загрузить информацию о канале." }
    }
    LaunchedEffect(api) {
        try { publicUrl = (api.get("Config") as JSONObject).text("publicUrl", "PublicUrl") }
        catch (cancel: CancellationException) { throw cancel }
        catch (_: Exception) { publicUrl = null }
    }
    var searchShown by remember { mutableStateOf(false) }
    var enterNative by remember { mutableStateOf(false) }
    val searchFocus = remember { FocusRequester() }
    val key = "${state.tab}:${state.channel?.text("authorId")}:${state.submittedQuery}"
    LaunchedEffect(Unit) {
        if (!state.restoreFocus) {
            state.tab = "Popular"; state.channel = null; state.submittedQuery = ""
            withFrameNanos { }; withFrameNanos { }; firstFocus.requestFocus()
        }
    }
    LaunchedEffect(searchShown) { if (searchShown) { withFrameNanos { }; searchFocus.requestFocus() } }
    LaunchedEffect(api, key, revision, if (state.tab == "Continue") watchRefresh else 0) {
        loading = true; error = null
        try {
            if (state.loadedKey != key || revision > 0 || state.entries.isEmpty() || state.tab == "Continue") {
                state.entries = emptyList(); state.continuation = null; state.nativePosition = 0
                val path = when {
                    state.submittedQuery.isNotBlank() -> "Search?q=${URLEncoder.encode(state.submittedQuery, "UTF-8")}" 
                    state.channel != null -> "Channel/${state.channel!!.text("authorId")}/Videos"
                    state.tab == "Continue" -> "Watch/Continue"
                    else -> if (state.tab == "Recommendations") "Recommendations?limit=30" else state.tab
                }
                val result = api.list(path)
                state.entries = result.youtubeItems()
                state.continuation = (result as? JSONObject)?.text("NextCursor", "nextCursor", "continuation")?.takeIf { it.isNotBlank() }
                state.loadedKey = key
                state.nativePosition = 0
            }
        } catch (cancel: CancellationException) { throw cancel }
        catch (failure: Exception) { error = "Не удалось загрузить YouTube. ${failure.youtubeFailureMessage()}" }
        finally { loading = false }
    }
    LaunchedEffect(api, key, state.loadedKey, watchRefresh, loading) {
        if (!loading && state.tab == "Continue" && state.channel == null && state.submittedQuery.isBlank() && state.loadedKey == key) {
            state.entries.filter { it.text("title").isBlank() || it.text("author").isBlank() }.chunked(4).forEach { batch ->
                val resolved = coroutineScope { batch.map { entry -> async {
                    try {
                        val metadata = (api.get("Watch/Features?videoId=${URLEncoder.encode(entry.text("videoId"), "UTF-8")}") as JSONObject).normalizeYouTube()
                        JSONObject(entry.toString()).apply { for (field in listOf("title", "author", "authorId")) metadata.text(field).takeIf { it.isNotBlank() }?.let { put(field, it) } }
                    } catch (cancel: CancellationException) { throw cancel }
                    catch (_: Exception) { entry }
                } }.awaitAll() }
                val byId = resolved.associateBy { it.text("videoId") }
                state.entries = state.entries.map { byId[it.text("videoId")] ?: it }
            }
        }
    }
    BackHandler(enabled = state.channel != null || state.submittedQuery.isNotBlank()) {
        state.channel = null; state.submittedQuery = ""; state.query = ""
    }
    val enterGrid = Modifier.onPreviewKeyEvent { event ->
        if (event.type == KeyEventType.KeyDown && event.key == Key.DirectionDown && state.entries.isNotEmpty()) {
            enterNative = true; true
        } else false
    }
    Column(Modifier.fillMaxSize().background(Color.Black).padding(horizontal = 28.dp)) {
        Text(state.channel?.text("author") ?: "YouTube", fontSize = 28.sp, modifier = Modifier.padding(vertical = 12.dp))
        LazyRow(enterGrid.cinemaSidebarNavigation(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Button(modifier = Modifier.focusRequester(firstFocus), onClick = { state.tab = "Popular"; state.channel = null; state.submittedQuery = "" }) { Text("Популярное") } }
            item { Button(onClick = { state.tab = "Subscriptions"; state.channel = null; state.submittedQuery = "" }) { Text("Подписки") } }
            item { Button(onClick = { state.tab = "Continue"; state.channel = null; state.submittedQuery = "" }) { Text("Продолжить просмотр") } }
            item { Button(onClick = { searchShown = !searchShown }) { Text("Поиск") } }
        }
        if (state.channel != null) Row(enterGrid.cinemaSidebarNavigation().fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            val info = channelInfo ?: state.channel!!
            AsyncImage(info.entries("authorThumbnails").lastOrNull()?.text("url"), null,
                modifier = Modifier.size(68.dp).then(Modifier.graphicsLayer { clip = true; shape = androidx.compose.foundation.shape.CircleShape }), contentScale = ContentScale.Fit)
            Column(Modifier.weight(1f)) {
                Text(info.text("author"), fontSize = 23.sp)
                Text(info.text("description").take(220), fontSize = 16.sp)
                channelError?.let { Text(it) }
            }
            if (channelInfo != null) Button(onClick = {
                if (!subscriptionBusy) scope.launch {
                    subscriptionBusy = true; channelError = null
                    try {
                        val subscribed = channelInfo!!.optBoolean("isSubscribed")
                        api.write("Subscriptions/${URLEncoder.encode(info.text("authorId"), "UTF-8")}", if (subscribed) "DELETE" else "POST")
                        channelInfo = JSONObject(channelInfo.toString()).put("isSubscribed", !subscribed)
                    } catch (cancel: CancellationException) { throw cancel }
                    catch (_: Exception) { channelError = "Не удалось изменить подписку. Попробуйте снова." }
                    finally { subscriptionBusy = false }
                }
            }) { Text(if (subscriptionBusy) "Сохранение…" else if (channelInfo!!.optBoolean("isSubscribed")) "✓ Вы подписаны" else "Подписаться") }
        }
        if (searchShown) SearchTextInput(state.query, { state.query = it }, { state.submittedQuery = state.query.trim(); state.channel = null }, enterGrid.fillMaxWidth().padding(vertical = 12.dp).focusRequester(searchFocus))
        if (loading) Text("Загрузка…", modifier = Modifier.padding(12.dp))
        error?.let { Text(it); Button(onClick = { revision++ }) { Text("Повторить") } }
        if (!loading && error == null && state.entries.isEmpty()) Text("Пока нет материалов. Попробуйте «Подписки» или поиск.")
        CinemaNativeYouTubeGrid(state, Modifier.weight(1f).fillMaxWidth().clipToBounds(), enterNative, { enterNative = false }, publicUrl, { if (searchShown) searchFocus.requestFocus() else firstFocus.requestFocus() }) { entry ->
            val videoId = entry.text("videoId")
            if (videoId.isBlank()) { state.channel = entry; state.submittedQuery = ""; state.nativePosition = 0 }
            else {
                scope.launch {
                    try {
                        val base = publicUrl?.takeIf { it.isNotBlank() }
                            ?: (api.get("Config") as JSONObject).text("publicUrl", "PublicUrl").also { publicUrl = it }
                        check(base.startsWith("http://") || base.startsWith("https://")) { "Адрес Invidious не задан в плагине." }
                        state.restoreFocus = true
                        context.startActivity(Intent(context, CinemaYouTubePlayerActivity::class.java).putExtra("url", "${base.trimEnd('/')}/embed/$videoId?autoplay=1&controls=0").putExtra("channelId", entry.text("authorId")).putExtra("channelName", entry.text("author")).putExtra("videoId", videoId).putExtra("title", entry.text("title")))
                    } catch (cancel: CancellationException) { throw cancel }
                    catch (failure: Exception) { error = "Не удалось открыть видео. ${failure.youtubeFailureMessage()}" }
                }
            }
        }
        LaunchedEffect(api, key) {
            snapshotFlow { !loading && state.continuation != null && state.nativePosition >= state.entries.size - 8 }.collect { ready ->
            if (!ready) return@collect
            val cursor = state.continuation ?: return@collect
            loading = true
            try {
                val encoded = URLEncoder.encode(cursor, "UTF-8")
                val path = if (state.channel != null) "Channel/${state.channel!!.text("authorId")}/Videos?continuation=$encoded" else "Recommendations?limit=30&cursor=$encoded"
                val result = api.get(path)
                val added = result.youtubeItems()
                val previousCount = state.entries.size
                state.entries = (state.entries + added).distinctBy { it.text("videoId", "authorId") }
                state.continuation = (result as? JSONObject)?.text("NextCursor", "nextCursor", "continuation")?.takeIf { it.isNotBlank() && it != cursor && state.entries.size > previousCount }
            } catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { error = "Не удалось загрузить следующие видео."; state.continuation = null }
            finally { loading = false }
            }
        }
    }
}
