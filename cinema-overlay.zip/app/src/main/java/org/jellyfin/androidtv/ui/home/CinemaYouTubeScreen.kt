package org.jellyfin.androidtv.ui.home

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.search.composable.SearchTextInput
import org.jellyfin.sdk.api.client.ApiClient
import org.json.JSONObject
import org.koin.compose.koinInject
import java.net.URLEncoder

class CinemaYouTubeState {
    var tab by mutableStateOf("Recommendations")
    var channel by mutableStateOf<JSONObject?>(null)
    var entries by mutableStateOf<List<JSONObject>>(emptyList())
    var query by mutableStateOf("")
    var submittedQuery by mutableStateOf("")
    var nativePosition = 0
    var focusedId by mutableStateOf<String?>(null)
    var restoreFocus by mutableStateOf(false)
    var loadedKey: String? = null
    var continuation: String? = null
    val scroll = LazyGridState()
}

@Composable
fun CinemaYouTubeScreen(state: CinemaYouTubeState) {
    val client = koinInject<ApiClient>()
    val context = LocalContext.current
    val api = remember(client.baseUrl, client.accessToken) { CinemaYouTubeApi(client.baseUrl.orEmpty(), client.accessToken.orEmpty()) }
    val scope = rememberCoroutineScope()
    val firstFocus = remember { FocusRequester() }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var revision by remember { mutableIntStateOf(0) }
    var publicUrl by remember { mutableStateOf<String?>(null) }
    var searchShown by remember { mutableStateOf(false) }
    var enterNative by remember { mutableStateOf(false) }
    val searchFocus = remember { FocusRequester() }
    val key = "${state.tab}:${state.channel?.text("authorId")}:${state.submittedQuery}"
    LaunchedEffect(searchShown) { if (searchShown) { withFrameNanos { }; searchFocus.requestFocus() } }
    LaunchedEffect(key, revision) {
        loading = true; error = null
        try {
            if (publicUrl == null) publicUrl = (api.get("Config") as JSONObject).text("publicUrl", "PublicUrl")
            if (state.loadedKey != key || revision > 0) {
                state.entries = emptyList(); state.continuation = null; state.scroll.scrollToItem(0)
                val path = when {
                    state.submittedQuery.isNotBlank() -> "Search?q=${URLEncoder.encode(state.submittedQuery, "UTF-8")}" 
                    state.channel != null -> "Channel/${state.channel!!.text("authorId")}/Videos"
                    else -> state.tab
                }
                val result = api.get(path)
                state.entries = result.youtubeItems()
                state.continuation = (result as? JSONObject)?.text("NextCursor", "nextCursor", "continuation")?.takeIf { it.isNotBlank() }
                state.loadedKey = key
            }
        } catch (cancel: CancellationException) { throw cancel }
        catch (failure: Exception) { error = "Не удалось загрузить YouTube. ${failure.message?.takeIf { it.startsWith("HTTP") }.orEmpty()}" }
        finally { loading = false }
    }
    BackHandler(enabled = state.channel != null || state.submittedQuery.isNotBlank()) {
        state.channel = null; state.submittedQuery = ""; state.query = ""
    }
    val enterGrid = Modifier.onPreviewKeyEvent { event ->
        if (event.type == KeyEventType.KeyDown && event.key == Key.DirectionDown && state.entries.isNotEmpty()) {
            enterNative = true; true
        } else false
    }
    Column(Modifier.cinemaSidebarNavigation().fillMaxSize().background(Color.Black).padding(horizontal = 28.dp)) {
        Text(state.channel?.text("author") ?: "YouTube", fontSize = 28.sp, modifier = Modifier.padding(vertical = 12.dp))
        LazyRow(enterGrid, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Button(onClick = { state.tab = "Recommendations"; state.channel = null; state.submittedQuery = "" }) { Text("Для вас") } }
            item { Button(onClick = { state.tab = "Subscriptions"; state.channel = null; state.submittedQuery = "" }) { Text("Подписки") } }
            item { Button(onClick = { state.tab = "Popular"; state.channel = null; state.submittedQuery = "" }) { Text("Популярное") } }
            item { Button(onClick = { searchShown = !searchShown }) { Text("Поиск") } }
        }
        if (searchShown) SearchTextInput(state.query, { state.query = it }, { state.submittedQuery = state.query.trim(); state.channel = null }, enterGrid.fillMaxWidth().padding(vertical = 12.dp).focusRequester(searchFocus))
        if (loading) Text("Загрузка…", modifier = Modifier.padding(12.dp))
        error?.let { Text(it); Button(onClick = { revision++ }) { Text("Повторить") } }
        CinemaNativeYouTubeGrid(state, Modifier.weight(1f).fillMaxWidth(), enterNative, { enterNative = false }) { entry ->
            val videoId = entry.text("videoId")
            if (videoId.isBlank()) { state.channel = entry; state.submittedQuery = ""; state.nativePosition = 0 }
            else {
                val base = publicUrl.orEmpty().trimEnd('/')
                if (base.startsWith("http://") || base.startsWith("https://")) {
                    state.restoreFocus = true
                    context.startActivity(Intent(context, CinemaYouTubePlayerActivity::class.java).putExtra("url", "$base/embed/$videoId?autoplay=1&controls=1"))
                } else error = "В настройках плагина не указан адрес Invidious."
            }
        }
        if (!loading && state.continuation != null) Button(onClick = {
            scope.launch {
                loading = true
                try {
                    val cursor = URLEncoder.encode(state.continuation, "UTF-8")
                    val path = if (state.channel != null) "Channel/${state.channel!!.text("authorId")}/Videos?continuation=$cursor" else "Recommendations?cursor=$cursor"
                    val result = api.get(path)
                    state.entries = (state.entries + result.youtubeItems()).distinctBy { it.text("videoId", "authorId") }
                    state.continuation = (result as? JSONObject)?.text("NextCursor", "nextCursor", "continuation")?.takeIf { it.isNotBlank() }
                } catch (cancel: CancellationException) { throw cancel } catch (_: Exception) { error = "Не удалось загрузить следующие видео." } finally { loading = false }
            }
        }) { Text("Загрузить ещё") }
    }
}
