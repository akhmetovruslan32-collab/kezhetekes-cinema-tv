package org.jellyfin.androidtv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.*
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.key.*
import kotlinx.coroutines.launch
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.util.apiclient.getUrl
import org.jellyfin.androidtv.util.apiclient.itemBackdropImages
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.model.api.*
import org.koin.compose.koinInject

@Composable
fun CinemaLibraryScreen(library: BaseItemDto, screen: CinemaScreenState, collections: Boolean = false, onGlobalSearch: () -> Unit = {}, onBack: () -> Unit) {
	val api = koinInject<ApiClient>()
	val navigation = koinInject<NavigationRepository>()
	val session = remember(library.id) { screen.libraries.getOrPut(library.id.toString()) { CinemaLibraryState(library) } }
	var stack by session::stack
	val current = stack.last()
	var sort by session::sort
	var filter by session::filter
	val page = remember(current.id, sort, filter) { session.pages.getOrPut("${current.id}:$sort:$filter") { CinemaLibraryPage() } }
	val gridState = page.scroll

	var showFilters by remember { mutableStateOf(false) }
	var revision by remember { mutableIntStateOf(0) }
	var entries by page::entries
	var total by page::total
    val firstFocus = remember(current.id) { FocusRequester() }
    val scope = rememberCoroutineScope()
    var initialFocusAssigned by remember(current.id) { mutableStateOf(false) }
    LaunchedEffect(entries.isNotEmpty()) { if (entries.isNotEmpty() && !initialFocusAssigned && !page.restoreFocus) { withFrameNanos { }; firstFocus.requestFocus(); initialFocusAssigned = true } }
    val enterGrid = Modifier.onPreviewKeyEvent { event ->
        if (event.type == KeyEventType.KeyDown && event.key == Key.DirectionDown && entries.isNotEmpty()) {
            scope.launch { gridState.scrollToItem(0); withFrameNanos { }; withFrameNanos { }; firstFocus.requestFocus() }; true
        } else false
    }
	var failed by remember(current.id) { mutableStateOf(false) }
	var loading by remember(current.id) { mutableStateOf(true) }
	var backdrop by remember(current.id) { mutableStateOf(current.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920)) }
	fun back() { if (stack.size > 1) stack = stack.dropLast(1) else onBack() }
	BackHandler { back() }
	LaunchedEffect(current.id, sort, filter, revision) {
		var offset = page.nextOffset
        if (entries.isNotEmpty() && offset >= total) { loading = false; return@LaunchedEffect }
        if (entries.isNotEmpty()) snapshotFlow { (gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1) >= entries.size - 8 }.first { it }
		do {
		loading = true; failed = false
		try {
			val allCollections = collections && stack.size == 1
			val movies = !allCollections && current.collectionType == CollectionType.MOVIES
			val series = !allCollections && current.collectionType == CollectionType.TVSHOWS
			val result = withContext(Dispatchers.IO) { api.itemsApi.getItems(
				parentId = if (allCollections) null else current.id,
				recursive = allCollections || movies || series,
				includeItemTypes = when { allCollections -> setOf(BaseItemKind.BOX_SET); movies -> setOf(BaseItemKind.MOVIE, BaseItemKind.BOX_SET); series -> setOf(BaseItemKind.SERIES); else -> null },
				collapseBoxSetItems = movies,
				fields = ItemRepository.browseFields,
				sortBy = setOf(sort),
				sortOrder = setOf(if (sort == ItemSortBy.SORT_NAME) SortOrder.ASCENDING else SortOrder.DESCENDING),
				filters = if (filter and 2 != 0) setOf(ItemFilter.IS_FAVORITE) else null,
				isPlayed = if (filter and 1 != 0) false else null,
				startIndex = offset, limit = 40,
			).content }
			entries = (entries + result.items).distinctBy { it.id }
			val next = offset + result.items.size
			if (next == offset) break
			offset = next
            page.nextOffset = offset
			total = result.totalRecordCount
			if (backdrop == null) backdrop = entries.firstNotNullOfOrNull { it.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920) }
		} catch (failure: CancellationException) { throw failure }
		catch (_: Exception) { failed = true }
		finally { loading = false }
		if (failed || offset >= total) break
		snapshotFlow { (gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1) >= entries.size - 8 }.first { it }
		} while (true)
	}
    if (showFilters) androidx.compose.ui.window.Dialog(onDismissRequest = { showFilters = false }) {
        Column(Modifier.width(340.dp).background(Color(0xF0181818), androidx.compose.foundation.shape.RoundedCornerShape(20.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Сортировка", fontSize = 23.sp)
            listOf(ItemSortBy.SORT_NAME to "По названию", ItemSortBy.COMMUNITY_RATING to "По рейтингу", ItemSortBy.DATE_CREATED to "Недавно добавленные").forEach { (value, title) ->
                Button(onClick = { sort = value; showFilters = false }, modifier = Modifier.fillMaxWidth()) { Text((if (sort == value) "✓  " else "") + title) }
            }
            Button(onClick = { filter = 0; sort = ItemSortBy.SORT_NAME; showFilters = false }) { Text("Сбросить") }
        }
    }
	Box(Modifier.cinemaSidebarNavigation().fillMaxSize().background(Color.Black)) {
		Column(Modifier.fillMaxSize().padding(horizontal = 28.dp)) {
			LazyRow(enterGrid.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
								item { CinemaIconButton(R.drawable.ic_sort, "Сортировка", onClick = { showFilters = true }) }
                item { CinemaIconButton(R.drawable.ic_unwatch, "Не просмотрено", selected = filter and 1 != 0, onClick = { filter = filter xor 1 }) }
                item { CinemaIconButton(R.drawable.ic_heart, "Избранное", selected = filter and 2 != 0, onClick = { filter = filter xor 2 }) }
				item { CinemaIconButton(R.drawable.ic_search, "Глобальный поиск", onClick = onGlobalSearch) }
			}

			Text("${cinemaLibraryName(current)}   ·   $total", fontSize = 24.sp)
			if (loading && entries.isEmpty()) Text(stringResource(R.string.loading))
			if (failed) Row {
				Text(stringResource(R.string.cinema_home_error))
				Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
			}
			if (!loading && !failed && entries.isEmpty()) Text(stringResource(R.string.cinema_catalog_empty))
			LazyVerticalGrid(GridCells.Adaptive(160.dp), Modifier.weight(1f), state = gridState, contentPadding = PaddingValues(vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
				items(entries, key = { it.id }) { item ->
					val folder = item.type == BaseItemKind.FOLDER || item.type == BaseItemKind.BOX_SET
					CinemaCard(item, api, false, null, externalFocus = if (item.id == entries.firstOrNull()?.id) firstFocus else null, square = library.name.orEmpty().contains("youtube", true),
                        restoreFocus = page.restoreFocus && page.focusedId == item.id.toString(), onRestored = { page.restoreFocus = false }, onFocus = {
                        page.focusedId = item.id.toString()
						item.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920)?.let { backdrop = it }
					}) {
						page.restoreFocus = true
                        if (folder) { stack = stack + item }
                        else navigation.navigate(Destinations.itemDetails(item.id))
					}
				}
			}
		}
	}
}
