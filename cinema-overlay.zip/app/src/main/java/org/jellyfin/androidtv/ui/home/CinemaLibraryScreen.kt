package org.jellyfin.androidtv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.util.apiclient.getUrl
import org.jellyfin.androidtv.util.apiclient.itemBackdropImages
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.model.api.*
import org.koin.compose.koinInject

@Composable
fun CinemaLibraryScreen(library: BaseItemDto, collections: Boolean = false, onGlobalSearch: () -> Unit = {}, onBack: () -> Unit) {
	val api = koinInject<ApiClient>()
	val navigation = koinInject<NavigationRepository>()
	var stack by remember(library.id, collections) { mutableStateOf(listOf(library)) }
	val current = stack.last()
	var sort by remember { mutableStateOf(ItemSortBy.SORT_NAME) }
	var filter by remember { mutableIntStateOf(0) }
	val gridState = rememberLazyGridState()
	var showFilters by remember { mutableStateOf(false) }
	var revision by remember { mutableIntStateOf(0) }
	var entries by remember(current.id) { mutableStateOf<List<BaseItemDto>>(emptyList()) }
	var total by remember(current.id) { mutableIntStateOf(0) }
	var failed by remember(current.id) { mutableStateOf(false) }
	var loading by remember(current.id) { mutableStateOf(true) }
	var backdrop by remember(current.id) { mutableStateOf(current.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920)) }
	fun back() { if (stack.size > 1) stack = stack.dropLast(1) else onBack() }
	BackHandler { back() }
	LaunchedEffect(current.id, sort, filter, revision) {
		entries = emptyList(); total = 0
		gridState.scrollToItem(0)
		var offset = 0
		do {
		loading = true; failed = false
		try {
			val allCollections = collections && stack.size == 1
			val movies = !allCollections && current.collectionType == CollectionType.MOVIES
			val series = !allCollections && current.collectionType == CollectionType.TVSHOWS
			val result = withContext(Dispatchers.IO) { api.itemsApi.getItems(
				parentId = if (allCollections) null else current.id,
				recursive = allCollections || movies || series,
				includeItemTypes = when { allCollections -> setOf(BaseItemKind.BOX_SET); movies -> setOf(BaseItemKind.MOVIE, BaseItemKind.BOX_SET); series -> setOf(BaseItemKind.SERIES); else -> null },
				collapseBoxSetItems = movies,
				fields = ItemRepository.browseFields,
				sortBy = setOf(sort),
				sortOrder = setOf(if (sort == ItemSortBy.SORT_NAME) SortOrder.ASCENDING else SortOrder.DESCENDING),
				filters = if (filter == 2) setOf(ItemFilter.IS_FAVORITE) else null,
				isPlayed = if (filter == 1) false else null,
				startIndex = offset, limit = 40,
			).content }
			entries = (entries + result.items).distinctBy { it.id }
			val next = offset + result.items.size
			if (next == offset) break
			offset = next
			total = result.totalRecordCount
			if (backdrop == null) backdrop = entries.firstNotNullOfOrNull { it.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920) }
		} catch (failure: CancellationException) { throw failure }
		catch (_: Exception) { failed = true }
		finally { loading = false }
		if (failed || offset >= total) break
		snapshotFlow { (gridState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: -1) >= entries.size - 8 }.first { it }
		} while (true)
	}
	Box(Modifier.cinemaSidebarNavigation().fillMaxSize().background(Color(0xFF080B0F))) {
		Crossfade(backdrop, animationSpec = tween(700), label = "library-backdrop") { url -> AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
		Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF080B0F).copy(alpha = .7f), Color(0xFF080B0F).copy(alpha = .82f)))))
		Column(Modifier.fillMaxSize().padding(horizontal = 28.dp)) {
			LazyRow(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
				item { Button(onClick = { showFilters = !showFilters }) { Text("Фильтры") } }
				item { CinemaIconButton(R.drawable.ic_search, "Глобальный поиск", onGlobalSearch) }
			}
			if (showFilters) LazyRow(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
				items(6) { option ->
					val labels = listOf("Все", "Не посмотрено", "Избранное", "По рейтингу", "Недавно добавленное", "По названию")
					Button(onClick = {
						when (option) {
							0 -> { filter = 0; sort = ItemSortBy.SORT_NAME }
							1 -> filter = 1
							2 -> filter = 2
							3 -> sort = ItemSortBy.COMMUNITY_RATING
							4 -> sort = ItemSortBy.DATE_CREATED
							5 -> sort = ItemSortBy.SORT_NAME
						}
						showFilters = false
					}) { Text(labels[option]) }
				}
			}
			Text("${cinemaLibraryName(current)}   ·   $total", fontSize = 24.sp)
			if (loading && entries.isEmpty()) Text(stringResource(R.string.loading))
			if (failed) Row {
				Text(stringResource(R.string.cinema_home_error))
				Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
			}
			if (!loading && !failed && entries.isEmpty()) Text(stringResource(R.string.cinema_catalog_empty))
			LazyVerticalGrid(GridCells.Adaptive(160.dp), Modifier.weight(1f), state = gridState, contentPadding = PaddingValues(vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
				items(entries, key = { it.id }) { item ->
					val folder = item.type == BaseItemKind.FOLDER || item.type == BaseItemKind.BOX_SET
					CinemaCard(item, api, false, null, square = item.type == BaseItemKind.FOLDER && current.collectionType !in setOf(CollectionType.MOVIES, CollectionType.TVSHOWS), onFocus = {
						item.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920)?.let { backdrop = it }
					}) {
						if (folder) { stack = stack + item; filter = 0 }
						else navigation.navigate(Destinations.itemDetails(item.id))
					}
				}
			}
		}
	}
}
