package org.jellyfin.androidtv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.data.repository.ItemRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.util.apiclient.getUrl
import org.jellyfin.androidtv.util.apiclient.itemBackdropImages
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.model.api.*
import org.koin.compose.koinInject

@Composable
fun CinemaLibraryScreen(library: BaseItemDto, collections: Boolean = false, onBack: () -> Unit) {
	val api = koinInject<ApiClient>()
	val navigation = koinInject<NavigationRepository>()
	var stack by remember(library.id, collections) { mutableStateOf(listOf(library)) }
	val current = stack.last()
	var sort by remember { mutableStateOf(ItemSortBy.SORT_NAME) }
	var filter by remember { mutableIntStateOf(0) }
	var page by remember(current.id) { mutableIntStateOf(0) }
	var revision by remember { mutableIntStateOf(0) }
	var entries by remember(current.id) { mutableStateOf<List<BaseItemDto>>(emptyList()) }
	var total by remember(current.id) { mutableIntStateOf(0) }
	var failed by remember(current.id) { mutableStateOf(false) }
	var loading by remember(current.id) { mutableStateOf(true) }
	var backdrop by remember(current.id) { mutableStateOf(current.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920)) }
	fun back() { if (stack.size > 1) stack = stack.dropLast(1) else onBack() }
	BackHandler { back() }
	LaunchedEffect(current.id, sort, filter, page, revision) {
		loading = true; failed = false
		try {
			val allCollections = collections && stack.size == 1
			val movies = !allCollections && current.collectionType == CollectionType.MOVIES
			val series = !allCollections && current.collectionType == CollectionType.TVSHOWS
			val result = withContext(Dispatchers.IO) { api.itemsApi.getItems(
				parentId = if (allCollections) null else current.id,
				recursive = allCollections || movies || series,
				includeItemTypes = when { allCollections -> setOf(BaseItemKind.BOX_SET); movies -> setOf(BaseItemKind.MOVIE, BaseItemKind.BOX_SET); series -> setOf(BaseItemKind.SERIES); else -> null },
				collapseBoxSetItems = movies,
				fields = ItemRepository.browseFields,
				sortBy = setOf(sort),
				sortOrder = setOf(if (sort == ItemSortBy.SORT_NAME) SortOrder.ASCENDING else SortOrder.DESCENDING),
				filters = if (filter == 2) setOf(ItemFilter.IS_FAVORITE) else null,
				isPlayed = if (filter == 1) false else null,
				startIndex = page * 40, limit = 40,
			).content }
			entries = result.items
			total = result.totalRecordCount
			if (backdrop == null) backdrop = entries.firstNotNullOfOrNull { it.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920) }
		} catch (failure: CancellationException) { throw failure }
		catch (_: Exception) { failed = true }
		finally { loading = false }
	}
	Box(Modifier.fillMaxSize().background(Color(0xFF080B0F))) {
		Crossfade(backdrop, animationSpec = tween(700), label = "library-backdrop") { url -> AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
		Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF080B0F).copy(alpha = .7f), Color(0xFF080B0F).copy(alpha = .82f)))))
		Column(Modifier.fillMaxSize().padding(horizontal = 28.dp)) {
			LazyRow(Modifier.padding(vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
				item { Button(onClick = { back() }) { Text(stringResource(R.string.cinema_previous_page)) } }
				item { Button(onClick = { sort = ItemSortBy.SORT_NAME; page = 0 }) { Text(stringResource(R.string.cinema_sort_name)) } }
				item { Button(onClick = { sort = ItemSortBy.DATE_CREATED; page = 0 }) { Text(stringResource(R.string.cinema_recently_added)) } }
				item { Button(onClick = { sort = ItemSortBy.COMMUNITY_RATING; page = 0 }) { Text(stringResource(R.string.cinema_sort_rating)) } }
				item { Button(onClick = { filter = (filter + 1) % 3; page = 0 }) { Text(stringResource(when (filter) { 1 -> R.string.cinema_filter_unwatched; 2 -> R.string.cinema_my_list; else -> R.string.cinema_filter_all })) } }
			}
			Text("${current.name.orEmpty()}   ·   $total", fontSize = 24.sp)
			if (loading) Text(stringResource(R.string.loading))
			if (failed) Row {
				Text(stringResource(R.string.cinema_home_error))
				Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
			}
			if (!loading && !failed && entries.isEmpty()) Text(stringResource(R.string.cinema_catalog_empty))
			LazyVerticalGrid(GridCells.Adaptive(160.dp), Modifier.weight(1f), contentPadding = PaddingValues(vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
				items(entries, key = { it.id }) { item ->
					val folder = item.type == BaseItemKind.FOLDER || item.type == BaseItemKind.BOX_SET
					CinemaCard(item, api, false, null, square = item.type == BaseItemKind.FOLDER && current.collectionType !in setOf(CollectionType.MOVIES, CollectionType.TVSHOWS), onFocus = {
						item.itemBackdropImages.firstOrNull()?.getUrl(api, maxWidth = 1920)?.let { backdrop = it }
					}) {
						if (folder) { stack = stack + item; filter = 0 }
						else navigation.navigate(Destinations.itemDetails(item.id))
					}
				}
			}
			Row(Modifier.padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
				Button(enabled = page > 0 && !loading, onClick = { page-- }) { Text(stringResource(R.string.cinema_previous_page)) }
				Text(stringResource(R.string.cinema_page, page + 1))
				Button(enabled = (page + 1) * 40 < total && !loading, onClick = { page++ }) { Text(stringResource(R.string.cinema_next_page)) }
			}
		}
	}
}
