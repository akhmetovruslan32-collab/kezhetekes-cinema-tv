package org.jellyfin.androidtv.ui.search.composable

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.base.Icon
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import androidx.compose.ui.focus.onFocusChanged

@Composable
fun SearchTextInput(query: String, onQueryChange: (String) -> Unit, onQuerySubmit: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val change by rememberUpdatedState(onQueryChange)
    val submit by rememberUpdatedState(onQuerySubmit)
    var open by remember { mutableStateOf(false) }
    var dismissed by remember { mutableStateOf(false) }
    DisposableEffect(open) {
        val dialog = if (open) cinemaTvKeyboard(context, query, { change(it) }, { submit() }, { open = false; dismissed = true }).also { it.show() } else null
        onDispose { dialog?.setOnDismissListener(null); dialog?.dismiss() }
    }
    Button(onClick = { open = true }, modifier = modifier.onFocusChanged {
        if (it.isFocused && !dismissed) open = true
        if (!it.isFocused && !open) dismissed = false
    }, shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(ImageVector.vectorResource(R.drawable.ic_search), contentDescription = "Поиск")
            Text(query.ifBlank { "Введите запрос…" }, fontSize = 20.sp, maxLines = 1)
        }
    }
}
