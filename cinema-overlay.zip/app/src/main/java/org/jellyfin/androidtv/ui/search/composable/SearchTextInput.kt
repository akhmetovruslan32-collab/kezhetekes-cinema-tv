package org.jellyfin.androidtv.ui.search.composable

import android.app.Dialog
import android.graphics.Color
import android.view.Gravity
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.Button
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.jellyfin.androidtv.ui.base.Text

/** Remote keyboard independent of vendor IME and paired phones. */
@Composable
fun SearchTextInput(query: String, onQueryChange: (String) -> Unit, onQuerySubmit: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val change by rememberUpdatedState(onQueryChange)
    val submit by rememberUpdatedState(onQuerySubmit)
    var focused by remember { mutableStateOf(false) }
    var keyboardOpen by remember { mutableStateOf(false) }
    Text(text = if (query.isEmpty()) "Поиск — нажмите ОК для ввода" else query, fontSize = 20.sp,
        color = androidx.compose.ui.graphics.Color(if (focused) 0xFFE2B65B else 0xFFFFFFFF),
        modifier = modifier.onFocusChanged { focused = it.isFocused; if (it.isFocused) keyboardOpen = true }
            .onPreviewKeyEvent { event ->
                if (event.nativeKeyEvent.action == KeyEvent.ACTION_DOWN && event.nativeKeyEvent.keyCode in listOf(KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER)) { keyboardOpen = true; true } else false
            }.clickable { keyboardOpen = true }.background(androidx.compose.ui.graphics.Color.Black).padding(14.dp))
    if (keyboardOpen) DisposableEffect(context) {
        val dialog = Dialog(context)
        var input = query
        var russian = true
        fun dp(value: Int) = (value * context.resources.displayMetrics.density).toInt()
        val body = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(12), dp(18), dp(12)); setBackgroundColor(Color.BLACK) }
        val display = TextView(context).apply { textSize = 22f; setTextColor(Color.WHITE); text = input.ifEmpty { "Введите название" }; setPadding(0, 0, 0, dp(10)) }
        body.addView(display, LinearLayout.LayoutParams(-1, dp(48)))
        val keys = GridLayout(context).apply { columnCount = 8 }
        body.addView(keys)
        fun refresh() { display.text = input.ifEmpty { "Введите название" }; change(input) }
        fun button(label: String, action: () -> Unit) = Button(context).apply {
            text = label; textSize = 18f; isAllCaps = false; setTextColor(Color.WHITE)
            setOnFocusChangeListener { _, selected -> setTextColor(if (selected) 0xFFE2B65B.toInt() else Color.WHITE) }
            setOnClickListener { action() }
        }
        fun fillKeys() {
            keys.removeAllViews()
            val alphabet = if (russian) "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ0123456789" else "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
            alphabet.forEach { letter -> keys.addView(button(letter.toString()) { input += letter; refresh() }, GridLayout.LayoutParams().apply { width = dp(70); height = dp(43) }) }
        }
        fillKeys()
        val actions = LinearLayout(context)
        fun action(label: String, block: () -> Unit) { actions.addView(button(label, block), LinearLayout.LayoutParams(0, dp(50), 1f)) }
        action("РУ / EN") { russian = !russian; fillKeys() }
        action("Пробел") { input += " "; refresh() }
        action("⌫") { input = input.dropLast(1); refresh() }
        action("Очистить") { input = ""; refresh() }
        action("Найти") { change(input); dialog.dismiss(); submit() }
        body.addView(actions)
        dialog.setContentView(body)
        dialog.setOnDismissListener { keyboardOpen = false }
        dialog.window?.apply { setBackgroundDrawableResource(android.R.color.transparent); addFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM); setGravity(Gravity.CENTER) }
        dialog.show()
        dialog.window?.setLayout(dp(596), WindowManager.LayoutParams.WRAP_CONTENT)
        keys.getChildAt(0)?.requestFocus()
        onDispose { dialog.setOnDismissListener(null); dialog.dismiss() }
    }
}
