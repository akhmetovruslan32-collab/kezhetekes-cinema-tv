package org.jellyfin.androidtv.ui.home

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import org.jellyfin.androidtv.constant.ImageType
import org.jellyfin.androidtv.ui.itemhandling.BaseItemDtoBaseRowItem
import org.jellyfin.androidtv.ui.presentation.CardPresenter
import org.jellyfin.sdk.model.api.BaseItemDto

/** Uses the same CardPresenter and Leanback focus animator as the cast/similar-film rows. */
@Composable
internal fun CinemaNativeMovieRow(items: List<BaseItemDto>, rowKey: String, screen: CinemaScreenState,
    onVertical: (Boolean) -> Unit, onClick: (BaseItemDto) -> Unit) {
    val vertical by rememberUpdatedState(onVertical)
    val click by rememberUpdatedState(onClick)
    AndroidView(modifier = Modifier.fillMaxWidth().height(230.dp), factory = { context ->
        val grid = HorizontalGridView(context).apply {
            setNumRows(1)
            val density = resources.displayMetrics.density
            setPadding((28*density).toInt(), (18*density).toInt(), (28*density).toInt(), (18*density).toInt())
            setHorizontalSpacing((24*density).toInt())
            clipChildren = false
            clipToPadding = false
            setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ALIGNED)
            windowAlignment = BaseGridView.WINDOW_ALIGN_BOTH_EDGE
        }
        val objectAdapter = ArrayObjectAdapter(CardPresenter(true, ImageType.THUMB, 135))
        objectAdapter.addAll(0, items.map { BaseItemDtoBaseRowItem(it, preferParentThumb = true, staticHeight = true) })
        val bridge = ItemBridgeAdapter(objectAdapter)
        FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
        bridge.setAdapterListener(object : ItemBridgeAdapter.AdapterListener() {
            override fun onBind(holder: ItemBridgeAdapter.ViewHolder) {
                val view = holder.viewHolder.view
                (view as? BaseCardView)?.apply { infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS }
                val item = (holder.item as BaseItemDtoBaseRowItem).baseItem ?: return
                view.setOnClickListener { screen.focusedHomeRow = rowKey; screen.focusedHomeItem = item.id.toString(); screen.nativeRowPositions[rowKey] = items.indexOf(item); screen.restoreHomeFocus = true; click(item) }

            }
        })
        grid.installCinemaShelfKeys({ vertical(false) }, { vertical(true) })
        grid.adapter = bridge
        grid.setOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
            override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                if (grid.hasFocus() && position in items.indices) {
                    screen.nativeRowPositions[rowKey] = position
                    screen.focusedHomeRow = rowKey
                    screen.focusedHomeItem = items[position].id.toString()
                }
            }
        })
        grid.setSelectedPosition(screen.nativeRowPositions[rowKey] ?: 0)
        grid
    }, update = { grid ->
        if (screen.pendingHomeRow == rowKey || (screen.restoreHomeFocus && screen.focusedHomeRow == rowKey)) {
            val restore = screen.restoreHomeFocus
            val position = if (restore) screen.nativeRowPositions[rowKey] ?: 0 else 0
            screen.pendingHomeRow = null
            screen.restoreHomeFocus = false
            grid.focusCinemaItem(position)
        }
    })
}
