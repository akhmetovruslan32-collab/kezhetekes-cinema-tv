package org.jellyfin.androidtv.ui.home

import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.ImageView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import org.jellyfin.androidtv.ui.browsing.MainActivity
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.jellyfin.androidtv.util.apiclient.getUrl
import org.jellyfin.androidtv.util.apiclient.itemImages
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.ImageType
import org.json.JSONObject

private data class CatalogCard(val remote: JSONObject? = null, val local: BaseItemDto? = null)

/** Fixed four-column grid. All arrow navigation stays in the same native focus system. */
@Composable
internal fun CinemaNativeCatalogGrid(state: CinemaCatalogState, api: ApiClient, modifier: Modifier,
    enter: Boolean, onEntered: () -> Unit, onTop: () -> Unit, onOpen: (JSONObject) -> Unit, onLibraryOpen: (BaseItemDto) -> Unit) {
    val cards = remember(state.entries, state.libraryMatches) {
        state.libraryMatches.map { CatalogCard(local = it) } + state.entries.map { CatalogCard(remote = it) }
    }
    val currentCards by rememberUpdatedState(cards)
    val top by rememberUpdatedState(onTop)
    val open by rememberUpdatedState(onOpen)
    val libraryOpen by rememberUpdatedState(onLibraryOpen)
    val gridHolder = remember { arrayOfNulls<VerticalGridView>(1) }
    val presenter = remember(api) { object : Presenter() {
        override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(LegacyImageCardView(parent.context, true).apply {
            useCinemaTransparentInfo()
                isFocusable = true; isFocusableInTouchMode = true
            cardType = BaseCardView.CARD_TYPE_INFO_UNDER
            infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS
        })
        override fun onBindViewHolder(holder: ViewHolder, item: Any?) {
            val entry = item as CatalogCard
            val card = holder.view as LegacyImageCardView
            val grid = gridHolder[0]
            val density = card.resources.displayMetrics.density
            val width = if (grid != null && grid.width > 0)
                (((grid.width - grid.paddingLeft - grid.paddingRight) / density - 3 * 18) / 4 - 12).toInt().coerceAtLeast(100)
                else 164
            card.setMainImageDimensions(width, width * 3 / 2, ImageView.ScaleType.CENTER_CROP)
            val remote = entry.remote
            card.setTitleText(entry.local?.name ?: remote?.text("Name", "name", "title", "OriginalTitle"))
            card.setContentText(entry.local?.let { item ->
                val kp = item.providerIds?.entries?.firstOrNull { it.key.equals("KinopoiskRating", true) || it.key.equals("KpRating", true) }?.value?.toDoubleOrNull()?.takeIf { it > 0 && it <= 10 }
                listOfNotNull(item.productionYear?.toString(), item.communityRating?.let { "★ ${String.format(java.util.Locale.US, "%.1f", it)}" }, "КП ${kp?.let { String.format(java.util.Locale.US, "%.1f", it) } ?: "—"}", item.officialRating).joinToString(" · ")
            } ?: listOfNotNull(remote?.text("OfficialRating", "officialRating")?.takeIf { it.isNotBlank() },
                if (state.tab == "requests") remote?.text("mediaStatusLabel", "statusLabel") else null).joinToString(" · "))
            val poster = remote?.optJSONObject("ProviderIds")?.text("TmdbPosterPath")?.takeIf { it.isNotBlank() } ?: remote?.text("posterPath")
            card.mainImageView.load(url = entry.local?.itemImages?.get(ImageType.PRIMARY)?.getUrl(api, maxWidth = 342)
                ?: poster?.takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w342$it" })
            card.setOnClickListener {
                state.nativePosition = currentCards.indexOf(entry).coerceAtLeast(0)
                state.focusedId = entry.local?.id?.toString() ?: remote.toString()
                if (entry.local != null) libraryOpen(entry.local) else remote?.let { open(it) }
            }
            card.setOnKeyListener { _, key, event ->
                if (event.action != KeyEvent.ACTION_DOWN) false else {
                    val index = currentCards.indexOf(entry).coerceAtLeast(0)
                    val parent = gridHolder[0]
                    when (key) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            if (event.repeatCount == 0) {
                                if (index % 4 == 0) (card.context as? MainActivity)?.openCinemaSidebar()
                                else parent?.setSelectedPosition(index - 1)
                            }; true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            if (event.repeatCount == 0 && index % 4 != 3 && index < currentCards.lastIndex) parent?.setSelectedPosition(index + 1)
                            true
                        }
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            if (event.repeatCount == 0) { if (index < 4) top() else parent?.setSelectedPosition(index - 4) }; true
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (event.repeatCount == 0 && (index / 4 + 1) * 4 < currentCards.size) parent?.setSelectedPosition((index + 4).coerceAtMost(currentCards.lastIndex))
                            true
                        }
                        else -> false
                    }
                }
            }
        }
        override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null); holder.view.setOnKeyListener(null) }
    } }
    val objects = remember(presenter) { ArrayObjectAdapter(presenter) }
    AndroidView(modifier = modifier, factory = { context ->
        VerticalGridView(context).apply {
            gridHolder[0] = this
            setNumColumns(4); setColumnWidth(0)
            val density = resources.displayMetrics.density
            setPadding((18*density).toInt(), (18*density).toInt(), (18*density).toInt(), (18*density).toInt())
            setHorizontalSpacing((18*density).toInt()); setVerticalSpacing((24*density).toInt())
            clipChildren = false; clipToPadding = false
            setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ITEM)
            windowAlignment = BaseGridView.WINDOW_ALIGN_BOTH_EDGE
            val bridge = ItemBridgeAdapter(objects)
            FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
            adapter = bridge
            setOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
                override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                    if (hasFocus() && position in currentCards.indices) state.nativePosition = position
                }
            })
        }
    }, update = { grid ->
        if (grid.tag != cards) {
            grid.tag = cards
            // Appending a page does not rebind or reposition the cards already on screen.
            if (objects.size() <= cards.size && (0 until objects.size()).all { objects[it] == cards[it] }) {
                objects.addAll(objects.size(), cards.drop(objects.size()))
            } else { objects.clear(); objects.addAll(0, cards); grid.setSelectedPosition(state.nativePosition.coerceIn(0, cards.lastIndex.coerceAtLeast(0))) }
        }
        if ((enter || state.restoreFocus) && cards.isNotEmpty()) {
            grid.setSelectedPosition(if (enter) 0 else state.nativePosition.coerceIn(0, cards.lastIndex))
            state.restoreFocus = false
            grid.post { grid.requestFocus() }
            onEntered()
        }
    })
}
