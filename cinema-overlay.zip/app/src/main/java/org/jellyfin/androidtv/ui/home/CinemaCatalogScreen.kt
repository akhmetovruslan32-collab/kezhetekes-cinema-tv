package org.jellyfin.androidtv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloatAsState
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.key.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.auth.repository.ServerRepository
import org.jellyfin.androidtv.auth.repository.SessionRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.ui.search.composable.SearchTextInput
import org.json.JSONObject
import org.koin.compose.koinInject
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CinemaCatalogScreen(state: CinemaCatalogState, openSearch: Boolean = false, searchOnly: Boolean = false, onBack: () -> Unit) {
	val context = androidx.compose.ui.platform.LocalContext.current
    val history = remember { context.getSharedPreferences("cinema-search", 0) }
    var recentQueries by remember { mutableStateOf(history.getString("queries", "").orEmpty().split("\n").filter { it.isNotBlank() }) }
	val server = koinInject<ServerRepository>().currentServer.value
	val session = koinInject<SessionRepository>().currentSession.value
	val client = koinInject<ApiClient>()
	val serverAddress = client.baseUrl ?: server?.address
	val accessToken = client.accessToken ?: session?.accessToken
	val api = remember(serverAddress, accessToken) {
		if (serverAddress == null || accessToken == null) null else CinemaCatalogApi(serverAddress, accessToken)
	}
	var tab by state::tab
	val listState = state.scroll
	val searchFocus = remember { FocusRequester() }
	val keyboard = LocalSoftwareKeyboardController.current
	var searchVisible by state::searchVisible
	LaunchedEffect(openSearch) { if (openSearch) searchVisible = true }
	LaunchedEffect(searchVisible) { if (searchVisible && state.selected == null && !state.restoreFocus && state.submittedQuery.isBlank()) { searchFocus.requestFocus() } }
	var revision by remember { mutableIntStateOf(0) }
	var response by state::response
	var entries by state::entries
	var loading by remember { mutableStateOf(false) }
	var error by remember { mutableStateOf(false) }
	var errorDetail by remember { mutableStateOf("") }
	var selected by state::selected
	var query by state::query
	var submittedQuery by state::submittedQuery
	var libraryMatches by state::libraryMatches
	fun submit() {
        submittedQuery = query.trim()
        if (submittedQuery.isNotBlank()) {
            recentQueries = (listOf(submittedQuery) + recentQueries).distinct().take(12)
            history.edit().putString("queries", recentQueries.joinToString("\n")).apply()
        }
        keyboard?.hide()
    }
    val navigation = koinInject<NavigationRepository>()
    var enterPending by remember { mutableStateOf(false) }
    var filtersVisible by remember { mutableStateOf(false) }
    val overview = !searchOnly && tab != "requests" && submittedQuery.isBlank() && state.browsePath == null && state.filterQuery == null
    fun resetBrowse() { state.browsePath = null; state.filterQuery = null; submittedQuery = ""; state.restoreFocus = false }
    fun backBrowse() { if (state.browsePath != null || state.filterQuery != null) { resetBrowse(); state.restoreFocus = true } else onBack() }
    val headerFocus = remember { FocusRequester() }
    val enterResults = Modifier.onPreviewKeyEvent { event ->
        if (event.type == KeyEventType.KeyDown && event.key == Key.DirectionDown && (overview || libraryMatches.isNotEmpty() || entries.isNotEmpty())) {
            keyboard?.hide()
            enterPending = true
            true
        } else false
    }

	LaunchedEffect(submittedQuery) {
		libraryMatches = emptyList()
		if (submittedQuery.isNotBlank()) try {
			libraryMatches = withContext(Dispatchers.IO) { client.itemsApi.getItems(searchTerm = submittedQuery,
				fields = org.jellyfin.androidtv.data.repository.ItemRepository.browseFields + setOf(org.jellyfin.sdk.model.api.ItemFields.PROVIDER_IDS, org.jellyfin.sdk.model.api.ItemFields.TAGS), recursive = true, includeItemTypes = setOf(BaseItemKind.MOVIE, BaseItemKind.SERIES), limit = 24).content.items }
		} catch (failure: CancellationException) { throw failure } catch (_: Exception) { }
	}
	BackHandler { if (selected != null) { selected = null; state.restoreFocus = true } else backBrowse() }
	LaunchedEffect(api, tab, revision, submittedQuery, state.browsePath, state.filterQuery) {
        if (overview) { loading = false; error = false; return@LaunchedEffect }
		if (searchOnly && submittedQuery.isBlank()) { response = null; entries = emptyList(); loading = false; return@LaunchedEffect }
        val loadKey = "$tab:$submittedQuery:$revision:${state.browsePath}:${state.filterQuery}"
        if (state.loadedKey != loadKey) {
            state.loadedKey = loadKey; response = null; entries = emptyList()
            state.nextPage = 0; state.hasMore = true; state.nativePosition = 0
        } else {
            if (!state.hasMore) return@LaunchedEffect
            if (entries.isNotEmpty()) snapshotFlow { selected == null && state.nativePosition >= libraryMatches.size + entries.size - 8 }.first { it }
        }
        error = false; errorDetail = ""
        var page = state.nextPage
		do {
		loading = true
		try {
			check(api != null)
			val result = api.get(when {
				submittedQuery.isNotBlank() -> "search?query=${java.net.URLEncoder.encode(submittedQuery, "UTF-8")}&startIndex=${page * 24}&limit=24"
				tab == "requests" -> "requests?take=24&skip=${page * 24}"
                state.filterQuery != null -> "discover/filtered/$tab?${state.filterQuery}&page=${page + 1}"
                state.browsePath != null -> "${state.browsePath}?startIndex=${page * 24}&limit=24"
				else -> "discover/${if (tab == "movie") "movies" else "tv"}/trending?startIndex=${page * 24}&limit=24"
			})
			response = result
			val batch = result.entries("Items", "items", "Results", "results", "requests")
			val previousCount = entries.size
			entries = (entries + batch).distinctBy { it.toString() }
			val total = result.optInt("TotalRecordCount", result.optInt("totalRecordCount", 0))
			val more = if (state.filterQuery != null && submittedQuery.isBlank()) page + 1 < result.optInt("totalPages", 1) else if (tab == "requests" && submittedQuery.isBlank()) page + 1 < result.optInt("totalPages", 1) else if (total > 0) (page + 1) * 24 < total else batch.size >= 24
			state.hasMore = more && batch.isNotEmpty() && entries.size > previousCount
            state.nextPage = page + 1
            loading = false
			if (!more || batch.isEmpty() || entries.size == previousCount) break
			snapshotFlow { selected == null && state.nativePosition >= libraryMatches.size + entries.size - 8 }.first { it }
			page++
		} catch (failure: CancellationException) { throw failure }
		catch (failure: Exception) {
			error = true
			errorDetail = when (failure) {
				is java.net.SocketTimeoutException -> "Сервер каталога не ответил вовремя."
				is java.net.ConnectException -> "Не удалось подключиться к серверу Jellyfin."
				is org.json.JSONException -> "Сервер вернул ответ в неожиданном формате."
				else -> failure.message?.takeIf { it.startsWith("HTTP ") } ?: "Проверьте вход и доступ к каталогу на выбранном сервере."
			}
		}
		finally { loading = false }
		} while (!error)
	}
	val chosen = selected
	if (chosen != null && api != null) {
		CinemaCatalogDetails(chosen, tab, api, { selected = null; state.restoreFocus = true }, { revision++ })
		return
	}
    LaunchedEffect(Unit) {
        if (!searchOnly && !state.initialHeaderFocusAssigned) {
            state.initialHeaderFocusAssigned = true
            withFrameNanos { }
            headerFocus.requestFocus()
        }
    }
	Column(Modifier.fillMaxSize().background(Color.Black).padding(28.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
		if (!searchOnly) LazyRow(enterResults.cinemaSidebarNavigation(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
			item { Button(modifier = enterResults.focusRequester(headerFocus), onClick = { tab = "movie"; resetBrowse() }) { Text(stringResource(R.string.cinema_catalog_movies)) } }
			item { Button(modifier = enterResults, onClick = { tab = "tv"; resetBrowse() }) { Text(stringResource(R.string.cinema_catalog_series)) } }
			item { Button(modifier = enterResults, onClick = { tab = "requests"; resetBrowse() }) { Text(stringResource(R.string.cinema_requests)) } }
			if (tab != "requests") item { Button(modifier = enterResults, onClick = { filtersVisible = true }) { Text("Фильтры") } }
            if (state.browsePath != null || state.filterQuery != null) item { Button(modifier = enterResults, onClick = { backBrowse() }) { Text("Назад к подборкам") } }
            item { CinemaIconButton(R.drawable.ic_search, "Глобальный поиск", modifier = enterResults) { if (searchVisible) { searchFocus.requestFocus() } else searchVisible = true } }
		}
		if (searchVisible) Row(enterResults.cinemaSidebarNavigation(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
			SearchTextInput(query, { query = it }, { submit() }, Modifier.weight(1f).focusRequester(searchFocus), autoOpenOnFocus = submittedQuery.isBlank())
			CinemaIconButton(R.drawable.ic_search, "Найти") { submit() }
		}
        if (overview && api != null) {
            CinemaCatalogOverview(state, api, Modifier.weight(1f).fillMaxWidth(), enterPending,
                { enterPending = false }, { headerFocus.requestFocus() }, { selected = it }, { title, path ->
                    state.browseTitle = title; state.browsePath = path; state.restoreFocus = true
                })
        } else if (searchOnly && submittedQuery.isBlank()) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (recentQueries.isNotEmpty()) item { Text("Недавние поиски", fontSize = 22.sp) }
                items(recentQueries) { previous -> Button(onClick = { query = previous; submit() }) { Text(previous) } }
            }
        } else {
            if (error) {
                Text(stringResource(R.string.cinema_catalog_error))
                Text(errorDetail, color = Color(0xFFFFD48A))
                Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
            }
            if (loading) Text(stringResource(R.string.loading))
            if (response != null && entries.isEmpty() && libraryMatches.isEmpty() && !loading) Text(stringResource(R.string.cinema_catalog_empty))
            CinemaNativeCatalogGrid(state, client, Modifier.weight(1f).fillMaxWidth(), enterPending,
                onEntered = { enterPending = false },
                onTop = { if (searchVisible) searchFocus.requestFocus() else headerFocus.requestFocus() },
                onOpen = { selected = it },
                onLibraryOpen = { state.restoreFocus = true; navigation.navigate(Destinations.itemDetails(it.id)) })
        }

    }
    if (filtersVisible && api != null) CinemaCatalogFilters(api, tab, state.filterQuery, { filtersVisible = false }, { value ->
        filtersVisible = false; submittedQuery = ""; state.browsePath = null; state.filterQuery = value
        state.restoreFocus = true
    })
}

@Composable
private fun CinemaCatalogDetails(entry: JSONObject, fallbackType: String, api: CinemaCatalogApi, onBack: () -> Unit, onChanged: () -> Unit) {
	val type = entry.text("SourceType", "sourceType", "mediaType", "MediaType", "type").lowercase(java.util.Locale.ROOT).let { if (it == "tv" || it == "series") "tv" else if (it == "movie") "movie" else if (fallbackType == "tv") "tv" else "movie" }
	val ids = entry.optJSONObject("ProviderIds") ?: entry.optJSONObject("providerIds")
	val id = ids?.text("Tmdb", "tmdb", "Jellyseerr")?.toIntOrNull() ?: entry.optInt("tmdbId", entry.optInt("Id", entry.optInt("id")))
	val scope = rememberCoroutineScope()
	val navigation = koinInject<NavigationRepository>()
	var details by remember(id, type) { mutableStateOf<JSONObject?>(null) }
	var options by remember(id, type) { mutableStateOf<JSONObject?>(null) }
	var option by remember(id, type) { mutableStateOf<JSONObject?>(null) }
	var seasons by remember(id, type) { mutableStateOf(setOf<Int>()) }
	var error by remember(id, type) { mutableStateOf(false) }
	var busy by remember(id, type) { mutableStateOf(false) }
	var requested by remember(id, type) { mutableStateOf(false) }
	var revision by remember { mutableIntStateOf(0) }
	LaunchedEffect(id, type, revision) {
		error = false
		try {
			check(id > 0)
			details = api.get("details/$type/$id")
			options = api.get("request-options/$type")
			val profiles = options?.entries("options", "Options").orEmpty()
			option = profiles.firstOrNull { it.optBoolean("isDefault", it.optBoolean("IsDefault")) && !it.optBoolean("is4k", it.optBoolean("Is4k")) } ?: profiles.firstOrNull { !it.optBoolean("is4k", it.optBoolean("Is4k")) }
		} catch (failure: CancellationException) { throw failure }
		catch (_: Exception) { error = true }
	}
	LazyColumn(Modifier.cinemaSidebarNavigation().fillMaxSize().background(Color.Black), contentPadding = PaddingValues(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
		item { Text(details?.text("title", "name", "Title", "Name")?.takeIf { it.isNotEmpty() } ?: entry.text("Name", "title"), fontSize = 28.sp) }
		item { Text(details?.text("overview", "Overview").orEmpty()) }
		if (error) item { Column {
			Text(stringResource(R.string.cinema_request_error))
			Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
		} }
		val settings = options
		val profiles = settings?.entries("options", "Options").orEmpty()
		val chosen4k = option?.optBoolean("is4k", option?.optBoolean("Is4k") ?: false) == true
		val allowed = if (chosen4k) settings?.optBoolean("canRequest4k", settings.optBoolean("CanRequest4k")) == true else settings?.optBoolean("canRequest", settings.optBoolean("CanRequest")) == true
		val media = details?.optJSONObject("mediaInfo")
		val status = media?.optInt(if (chosen4k) "status4k" else "status", 1) ?: 1
		val jellyfinId = media?.text("jellyfinItemId")?.let { runCatching { java.util.UUID.fromString(it) }.getOrNull() }
		if (jellyfinId != null) item { Button(onClick = { navigation.navigate(Destinations.itemDetails(jellyfinId)) }) { Text(stringResource(R.string.cinema_open_library)) } }
		if (status in 2..6) item { Text(stringResource(when (status) {
			2 -> R.string.cinema_status_pending
			3 -> R.string.cinema_status_processing
			4 -> R.string.cinema_status_partial
			5 -> R.string.cinema_status_available
			else -> R.string.cinema_status_blocked
		})) }
		items(profiles) { profile ->
			val is4k = profile.optBoolean("is4k", profile.optBoolean("Is4k"))
			val permitted = if (is4k) settings?.optBoolean("canRequest4k", settings.optBoolean("CanRequest4k")) == true else settings?.optBoolean("canRequest", settings.optBoolean("CanRequest")) == true
			Button(enabled = permitted && !busy, onClick = { option = profile; seasons = emptySet() }) { Text((if (profile === option) "✓ " else "") + profile.text("profileName", "ProfileName") + if (is4k) " · 4K" else "") }
		}
		if (type == "tv") items(details?.entries("seasons", "Seasons").orEmpty().filter { it.optInt("seasonNumber", it.optInt("SeasonNumber")) > 0 && it.optInt("episodeCount", 1) > 0 }) { season ->
			val number = season.optInt("seasonNumber", season.optInt("SeasonNumber"))
			val seasonStatus = media?.entries("seasons")?.firstOrNull { it.optInt("seasonNumber") == number }?.optInt(if (chosen4k) "status4k" else "status", 1) ?: 1
			Button(enabled = !busy && seasonStatus !in 2..6, onClick = { seasons = if (number in seasons) seasons - number else seasons + number }) { Text((if (number in seasons || seasonStatus in 2..6) "✓ " else "") + stringResource(R.string.cinema_season, number)) }
		}
		item {
			if (requested) Text(stringResource(R.string.cinema_request_sent))
			else Button(enabled = allowed && option != null && !busy && !error && status != 6 && (if (type == "tv") seasons.isNotEmpty() else status !in listOf(2, 3, 5)), onClick = {
				scope.launch {
					busy = true
					try { api.request(type, id, checkNotNull(option), seasons.sorted()); requested = true; onChanged() }
					catch (failure: CancellationException) { throw failure }
					catch (_: Exception) { error = true }
					finally { busy = false }
				}
			}) { Text(stringResource(R.string.cinema_request)) }
		}
	}
}

