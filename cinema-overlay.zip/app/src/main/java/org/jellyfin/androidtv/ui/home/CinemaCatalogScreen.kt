package org.jellyfin.androidtv.ui.home

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloatAsState
import kotlinx.coroutines.flow.first
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.auth.repository.ServerRepository
import org.jellyfin.androidtv.auth.repository.SessionRepository
import org.jellyfin.androidtv.ui.base.Text
import org.jellyfin.androidtv.ui.base.button.Button
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.ui.search.composable.SearchTextInput
import org.json.JSONObject
import org.koin.compose.koinInject
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.itemsApi
import org.jellyfin.sdk.model.api.BaseItemDto
import org.jellyfin.sdk.model.api.BaseItemKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun CinemaCatalogScreen(openSearch: Boolean = false, onBack: () -> Unit) {
	val server = koinInject<ServerRepository>().currentServer.value
	val session = koinInject<SessionRepository>().currentSession.value
	val client = koinInject<ApiClient>()
	val serverAddress = client.baseUrl ?: server?.address
	val accessToken = client.accessToken ?: session?.accessToken
	val api = remember(serverAddress, accessToken) {
		if (serverAddress == null || accessToken == null) null else CinemaCatalogApi(serverAddress, accessToken)
	}
	var tab by remember { mutableStateOf("movie") }
	val listState = rememberLazyListState()
	val searchFocus = remember { FocusRequester() }
	val keyboard = LocalSoftwareKeyboardController.current
	var searchVisible by remember { mutableStateOf(openSearch) }
	LaunchedEffect(searchVisible) { if (searchVisible) { searchFocus.requestFocus(); keyboard?.show() } }
	var revision by remember { mutableIntStateOf(0) }
	var response by remember { mutableStateOf<JSONObject?>(null) }
	var entries by remember { mutableStateOf<List<JSONObject>>(emptyList()) }
	var loading by remember { mutableStateOf(false) }
	var error by remember { mutableStateOf(false) }
	var errorDetail by remember { mutableStateOf("") }
	var selected by remember { mutableStateOf<JSONObject?>(null) }
	var query by remember { mutableStateOf("") }
	var submittedQuery by remember { mutableStateOf("") }
	var libraryMatches by remember { mutableStateOf<List<BaseItemDto>>(emptyList()) }
	val navigation = koinInject<NavigationRepository>()
	LaunchedEffect(submittedQuery) {
		libraryMatches = emptyList()
		if (submittedQuery.isNotBlank()) try {
			libraryMatches = withContext(Dispatchers.IO) { client.itemsApi.getItems(searchTerm = submittedQuery,
				recursive = true, includeItemTypes = setOf(BaseItemKind.MOVIE, BaseItemKind.SERIES), limit = 24).content.items }
		} catch (failure: CancellationException) { throw failure } catch (_: Exception) { }
	}
	BackHandler { if (selected != null) selected = null else onBack() }
	LaunchedEffect(api, tab, revision, submittedQuery) {
		response = null; entries = emptyList(); error = false; errorDetail = ""
		listState.scrollToItem(0)
		var page = 0
		do {
		loading = true
		try {
			check(api != null)
			val result = api.get(when {
				submittedQuery.isNotBlank() -> "search?query=${java.net.URLEncoder.encode(submittedQuery, "UTF-8")}&startIndex=${page * 24}&limit=24"
				tab == "requests" -> "requests?take=24&skip=${page * 24}"
				else -> "discover/${if (tab == "movie") "movies" else "tv"}/trending?startIndex=${page * 24}&limit=24"
			})
			response = result
			val batch = result.entries("Items", "items", "Results", "results", "requests")
			val previousCount = entries.size
			entries = (entries + batch).distinctBy { it.toString() }
			val total = result.optInt("TotalRecordCount", result.optInt("totalRecordCount", 0))
			val more = if (tab == "requests" && submittedQuery.isBlank()) page + 1 < result.optInt("totalPages", 1) else if (total > 0) (page + 1) * 24 < total else batch.size >= 24
			loading = false
			if (!more || batch.isEmpty() || entries.size == previousCount) break
			snapshotFlow { val layout = listState.layoutInfo; selected == null && layout.totalItemsCount > 0 && (layout.visibleItemsInfo.lastOrNull()?.index ?: -1) >= layout.totalItemsCount - 2 }.first { it }
			page++
		} catch (failure: CancellationException) { throw failure }
		catch (failure: Exception) {
			error = true
			errorDetail = when (failure) {
				is java.net.SocketTimeoutException -> "Сервер каталога не ответил вовремя."
				is java.net.ConnectException -> "Не удалось подключиться к серверу Jellyfin."
				is org.json.JSONException -> "Сервер вернул ответ в неожиданном формате."
				else -> failure.message?.takeIf { it.startsWith("HTTP ") } ?: "Проверьте вход и доступ к каталогу на выбранном сервере."
			}
		}
		finally { loading = false }
		} while (!error)
	}
	val chosen = selected
	if (chosen != null && api != null) {
		CinemaCatalogDetails(chosen, tab, api, { selected = null }, { revision++ })
		return
	}
	LazyColumn(Modifier.cinemaSidebarNavigation().fillMaxSize().background(Color(0xFF080B0F)), state = listState, contentPadding = PaddingValues(28.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
		item { LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
			item { Button(onClick = { tab = "movie"; submittedQuery = "" }) { Text(stringResource(R.string.cinema_catalog_movies)) } }
			item { Button(onClick = { tab = "tv"; submittedQuery = "" }) { Text(stringResource(R.string.cinema_catalog_series)) } }
			item { Button(onClick = { tab = "requests"; submittedQuery = "" }) { Text(stringResource(R.string.cinema_requests)) } }
			item { CinemaIconButton(R.drawable.ic_search, "Глобальный поиск") { if (searchVisible) { searchFocus.requestFocus(); keyboard?.show() } else searchVisible = true } }
		} }
		if (searchVisible) item { Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
			SearchTextInput(query, { query = it }, { submittedQuery = query.trim(); keyboard?.hide() }, Modifier.weight(1f).focusRequester(searchFocus))
			CinemaIconButton(R.drawable.ic_search, "Найти") { submittedQuery = query.trim(); keyboard?.hide() }
		} }
		if (error) item { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
			Text(stringResource(R.string.cinema_catalog_error))
			Text(errorDetail, color = Color(0xFFFFD48A))
			Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
		} }
		if (libraryMatches.isNotEmpty()) {
			item { Text("На вашем сервере", fontSize = 22.sp) }
			item { LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
				items(libraryMatches, key = { it.id }) { item -> CinemaCard(item, client, false, null) { navigation.navigate(Destinations.itemDetails(item.id)) } }
			} }
		}
		if (submittedQuery.isNotBlank()) item { Text("Глобальный каталог", fontSize = 22.sp) }
		val result = response
		if (result == null && !error) item { Text(stringResource(R.string.loading)) }
		if (result != null && entries.isEmpty()) item { Text(stringResource(R.string.cinema_catalog_empty)) }
		items(entries.chunked(5)) { row ->
			Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
				for (entry in row) {
					val interaction = remember { MutableInteractionSource() }
					val focused by interaction.collectIsFocusedAsState()
					val scale by animateFloatAsState(if (focused) 1.045f else 1f, label = "catalog-card-focus")
					Column(Modifier.width(162.dp).padding(5.dp)) {
					val title = entry.text("Name", "name", "title", "OriginalTitle")
					val path = entry.optJSONObject("ProviderIds")?.text("TmdbPosterPath") ?: entry.text("posterPath")
					Button(onClick = { selected = entry }, modifier = Modifier.border(3.dp, if (focused) Color(0xFFE2B65B) else Color.Transparent, RoundedCornerShape(8.dp)), interactionSource = interaction, shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(0.dp)) {
						AsyncImage(path.takeIf { it.isNotBlank() }?.let { "https://image.tmdb.org/t/p/w342$it" }, title, Modifier.width(154.dp).height(231.dp).background(Color(0xFF20242C)), contentScale = ContentScale.Crop)
					}
					Text(title, color = if (focused) Color(0xFFE2B65B) else Color.White, maxLines = 2, fontSize = 15.sp)
					if (tab == "requests") Text(entry.text("mediaStatusLabel", "statusLabel"), maxLines = 2, fontSize = 13.sp)
				}
				}
			}
		}
		if (loading && entries.isNotEmpty()) item { Text(stringResource(R.string.loading)) }
	}
}

@Composable
private fun CinemaCatalogDetails(entry: JSONObject, fallbackType: String, api: CinemaCatalogApi, onBack: () -> Unit, onChanged: () -> Unit) {
	val type = entry.text("SourceType", "sourceType", "mediaType", "MediaType", "type").lowercase(java.util.Locale.ROOT).let { if (it == "tv" || it == "series") "tv" else if (it == "movie") "movie" else if (fallbackType == "tv") "tv" else "movie" }
	val ids = entry.optJSONObject("ProviderIds") ?: entry.optJSONObject("providerIds")
	val id = ids?.text("Tmdb", "tmdb", "Jellyseerr")?.toIntOrNull() ?: entry.optInt("tmdbId", entry.optInt("Id", entry.optInt("id")))
	val scope = rememberCoroutineScope()
	val navigation = koinInject<NavigationRepository>()
	var details by remember(id, type) { mutableStateOf<JSONObject?>(null) }
	var options by remember(id, type) { mutableStateOf<JSONObject?>(null) }
	var option by remember(id, type) { mutableStateOf<JSONObject?>(null) }
	var seasons by remember(id, type) { mutableStateOf(setOf<Int>()) }
	var error by remember(id, type) { mutableStateOf(false) }
	var busy by remember(id, type) { mutableStateOf(false) }
	var requested by remember(id, type) { mutableStateOf(false) }
	var revision by remember { mutableIntStateOf(0) }
	LaunchedEffect(id, type, revision) {
		error = false
		try {
			check(id > 0)
			details = api.get("details/$type/$id")
			options = api.get("request-options/$type")
			val profiles = options?.entries("options", "Options").orEmpty()
			option = profiles.firstOrNull { it.optBoolean("isDefault", it.optBoolean("IsDefault")) && !it.optBoolean("is4k", it.optBoolean("Is4k")) } ?: profiles.firstOrNull { !it.optBoolean("is4k", it.optBoolean("Is4k")) }
		} catch (failure: CancellationException) { throw failure }
		catch (_: Exception) { error = true }
	}
	LazyColumn(Modifier.cinemaSidebarNavigation().fillMaxSize().background(Color(0xFF080B0F)), contentPadding = PaddingValues(28.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
		item { Text(details?.text("title", "name", "Title", "Name")?.takeIf { it.isNotEmpty() } ?: entry.text("Name", "title"), fontSize = 28.sp) }
		item { Text(details?.text("overview", "Overview").orEmpty()) }
		if (error) item { Column {
			Text(stringResource(R.string.cinema_request_error))
			Button(onClick = { revision++ }) { Text(stringResource(R.string.cinema_retry)) }
		} }
		val settings = options
		val profiles = settings?.entries("options", "Options").orEmpty()
		val chosen4k = option?.optBoolean("is4k", option?.optBoolean("Is4k") ?: false) == true
		val allowed = if (chosen4k) settings?.optBoolean("canRequest4k", settings.optBoolean("CanRequest4k")) == true else settings?.optBoolean("canRequest", settings.optBoolean("CanRequest")) == true
		val media = details?.optJSONObject("mediaInfo")
		val status = media?.optInt(if (chosen4k) "status4k" else "status", 1) ?: 1
		val jellyfinId = media?.text("jellyfinItemId")?.let { runCatching { java.util.UUID.fromString(it) }.getOrNull() }
		if (jellyfinId != null) item { Button(onClick = { navigation.navigate(Destinations.itemDetails(jellyfinId)) }) { Text(stringResource(R.string.cinema_open_library)) } }
		if (status in 2..6) item { Text(stringResource(when (status) {
			2 -> R.string.cinema_status_pending
			3 -> R.string.cinema_status_processing
			4 -> R.string.cinema_status_partial
			5 -> R.string.cinema_status_available
			else -> R.string.cinema_status_blocked
		})) }
		items(profiles) { profile ->
			val is4k = profile.optBoolean("is4k", profile.optBoolean("Is4k"))
			val permitted = if (is4k) settings?.optBoolean("canRequest4k", settings.optBoolean("CanRequest4k")) == true else settings?.optBoolean("canRequest", settings.optBoolean("CanRequest")) == true
			Button(enabled = permitted && !busy, onClick = { option = profile; seasons = emptySet() }) { Text((if (profile === option) "✓ " else "") + profile.text("profileName", "ProfileName") + if (is4k) " · 4K" else "") }
		}
		if (type == "tv") items(details?.entries("seasons", "Seasons").orEmpty().filter { it.optInt("seasonNumber", it.optInt("SeasonNumber")) > 0 && it.optInt("episodeCount", 1) > 0 }) { season ->
			val number = season.optInt("seasonNumber", season.optInt("SeasonNumber"))
			val seasonStatus = media?.entries("seasons")?.firstOrNull { it.optInt("seasonNumber") == number }?.optInt(if (chosen4k) "status4k" else "status", 1) ?: 1
			Button(enabled = !busy && seasonStatus !in 2..6, onClick = { seasons = if (number in seasons) seasons - number else seasons + number }) { Text((if (number in seasons || seasonStatus in 2..6) "✓ " else "") + stringResource(R.string.cinema_season, number)) }
		}
		item {
			if (requested) Text(stringResource(R.string.cinema_request_sent))
			else Button(enabled = allowed && option != null && !busy && !error && status != 6 && (if (type == "tv") seasons.isNotEmpty() else status !in listOf(2, 3, 5)), onClick = {
				scope.launch {
					busy = true
					try { api.request(type, id, checkNotNull(option), seasons.sorted()); requested = true; onChanged() }
					catch (failure: CancellationException) { throw failure }
					catch (_: Exception) { error = true }
					finally { busy = false }
				}
			}) { Text(stringResource(R.string.cinema_request)) }
		}
	}
}
