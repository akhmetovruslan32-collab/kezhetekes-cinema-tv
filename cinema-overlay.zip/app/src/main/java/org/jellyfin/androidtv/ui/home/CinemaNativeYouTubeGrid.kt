package org.jellyfin.androidtv.ui.home

import android.view.ViewGroup
import android.view.KeyEvent
import android.widget.ImageView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import org.jellyfin.androidtv.ui.browsing.MainActivity
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.json.JSONObject

@Composable
internal fun CinemaNativeYouTubeGrid(state: CinemaYouTubeState, modifier: Modifier, enter: Boolean, onEntered: () -> Unit, onOpen: (JSONObject) -> Unit) {
    val open by rememberUpdatedState(onOpen)
    val entries by rememberUpdatedState(state.entries)
    val presenter = remember {
        object : Presenter() {
            override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(LegacyImageCardView(parent.context, true).apply {
                isFocusable = true; isFocusableInTouchMode = true
                cardType = BaseCardView.CARD_TYPE_INFO_UNDER
                infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS
            })
            override fun onBindViewHolder(holder: ViewHolder, item: Any) {
                val entry = item as JSONObject
                val card = holder.view as LegacyImageCardView
                val id = entry.text("videoId")
                val channel = id.isBlank()
                card.setMainImageDimensions(210, if (channel) 210 else 118, if (channel) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP)
                card.setTitleText(entry.text("title", "author"))
                card.setContentText(if (channel) "Канал" else entry.text("author"))
                val image = if (channel) entry.entries("authorThumbnails").lastOrNull()?.text("url") else "https://i.ytimg.com/vi/$id/hqdefault.jpg"
                card.mainImageView.load(url = image)
                card.setOnClickListener { state.focusedId = entry.text("videoId", "authorId"); state.nativePosition = entries.indexOf(entry).coerceAtLeast(0); open(entry) }
                card.setOnKeyListener { _, key, event ->
                    if (event.action != KeyEvent.ACTION_DOWN) false else {
                        val index = entries.indexOf(entry)
                        when {
                            key == KeyEvent.KEYCODE_DPAD_DOWN && index + 3 >= entries.size -> true
                            key == KeyEvent.KEYCODE_DPAD_LEFT && index % 3 == 0 -> { (card.context as? MainActivity)?.openCinemaSidebar(); true }
                            else -> false
                        }
                    }
                }
            }
            override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null); holder.view.setOnKeyListener(null) }
        }
    }
    val objects = remember { ArrayObjectAdapter(presenter) }
    AndroidView(modifier = modifier, factory = { context ->
        VerticalGridView(context).apply {
            setNumColumns(3)
            setColumnWidth((220 * resources.displayMetrics.density).toInt())
            setVerticalSpacing((22 * resources.displayMetrics.density).toInt())
            setHorizontalSpacing((12 * resources.displayMetrics.density).toInt())
            val inset = (12 * resources.displayMetrics.density).toInt()
            setPadding(inset, inset, inset, inset)
            clipChildren = false; clipToPadding = false
            windowAlignment = BaseGridView.WINDOW_ALIGN_NO_EDGE
            windowAlignmentOffsetPercent = 0f
            itemAlignmentOffsetPercent = 0f
            val bridge = ItemBridgeAdapter(objects)
            FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
            adapter = bridge
            setOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
                override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                    if (hasFocus() && position in entries.indices) { state.nativePosition = position; state.focusedId = entries[position].text("videoId", "authorId") }
                }
            })
        }
    }, update = { grid ->
        if (grid.tag != state.entries) {
            grid.tag = state.entries
            objects.clear(); objects.addAll(0, state.entries)
            grid.setSelectedPosition(state.nativePosition.coerceIn(0, (state.entries.size - 1).coerceAtLeast(0)))
        }
        if ((enter || state.restoreFocus) && state.entries.isNotEmpty()) {
            grid.setSelectedPosition(if (enter) 0 else state.nativePosition.coerceIn(0, state.entries.lastIndex))
            state.restoreFocus = false
            grid.post { grid.requestFocus() }
            onEntered()
        }
    })
}
