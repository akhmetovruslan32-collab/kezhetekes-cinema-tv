package org.jellyfin.androidtv.ui.home

import android.view.ViewGroup
import android.view.KeyEvent
import android.widget.ImageView
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.leanback.widget.*
import org.jellyfin.androidtv.ui.browsing.MainActivity
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.json.JSONObject

@Composable
internal fun CinemaNativeYouTubeGrid(state: CinemaYouTubeState, modifier: Modifier, enter: Boolean, onEntered: () -> Unit, publicUrl: String?, onTop: () -> Unit, onOpen: (JSONObject) -> Unit) {
    val open by rememberUpdatedState(onOpen)
    val top by rememberUpdatedState(onTop)
    val entries by rememberUpdatedState(state.entries)
    val imageBase by rememberUpdatedState(publicUrl)
    val gridHolder = remember { arrayOfNulls<VerticalGridView>(1) }
    val presenter = remember {
        object : Presenter() {
            override fun onCreateViewHolder(parent: ViewGroup): ViewHolder = ViewHolder(LegacyImageCardView(parent.context, true).apply {
                useCinemaTransparentInfo()
                isFocusable = true; isFocusableInTouchMode = true
                cardType = BaseCardView.CARD_TYPE_INFO_UNDER
                infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS
            })
            override fun onBindViewHolder(holder: ViewHolder, item: Any?) {
                val entry = item as JSONObject
                val card = holder.view as LegacyImageCardView
                val id = entry.text("videoId")
                val channel = id.isBlank()
                val grid = gridHolder[0]
                val density = card.resources.displayMetrics.density
                val width = if (grid != null && grid.width > 0) (((grid.width - grid.paddingLeft - grid.paddingRight) / density - 3 * 18) / 4 - 12).toInt().coerceAtLeast(100) else 164
                card.setMainImageDimensions(width, if (channel) width else width * 9 / 16, if (channel) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP)
                card.mainImageView.apply {
                    clipToOutline = channel
                    outlineProvider = if (channel) object : android.view.ViewOutlineProvider() {
                        override fun getOutline(view: android.view.View, outline: android.graphics.Outline) { outline.setOval(0, 0, view.width, view.height) }
                    } else android.view.ViewOutlineProvider.BACKGROUND
                }
                card.setTitleText(entry.text("title", "author"))
                card.setContentText(if (channel) "Канал" else entry.text("author"))
                val image = if (channel) entry.entries("authorThumbnails").lastOrNull()?.text("url") else imageBase?.takeIf { it.isNotBlank() }?.let { "${it.trimEnd('/')}/vi/$id/mqdefault.jpg" } ?: "https://i.ytimg.com/vi/$id/hqdefault.jpg"
                card.mainImageView.load(url = image)
                card.setOnClickListener { state.focusedId = entry.text("videoId", "authorId"); state.nativePosition = entries.indexOf(entry).coerceAtLeast(0); open(entry) }

            }
            override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null); holder.view.setOnKeyListener(null) }
        }
    }
    val objects = remember { ArrayObjectAdapter(presenter) }
    AndroidView(modifier = modifier, factory = { context ->
        VerticalGridView(context).apply {
            gridHolder[0] = this
            installCinemaGridKeys(4, { top() })
            setNumColumns(4)
            setColumnWidth(0)
            setVerticalSpacing((22 * resources.displayMetrics.density).toInt())
            setHorizontalSpacing((18 * resources.displayMetrics.density).toInt())
            val inset = (18 * resources.displayMetrics.density).toInt()
            setPadding(inset, inset, inset, inset)
            clipChildren = false; clipToPadding = false
            setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ITEM)
            windowAlignment = BaseGridView.WINDOW_ALIGN_BOTH_EDGE
            val bridge = ItemBridgeAdapter(objects)
            FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false)
            adapter = bridge
            setOnChildViewHolderSelectedListener(object : OnChildViewHolderSelectedListener() {
                override fun onChildViewHolderSelected(parent: androidx.recyclerview.widget.RecyclerView, child: androidx.recyclerview.widget.RecyclerView.ViewHolder?, position: Int, subposition: Int) {
                    if (hasFocus() && position in entries.indices) { state.nativePosition = position; state.focusedId = entries[position].text("videoId", "authorId") }
                }
            })
        }
    }, update = { grid ->
        if (grid.tag != (state.entries to publicUrl)) {
            grid.tag = state.entries to publicUrl
            if (objects.size() <= state.entries.size && (0 until objects.size()).all { objects[it] == state.entries[it] }) objects.addAll(objects.size(), state.entries.drop(objects.size()))
            else { objects.clear(); objects.addAll(0, state.entries) }
            grid.setSelectedPosition(state.nativePosition.coerceIn(0, (state.entries.size - 1).coerceAtLeast(0)))
        }
        if ((enter || state.restoreFocus) && state.entries.isNotEmpty()) {
            grid.focusCinemaItem(if (enter) 0 else state.nativePosition.coerceIn(0, state.entries.lastIndex))
            state.restoreFocus = false
            grid.post { grid.requestFocus() }
            onEntered()
        }
    })
}
