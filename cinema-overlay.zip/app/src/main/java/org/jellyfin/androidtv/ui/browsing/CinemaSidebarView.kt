package org.jellyfin.androidtv.ui.browsing

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.AttributeSet
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.os.bundleOf
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.home.HomeFragment
import org.jellyfin.androidtv.ui.navigation.Destinations
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.ui.navigation.fragmentDestination
import org.jellyfin.androidtv.ui.preference.PreferencesFragment
import org.jellyfin.androidtv.ui.preference.screen.UserPreferencesScreen
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.sdk.api.client.extensions.userViewsApi
import org.jellyfin.sdk.model.api.CollectionType
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/** Expands over the content; the content's reserved rail width never changes. */
class CinemaSidebarView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs), KoinComponent {
    private val api by inject<ApiClient>()
    private val gold = Color.rgb(226, 182, 91)
    private val rows = mutableListOf<LinearLayout>()
    private var selected = 1
    private var previousContentFocus: View? = null
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    init {
        orientation = VERTICAL
        setPadding(dp(8), dp(8), dp(8), dp(8))
        setBackgroundColor(Color.rgb(8, 11, 15))
        elevation = dp(16).toFloat()
        isFocusable = false
    }

    fun bind(activity: MainActivity, navigation: NavigationRepository) {
        addView(ImageView(context).apply {
            setImageResource(R.drawable.cinema_goat)
            scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "КӘҖӘТӘКӘС CINEMA"
        }, LayoutParams(LayoutParams.MATCH_PARENT, dp(44)))
        val entries = listOf(
            Triple("search", "Поиск", R.drawable.ic_search),
            Triple("home", "Главная", R.drawable.cinema_nav_home),
            Triple("movies", "Фильмы", R.drawable.ic_movie),
            Triple("series", "Сериалы", R.drawable.cinema_nav_series),
            Triple("catalog", "Каталог", R.drawable.ic_folder),
            Triple("youtube", "YouTube", R.drawable.cinema_nav_youtube),
            Triple("tv", "ТВ-каналы", R.drawable.ic_tv),
            Triple("settings", "Настройки", R.drawable.ic_settings)
        )
        entries.forEachIndexed { index, (section, title, resource) ->
            val row = LinearLayout(context).apply {
                id = View.generateViewId()
                orientation = HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isFocusable = true
                isClickable = true
                contentDescription = title
                setPadding(dp(12), 0, dp(8), 0)
                addView(ImageView(context).apply { setImageResource(resource) }, LayoutParams(dp(24), dp(24)))
                addView(TextView(context).apply {
                    text = title; textSize = 17f; isSingleLine = true
                    setPadding(dp(18), 0, 0, 0)
                    visibility = View.GONE
                }, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
                setOnFocusChangeListener { _, _ -> paintRows() }
                setOnKeyListener { _, key, event ->
                    if (event.action == KeyEvent.ACTION_DOWN && key == KeyEvent.KEYCODE_DPAD_RIGHT) {
                        if (previousContentFocus?.isAttachedToWindow == true) previousContentFocus?.requestFocus()
                        else activity.focusCinemaContent()
                        true
                    } else false
                }
                setOnClickListener {
                    selected = index
                    paintRows()
                    when (section) {
                        "settings" -> navigation.reset(fragmentDestination<PreferencesFragment>(
                            PreferencesFragment.EXTRA_SCREEN to UserPreferencesScreen::class.java.name,
                            PreferencesFragment.EXTRA_SCREEN_ARGS to bundleOf()
                        ), clearHistory = true)
                        "tv" -> activity.lifecycleScope.launch {
                            try {
                                val television = withContext(Dispatchers.IO) { api.userViewsApi.getUserViews().content.items.firstOrNull { it.collectionType == CollectionType.LIVETV } }
                                if (television != null) navigation.reset(Destinations.librarySmartScreen(television), clearHistory = true)
                                else android.widget.Toast.makeText(context, "На сервере нет библиотеки ТВ-каналов", android.widget.Toast.LENGTH_LONG).show()
                            } catch (error: CancellationException) { throw error }
                            catch (_: Exception) { android.widget.Toast.makeText(context, "Не удалось загрузить ТВ-каналы", android.widget.Toast.LENGTH_LONG).show() }
                        }
                        else -> navigation.reset(fragmentDestination<HomeFragment>("cinemaSection" to section), clearHistory = true)
                    }
                    // Wait for the new fragment to take focus; no stale view is retained.
                    previousContentFocus = null
                    activity.window.decorView.post { activity.focusCinemaContent() }
                }
            }
            rows += row
            addView(row, LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f).apply { topMargin = dp(4) })
        }
        rows.forEachIndexed { index, row ->
            row.nextFocusUpId = rows[(index - 1).coerceAtLeast(0)].id
            row.nextFocusDownId = rows[(index + 1).coerceAtMost(rows.lastIndex)].id
        }
        viewTreeObserver.addOnGlobalFocusChangeListener { old, new ->
            val inRail = new != null && rows.any { it === new }
            if (inRail && old != null && rows.none { it === old }) previousContentFocus = old
            val width = dp(if (inRail) 240 else 68)
            if (layoutParams.width != width) { layoutParams = layoutParams.apply { this.width = width } }
            rows.forEach { it.getChildAt(1).visibility = if (inRail) View.VISIBLE else View.GONE }
            paintRows()
        }
        paintRows()
    }

    fun focusSelected() { rows.getOrNull(selected)?.requestFocus() }

    private fun paintRows() {
        rows.forEachIndexed { index, row ->
            val focused = row.hasFocus()
            val active = index == selected
            row.background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(if (focused) gold else if (active) Color.rgb(61, 48, 24) else Color.TRANSPARENT)
                if (active && !focused) setStroke(dp(1), gold)
            }
            val color = if (focused) Color.BLACK else if (active) gold else Color.WHITE
            (row.getChildAt(0) as ImageView).setColorFilter(color)
            (row.getChildAt(1) as TextView).setTextColor(color)
            row.animate().scaleX(if (focused) 1.035f else 1f).scaleY(if (focused) 1.035f else 1f).setDuration(100).start()
        }
    }
}
