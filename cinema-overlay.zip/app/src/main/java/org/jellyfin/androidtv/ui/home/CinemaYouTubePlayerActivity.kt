package org.jellyfin.androidtv.ui.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity

/** Uses the exact Invidious embed source configured by the Jellyfin web plugin. */
class CinemaYouTubePlayerActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var fullscreen: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url").orEmpty()
        if (!(url.startsWith("http://") || url.startsWith("https://"))) { finish(); return }
        supportActionBar?.hide()
        root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = WebViewClient()
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    fullscreen?.let { callback.onCustomViewHidden(); return }
                    fullscreen = view; fullscreenCallback = callback
                    web.visibility = View.GONE
                    root.addView(view, FrameLayout.LayoutParams(-1, -1))
                    view.requestFocus()
                }
                override fun onHideCustomView() { hideFullscreen() }
            }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        web.loadUrl(url)
        web.requestFocus()
    }

    private fun hideFullscreen() {
        fullscreen?.let { root.removeView(it) }
        fullscreen = null; web.visibility = View.VISIBLE
        fullscreenCallback?.onCustomViewHidden(); fullscreenCallback = null
        web.requestFocus()
    }
    @Deprecated("Legacy Android TV back dispatch")
    override fun onBackPressed() { if (fullscreen != null) hideFullscreen() else super.onBackPressed() }
    override fun onPause() { if (::web.isInitialized) web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) web.onResume() }
    override fun onDestroy() { if (::web.isInitialized) { web.stopLoading(); root.removeAllViews(); web.destroy() }; super.onDestroy() }
}
