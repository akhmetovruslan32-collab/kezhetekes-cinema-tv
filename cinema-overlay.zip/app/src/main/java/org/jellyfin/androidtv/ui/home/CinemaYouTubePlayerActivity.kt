package org.jellyfin.androidtv.ui.home

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Button
import android.widget.TextView
import android.widget.SeekBar
import org.json.JSONObject
import org.json.JSONTokener
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject
import org.jellyfin.sdk.api.client.ApiClient
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.ui.navigation.fragmentDestination

/** Uses the exact Invidious embed source configured by the Jellyfin web plugin. */
class CinemaYouTubePlayerActivity : AppCompatActivity() {
    private val navigation by inject<NavigationRepository>()
    private val apiClient by inject<ApiClient>()
    private var channelId = ""
    private var channelName = ""
    private lateinit var channelButton: Button
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private var fullscreen: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private lateinit var controls: LinearLayout
    private lateinit var pause: Button
    private lateinit var progress: SeekBar
    private lateinit var time: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var paused = false
    private var userPaused = false
    private var duration = 0
    private var position = 0
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private val hide = Runnable { controls.visibility = View.GONE; web.requestFocus() }
    private val tick = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            web.evaluateJavascript("(function(){var v=document.querySelector('video');return v?JSON.stringify({p:v.currentTime,d:isFinite(v.duration)?v.duration:0,paused:v.paused}):null})()") { result ->
                try {
                    val decoded = JSONTokener(result).nextValue() as? String ?: return@evaluateJavascript
                    val data = JSONObject(decoded)
                    position = data.optDouble("p").toInt().coerceAtLeast(0)
                    duration = data.optDouble("d").toInt().coerceAtLeast(0)
                    paused = data.optBoolean("paused")
                    progress.max = duration.coerceAtLeast(1)
                    progress.progress = position
                    time.text = "${clock(position)} / ${clock(duration)}"
                    pause.text = if (paused) "Продолжить" else "Пауза"
                } catch (_: Exception) { }
            }
            handler.postDelayed(this, 1000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val url = intent.getStringExtra("url").orEmpty()
        if (!(url.startsWith("http://") || url.startsWith("https://"))) { finish(); return }
        channelId = intent.getStringExtra("channelId").orEmpty()
        channelName = intent.getStringExtra("channelName").orEmpty()
        supportActionBar?.hide()
        root = FrameLayout(this).apply { setBackgroundColor(android.graphics.Color.BLACK) }
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    // Invidious supplies the video; the TV panel owns all visible controls.
                    view.evaluateJavascript("""(function(){
                        if(!document.getElementById('cinema-tv-controls')){
                            var s=document.createElement('style');s.id='cinema-tv-controls';
                            s.textContent='.vjs-control-bar,.vjs-big-play-button,.vjs-text-track-settings{display:none!important}';
                            document.head.appendChild(s);
                        }
                        function bind(){var v=document.querySelector('video');if(v){v.controls=false;v.removeAttribute('controls');}}
                        bind();if(!window.cinemaTvObserver){window.cinemaTvObserver=new MutationObserver(bind);window.cinemaTvObserver.observe(document.body,{childList:true,subtree:true});}
                    })()""", null)
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    fullscreen?.let { callback.onCustomViewHidden(); return }
                    fullscreen = view; fullscreenCallback = callback
                    root.addView(view, 1, FrameLayout.LayoutParams(-1, -1))
                    controls.bringToFront()
                    showControls()
                }
                override fun onHideCustomView() { hideFullscreen() }
            }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        createControls()
        setContentView(root)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        web.loadUrl(url)
        showControls()
        if (channelId.isBlank()) lifecycleScope.launch {
            try {
                val id = intent.getStringExtra("videoId").orEmpty()
                if (id.isNotBlank()) {
                    val result = CinemaYouTubeApi(apiClient.baseUrl.orEmpty(), apiClient.accessToken.orEmpty()).get("Video/$id")
                    val details = (result as? JSONObject)?.normalizeYouTube()
                    channelId = details?.text("authorId").orEmpty()
                    channelName = details?.text("author").orEmpty()
                    channelButton.isEnabled = channelId.isNotBlank()
                }
            } catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { }
        }
    }

    private fun createControls() {
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(16), dp(28), dp(16))
            setBackgroundColor(0xE6000000.toInt())
        }
        controls.addView(TextView(this).apply {
            text = channelName; textSize = 20f; setTextColor(android.graphics.Color.WHITE)
        })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        fun action(label: String, callback: () -> Unit): Button = Button(this).apply {
            text = label; textSize = 18f
            setTextColor(android.graphics.Color.WHITE)
            setOnFocusChangeListener { _, focused -> setTextColor(if (focused) 0xFFE2B65B.toInt() else android.graphics.Color.WHITE) }
            setOnClickListener { callback(); showControls(false) }
            row.addView(this, LinearLayout.LayoutParams(dp(150), dp(58)))
        }
        action("−10 секунд") { seek(-10) }
        pause = action("Пауза") { togglePause() }
        action("+10 секунд") { seek(10) }
        channelButton = action("Канал") {
            if (channelId.isNotBlank()) {
                navigation.navigate(fragmentDestination<HomeFragment>("cinemaSection" to "youtube", "youtubeChannelId" to channelId, "youtubeChannelName" to channelName))
                finish()
            }
        }.apply { isEnabled = channelId.isNotBlank() }
        time = TextView(this).apply { textSize = 18f; setTextColor(android.graphics.Color.WHITE); setPadding(dp(24), 0, 0, 0) }
        row.addView(time)
        controls.addView(row)
        progress = SeekBar(this).apply {
            isFocusable = true
            setKeyProgressIncrement(10)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) { if (fromUser) { seekTo(value); showControls(false) } }
                override fun onStartTrackingTouch(bar: SeekBar) { handler.removeCallbacks(hide) }
                override fun onStopTrackingTouch(bar: SeekBar) { showControls(false) }
            })
        }
        controls.addView(progress, LinearLayout.LayoutParams(-1, dp(48)))
        controls.addView(TextView(this).apply { text = "ОК — управление · ← → — перемотка · Назад — вернуться"; textSize = 15f; setTextColor(android.graphics.Color.LTGRAY) })
        root.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    }
    private fun video(command: String) { web.evaluateJavascript("(function(){var v=document.querySelector('video');if(v){$command}})()", null) }
    private fun togglePause() { userPaused = !paused; video("if(v.paused){v.play()}else{v.pause()}") }
    private fun seek(delta: Int) { seekTo((position + delta).coerceAtLeast(0)) }
    private fun seekTo(seconds: Int) { val target = if (duration > 0) seconds.coerceIn(0, duration) else seconds.coerceAtLeast(0); video("v.currentTime=$target"); position = target }
    private fun showControls(focus: Boolean = true) {
        controls.visibility = View.VISIBLE; controls.bringToFront()
        if (focus) pause.requestFocus()
        handler.removeCallbacks(hide); handler.postDelayed(hide, 8000)
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePause(); showControls(); return true }
                KeyEvent.KEYCODE_MEDIA_PLAY -> { userPaused = false; video("v.play()"); showControls(); return true }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> { userPaused = true; video("v.pause()"); showControls(); return true }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { seek(-10); showControls(); return true }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seek(10); showControls(); return true }
                KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (controls.visibility != View.VISIBLE) { seek(if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) -10 else 10); showControls(); return true }
                    showControls(false)
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (controls.visibility != View.VISIBLE) { showControls(); return true }
                    showControls(false)
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }
    private fun clock(value: Int): String = if (value >= 3600) "%d:%02d:%02d".format(value/3600, value/60%60, value%60) else "%d:%02d".format(value/60, value%60)

    private fun hideFullscreen() {
        fullscreen?.let { root.removeView(it) }
        fullscreen = null; web.visibility = View.VISIBLE
        fullscreenCallback?.onCustomViewHidden(); fullscreenCallback = null
        web.requestFocus()
    }
    @Deprecated("Legacy Android TV back dispatch")
    override fun onBackPressed() {
        if (controls.visibility == View.VISIBLE) { handler.removeCallbacks(hide); hide.run() }
        else finish()
    }
    override fun onPause() { handler.removeCallbacksAndMessages(null); if (::web.isInitialized) { video("v.pause()"); web.onPause() }; super.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) { web.onResume(); if (!userPaused) video("v.play()"); handler.post(tick) } }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); if (::web.isInitialized) { web.stopLoading(); root.removeAllViews(); web.destroy() }; super.onDestroy() }
}
