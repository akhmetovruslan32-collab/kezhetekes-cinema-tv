package org.jellyfin.androidtv.ui.home

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.leanback.widget.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.jellyfin.androidtv.R
import org.jellyfin.androidtv.ui.card.LegacyImageCardView
import org.jellyfin.androidtv.ui.navigation.NavigationRepository
import org.jellyfin.androidtv.ui.navigation.fragmentDestination
import org.jellyfin.sdk.api.client.ApiClient
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.koin.android.ext.android.inject

/** Keep the deployed Invidious streaming engine, with one native TV control panel. */
class CinemaYouTubePlayerActivity : AppCompatActivity() {
    private val navigation by inject<NavigationRepository>()
    private val apiClient by inject<ApiClient>()
    private val gold = Color.rgb(226, 182, 91)
    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var controls: LinearLayout
    private lateinit var pause: ImageButton
    private lateinit var qualityButton: TextView
    private lateinit var channelButton: TextView
    private lateinit var progress: SeekBar
    private lateinit var time: TextView
    private lateinit var status: TextView
    private var fullscreen: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private var popup: Dialog? = null
    private var channelId = ""
    private var channelName = ""
    private var videoTitle = ""
    private var publicBase = ""
    private var videoId = ""
    private var paused = false
    private var userPaused = false
    private var position = 0
    private var duration = 0
    private var scrubPosition: Int? = null
    private var preferredQuality = 0
    private var qualityPending = false
    private var related = emptyList<JSONObject>()
    private var detailsLoading = true
    private val handler = Handler(Looper.getMainLooper())
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private val hide = Runnable {
        if (popup?.isShowing != true && scrubPosition == null) { controls.visibility = View.GONE; web.requestFocus() }
    }
    private val tick = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            web.evaluateJavascript("(function(){var v=document.querySelector('video');return v?JSON.stringify({p:v.currentTime,d:isFinite(v.duration)?v.duration:0,paused:v.paused,b:v.buffered.length?v.buffered.end(v.buffered.length-1):0,ready:v.readyState}):null})()") { result ->
                try {
                    val data = JSONObject(JSONTokener(result).nextValue() as? String ?: return@evaluateJavascript)
                    if (scrubPosition == null) position = data.optDouble("p").toInt().coerceAtLeast(0)
                    duration = data.optDouble("d").toInt().coerceAtLeast(0)
                    paused = data.optBoolean("paused")
                    progress.max = duration.coerceAtLeast(1)
                    if (scrubPosition == null) progress.progress = position
                    progress.secondaryProgress = data.optDouble("b").toInt().coerceIn(0, progress.max)
                    time.text = "${clock(scrubPosition ?: position)} / ${clock(duration)}"
                    pause.setImageResource(if (paused) R.drawable.ic_play else R.drawable.ic_pause)
                    pause.contentDescription = if (paused) "Продолжить" else "Пауза"
                    status.text = if (data.optInt("ready") < 3 && !paused) "Буферизация…" else ""
                } catch (_: Exception) { }
            }
            if (qualityPending && preferredQuality > 0) web.evaluateJavascript("!!(window.CinemaTV && CinemaTV.quality($preferredQuality))") {
                if (it == "true") qualityPending = false
            }
            handler.postDelayed(this, 1000)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val original = intent.getStringExtra("url").orEmpty()
        val uri = Uri.parse(original)
        if (uri.scheme !in listOf("http", "https") || uri.host.isNullOrBlank()) { finish(); return }
        publicBase = "${uri.scheme}://${uri.encodedAuthority}"
        videoId = intent.getStringExtra("videoId") ?: uri.lastPathSegment.orEmpty()
        channelId = intent.getStringExtra("channelId").orEmpty()
        channelName = intent.getStringExtra("channelName").orEmpty()
        videoTitle = intent.getStringExtra("title").orEmpty()
        preferredQuality = getSharedPreferences("cinema-youtube-player", 0).getInt("quality", 0)
        supportActionBar?.hide()
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        web = WebView(this).apply {
            setBackgroundColor(Color.BLACK)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String) {
                    view.evaluateJavascript(assets.open("cinema-youtube-player.js").bufferedReader().use { it.readText() }, null)
                    qualityPending = preferredQuality > 0
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    if (fullscreen != null) { callback.onCustomViewHidden(); return }
                    fullscreen = view; fullscreenCallback = callback
                    root.addView(view, 1, FrameLayout.LayoutParams(-1, -1))
                    showControls()
                }
                override fun onHideCustomView() {
                    fullscreen?.let { root.removeView(it) }; fullscreen = null
                    fullscreenCallback?.onCustomViewHidden(); fullscreenCallback = null
                    web.visibility = View.VISIBLE
                }
            }
        }
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        createControls()
        setContentView(root)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        // DASH exposes all available resolutions and audio/subtitle tracks to the TV panel.
        web.loadUrl("$publicBase/embed/${Uri.encode(videoId)}?autoplay=1&controls=0&quality=dash&quality_dash=auto&local=true")
        showControls()
        lifecycleScope.launch {
            try {
                val data = CinemaYouTubeApi(apiClient.baseUrl.orEmpty(), apiClient.accessToken.orEmpty()).get("Video/${Uri.encode(videoId)}") as? JSONObject
                val info = data?.normalizeYouTube()
                if (channelId.isBlank()) channelId = info?.text("authorId").orEmpty()
                channelButton.isEnabled = channelId.isNotBlank()
                related = info?.entries("recommendedVideos", "RecommendedVideos").orEmpty().map { it.normalizeYouTube() }.filter { it.text("videoId").isNotBlank() }
            } catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { }
            finally { detailsLoading = false }
        }
    }

    private fun focusStyle(view: View) {
        view.id = View.generateViewId(); view.isFocusable = true; view.isFocusableInTouchMode = true
        view.background = null
        view.setOnFocusChangeListener { _, focused ->
            val tint = if (focused) gold else Color.WHITE
            if (view is TextView) view.setTextColor(tint)
            if (view is ImageButton) view.imageTintList = ColorStateList.valueOf(tint)
            if (focused) showControls(false)
        }
    }
    private fun labelButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 18f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
        setPadding(dp(12), dp(10), dp(12), dp(10)); focusStyle(this)
        setOnClickListener { action(); showControls(false) }
    }
    private fun createControls() {
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(28), dp(20), dp(28), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x00000000, 0xEE000000.toInt(), Color.BLACK))
        }
        controls.addView(TextView(this).apply { text = videoTitle.ifBlank { channelName }; textSize = 25f; setTextColor(Color.WHITE); maxLines = 2 })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        fun icon(resource: Int, description: String, action: () -> Unit) = ImageButton(this).apply {
            setImageResource(resource); contentDescription = description
            setPadding(dp(16), dp(12), dp(16), dp(12)); imageTintList = ColorStateList.valueOf(Color.WHITE)
            focusStyle(this); setOnClickListener { action(); showControls(false) }
            row.addView(this, LinearLayout.LayoutParams(dp(64), dp(60)))
        }
        icon(R.drawable.ic_rewind, "Назад на 10 секунд") { seek(-10) }
        pause = icon(R.drawable.ic_pause, "Пауза") { togglePause() }
        icon(R.drawable.ic_fast_forward, "Вперёд на 10 секунд") { seek(10) }
        channelButton = labelButton("Канал") {
            if (channelId.isNotBlank()) {
                navigation.navigate(fragmentDestination<HomeFragment>("cinemaSection" to "youtube", "youtubeChannelId" to channelId, "youtubeChannelName" to channelName)); finish()
            }
        }.apply { isEnabled = channelId.isNotBlank() }
        row.addView(channelButton)
        time = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.END; setPadding(dp(12), 0, 0, 0) }
        row.addView(time, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(row)
        progress = SeekBar(this).apply {
            id = View.generateViewId(); isFocusable = true; setKeyProgressIncrement(1)
            progressTintList = ColorStateList.valueOf(gold); thumbTintList = ColorStateList.valueOf(gold)
            secondaryProgressTintList = ColorStateList.valueOf(Color.GRAY)
            setOnKeyListener { _, key, event ->
                when (key) {
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (event.action == KeyEvent.ACTION_DOWN) {
                            scrubPosition = ((scrubPosition ?: position) + if (key == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1).coerceIn(0, duration.coerceAtLeast(0))
                            this.progress = scrubPosition ?: position
                            time.text = "${clock(scrubPosition ?: position)} / ${clock(duration)}"
                            handler.removeCallbacks(hide)
                        } else if (event.action == KeyEvent.ACTION_UP) { scrubPosition?.let { seekTo(it) }; scrubPosition = null; showControls(false) }
                        true
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) showRelated(); true }
                    else -> false
                }
            }
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(bar: SeekBar, value: Int, fromUser: Boolean) { if (fromUser) seekTo(value) }
                override fun onStartTrackingTouch(bar: SeekBar) { handler.removeCallbacks(hide) }
                override fun onStopTrackingTouch(bar: SeekBar) { showControls(false) }
            })
        }
        controls.addView(progress, LinearLayout.LayoutParams(-1, dp(44)))
        val settings = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        qualityButton = labelButton(qualityLabel()) { showQuality() }
        settings.addView(qualityButton)
        settings.addView(labelButton("Скорость") { choices("Скорость воспроизведения", listOf("0.5×", "0.75×", "1×", "1.25×", "1.5×", "2×")) { i -> js("CinemaTV.speed(${listOf(.5, .75, 1.0, 1.25, 1.5, 2.0)[i]})") } })
        settings.addView(labelButton("Звук") { showTracks("audio") })
        settings.addView(labelButton("Субтитры") { showTracks("text") })
        settings.addView(labelButton("Похожие видео ↓") { showRelated() })
        controls.addView(settings)
        status = TextView(this).apply { textSize = 15f; setTextColor(Color.LTGRAY) }
        controls.addView(status)
        root.addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    }
    private fun qualityLabel() = "Качество: ${if (preferredQuality == 0) "Авто" else "${preferredQuality}p"}"
    private fun js(command: String) { web.evaluateJavascript("(function(){if(window.CinemaTV){$command}})()", null) }
    private fun showQuality() {
        web.evaluateJavascript("window.CinemaTV?JSON.stringify(CinemaTV.qualities()):null") { raw ->
            try {
                val values = JSONArray(JSONTokener(raw).nextValue() as? String ?: "[]")
                val heights = listOf(0) + (0 until values.length()).map { values.getInt(it) }
                if (heights.size == 1) { notice("Качества ещё загружаются. Попробуйте снова через несколько секунд."); return@evaluateJavascript }
                choices("Качество видео", heights.map { if (it == 0) "Авто" else "${it}p" }) { i ->
                    preferredQuality = heights[i]
                    getSharedPreferences("cinema-youtube-player", 0).edit().putInt("quality", preferredQuality).apply()
                    qualityButton.text = qualityLabel(); js("CinemaTV.quality($preferredQuality)")
                }
            } catch (_: Exception) { notice("Не удалось получить список качеств.") }
        }
    }
    private fun showTracks(kind: String) {
        web.evaluateJavascript("window.CinemaTV?JSON.stringify(CinemaTV.tracks('$kind')):null") { raw ->
            try {
                val list = JSONArray(JSONTokener(raw).nextValue() as? String ?: "[]")
                val tracks = (0 until list.length()).map { list.getJSONObject(it) }
                if (tracks.isEmpty()) { notice(if (kind == "audio") "У видео одна звуковая дорожка." else "У видео нет доступных субтитров."); return@evaluateJavascript }
                val labels = (if (kind == "text") listOf("Выключены") else emptyList()) + tracks.map { it.optString("label") }
                choices(if (kind == "audio") "Звуковая дорожка" else "Субтитры", labels) { i ->
                    val index = if (kind == "text" && i == 0) -1 else tracks[i - if (kind == "text") 1 else 0].optInt("index")
                    js("CinemaTV.track('$kind',$index)")
                }
            } catch (_: Exception) { notice("Дорожки ещё загружаются.") }
        }
    }
    private fun choices(title: String, labels: List<String>, onChoice: (Int) -> Unit) {
        handler.removeCallbacks(hide)
        val dialog = Dialog(this)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(16)); setBackgroundColor(Color.BLACK) }
        layout.addView(TextView(this).apply { text = title; textSize = 23f; setTextColor(Color.WHITE); setPadding(dp(12), 0, 0, dp(14)) })
        labels.forEachIndexed { i, label -> layout.addView(labelButton(label) { onChoice(i); dialog.dismiss() }, LinearLayout.LayoutParams(-1, dp(48))) }
        dialog.setContentView(layout); popup = dialog
        dialog.setOnDismissListener { popup = null; showControls(false) }
        dialog.show(); dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(dp(440), -2)
        layout.getChildAt(1)?.requestFocus()
    }
    private fun showRelated() {
        if (related.isEmpty()) { notice(if (detailsLoading) "Загрузка похожих видео…" else "Для этого видео сервер не вернул рекомендации."); return }
        handler.removeCallbacks(hide)
        val dialog = Dialog(this)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(16), dp(20), dp(16)); setBackgroundColor(Color.BLACK) }
        layout.addView(TextView(this).apply { text = "Похожие видео"; textSize = 23f; setTextColor(Color.WHITE) })
        val grid = HorizontalGridView(this).apply { setNumRows(1); setHorizontalSpacing(dp(20)); setPadding(dp(12), dp(12), dp(12), dp(12)); clipChildren = false; clipToPadding = false; setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ITEM) }
        val presenter = object : Presenter() {
            override fun onCreateViewHolder(parent: ViewGroup) = ViewHolder(LegacyImageCardView(this@CinemaYouTubePlayerActivity, true).apply { useCinemaTransparentInfo(); isFocusable = true; cardType = BaseCardView.CARD_TYPE_INFO_UNDER; infoVisibility = BaseCardView.CARD_REGION_VISIBLE_ALWAYS })
            override fun onBindViewHolder(holder: ViewHolder, item: Any?) {
                val entry = item as JSONObject; val card = holder.view as LegacyImageCardView
                card.setMainImageDimensions(200, 112); card.setTitleText(entry.text("title")); card.setContentText(entry.text("author"))
                card.mainImageView.load(url = "$publicBase/vi/${Uri.encode(entry.text("videoId"))}/mqdefault.jpg")
                card.setOnClickListener {
                    startActivity(Intent(this@CinemaYouTubePlayerActivity, CinemaYouTubePlayerActivity::class.java).putExtra("url", "$publicBase/embed/${Uri.encode(entry.text("videoId"))}").putExtra("videoId", entry.text("videoId")).putExtra("title", entry.text("title")).putExtra("channelId", entry.text("authorId")).putExtra("channelName", entry.text("author")))
                    dialog.dismiss(); finish()
                }
            }
            override fun onUnbindViewHolder(holder: ViewHolder) { holder.view.setOnClickListener(null) }
        }
        val objects = ArrayObjectAdapter(presenter).apply { addAll(0, related) }
        val bridge = ItemBridgeAdapter(objects); FocusHighlightHelper.setupBrowseItemFocusHighlight(bridge, FocusHighlight.ZOOM_FACTOR_MEDIUM, false); grid.adapter = bridge
        grid.setOnKeyInterceptListener { event ->
            if (event.keyCode == KeyEvent.KEYCODE_DPAD_UP) { if (event.action == KeyEvent.ACTION_DOWN) { dialog.dismiss(); progress.requestFocus() }; true }
            else if (event.keyCode == KeyEvent.KEYCODE_DPAD_DOWN) true else false
        }
        layout.addView(grid, LinearLayout.LayoutParams(-1, dp(225)))
        dialog.setContentView(layout); popup = dialog; dialog.setOnDismissListener { popup = null; showControls(false) }
        dialog.show(); dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.window?.setLayout(resources.displayMetrics.widthPixels - dp(48), -2); dialog.window?.setGravity(Gravity.BOTTOM)
        grid.requestFocus(); grid.focusCinemaItem(0)
    }
    private fun notice(text: String) { Toast.makeText(this, text, Toast.LENGTH_LONG).show(); showControls(false) }
    private fun video(command: String) { web.evaluateJavascript("(function(){var v=document.querySelector('video');if(v){$command}})()", null) }
    private fun togglePause() { userPaused = !paused; video("if(v.paused){v.play()}else{v.pause()}") }
    private fun seek(delta: Int) { seekTo((position + delta).coerceAtLeast(0)) }
    private fun seekTo(seconds: Int) { val target = if (duration > 0) seconds.coerceIn(0, duration) else seconds.coerceAtLeast(0); video("v.currentTime=$target"); position = target }
    private fun showControls(focus: Boolean = true) {
        if (!::controls.isInitialized) return
        controls.visibility = View.VISIBLE; controls.bringToFront()
        if (focus && ::pause.isInitialized) pause.requestFocus()
        handler.removeCallbacks(hide); handler.postDelayed(hide, 8000)
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) when (event.keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { togglePause(); showControls(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { userPaused = false; video("v.play()"); showControls(); return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { userPaused = true; video("v.pause()"); showControls(); return true }
            KeyEvent.KEYCODE_MEDIA_REWIND -> { seek(-10); showControls(); return true }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { seek(10); showControls(); return true }
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controls.visibility != View.VISIBLE) { seek(if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) -10 else 10); showControls(); return true }; showControls(false)
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controls.visibility != View.VISIBLE) { showControls(); return true }; showControls(false)
            }
        }
        return super.dispatchKeyEvent(event)
    }
    private fun clock(value: Int): String = if (value >= 3600) "%d:%02d:%02d".format(value/3600, value/60%60, value%60) else "%d:%02d".format(value/60, value%60)
    @Deprecated("Legacy Android TV back dispatch")
    override fun onBackPressed() { if (popup?.isShowing == true) popup?.dismiss() else if (controls.visibility == View.VISIBLE) { handler.removeCallbacks(hide); hide.run() } else finish() }
    override fun onPause() { handler.removeCallbacksAndMessages(null); if (::web.isInitialized) { video("v.pause()"); web.onPause() }; super.onPause() }
    override fun onResume() { super.onResume(); if (::web.isInitialized) { web.onResume(); if (!userPaused) video("v.play()"); handler.post(tick) } }
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); popup?.setOnDismissListener(null); popup?.dismiss(); if (::web.isInitialized) { web.stopLoading(); root.removeAllViews(); web.destroy() }; super.onDestroy() }
}
