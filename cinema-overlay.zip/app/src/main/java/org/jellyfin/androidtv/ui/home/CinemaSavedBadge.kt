package org.jellyfin.androidtv.ui.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import org.jellyfin.androidtv.R

@Composable
internal fun CinemaSavedBadge(favorite: Boolean, modifier: Modifier = Modifier) {
    Image(painterResource(if (favorite) R.drawable.cinema_favorite_on else R.drawable.cinema_watched_on),
        if (favorite) "В избранном" else "Просмотрено", modifier.size(30.dp))
}
