package org.jellyfin.androidtv.ui.home

import android.app.Activity
import android.app.Application
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.leanback.widget.BaseGridView
import androidx.leanback.widget.HorizontalGridView
import androidx.leanback.widget.VerticalGridView
import androidx.recyclerview.widget.RecyclerView
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf
import org.robolectric.annotation.Config
import org.robolectric.annotation.LooperMode
import java.time.Duration

/** Exercises the production dispatch path with actual Leanback views, not a navigation model. */
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [28], application = Application::class)
@LooperMode(LooperMode.Mode.PAUSED)
class CinemaNativeNavigationTest {
    private val mountedGrids = mutableMapOf<Activity, BaseGridView>()

    private fun mount(vertical: Boolean, count: Int): Pair<Activity, BaseGridView> {
        val activity = Robolectric.buildActivity(Activity::class.java).setup().visible().get()
        val root = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        root.addView(Button(activity).apply { text = "Header" }, LinearLayout.LayoutParams(-1, 60))
        val grid: BaseGridView = if (vertical) VerticalGridView(activity).apply { setNumColumns(4) }
            else HorizontalGridView(activity).apply { setNumRows(1) }
        grid.setFocusScrollStrategy(BaseGridView.FOCUS_SCROLL_ALIGNED)
        grid.setPadding(20, 20, 20, 20)
        grid.setVerticalSpacing(16); grid.setHorizontalSpacing(16)
        grid.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun getItemCount() = count
            override fun onCreateViewHolder(parent: ViewGroup, type: Int): RecyclerView.ViewHolder = object : RecyclerView.ViewHolder(TextView(parent.context).apply {
                isFocusable = true; isFocusableInTouchMode = true
                layoutParams = ViewGroup.LayoutParams(150, 100)
            }) {}
            override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) { (holder.itemView as TextView).text = "Card $position" }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 300))
        root.addView(Button(activity).apply { text = "Footer" }, LinearLayout.LayoutParams(-1, 60))
        activity.setContentView(root)
        activity.window.decorView.dispatchWindowFocusChanged(true)
        root.measure(View.MeasureSpec.makeMeasureSpec(800, View.MeasureSpec.EXACTLY), View.MeasureSpec.makeMeasureSpec(500, View.MeasureSpec.EXACTLY))
        root.layout(0, 0, 800, 500)
        settle()
        grid.focusCinemaItem(0)
        settle()
        mountedGrids[activity] = grid
        return activity to grid
    }

    private fun settle(ms: Long = 500) { shadowOf(Looper.getMainLooper()).idleFor(Duration.ofMillis(ms)) }
    private fun position(grid: BaseGridView): Int = grid.findFocus()?.let { grid.findContainingViewHolder(it)?.bindingAdapterPosition } ?: -1
    private fun sendKey(activity: Activity, key: Int, repeat: Int = 0, action: Int = KeyEvent.ACTION_DOWN) {
        val focused = mountedGrids.getValue(activity).findFocus() ?: error("Remote focus was lost")
        assertTrue("Native grid must consume its arrows before Compose", focused.dispatchCinemaGridKey(KeyEvent(0, SystemClock.uptimeMillis(), action, key, repeat)))
    }
    private fun press(activity: Activity, key: Int) {
        sendKey(activity, key); sendKey(activity, key, action = KeyEvent.ACTION_UP); settle()
    }
    private fun assertVisibleFocus(grid: BaseGridView) {
        val focused = grid.findFocus() ?: error("Grid has no focused card")
        val item = grid.findContainingViewHolder(focused)?.itemView ?: error("Focus isn't on a card")
        assertTrue("Focus must remain in the visible viewport", item.right > grid.paddingLeft && item.left < grid.width - grid.paddingRight && item.bottom > grid.paddingTop && item.top < grid.height - grid.paddingBottom)
    }

    @Test fun holdAndReleaseKeepsAVisibleFocusedCard() {
        val (activity, grid) = mount(false, 60)
        grid.installCinemaShelfKeys({}, {})
        assertEquals(0, position(grid))
        repeat(35) { sendKey(activity, KeyEvent.KEYCODE_DPAD_RIGHT, it); settle(35) }
        sendKey(activity, KeyEvent.KEYCODE_DPAD_RIGHT, action = KeyEvent.ACTION_UP); settle(2500)
        assertTrue("A hold must scroll beyond the initial viewport", position(grid) > 5)
        assertVisibleFocus(grid)
        val stopped = position(grid); settle(2000)
        assertEquals("No stale holder task should steal focus after release", stopped, position(grid))
        repeat(15) { sendKey(activity, KeyEvent.KEYCODE_DPAD_LEFT, it); settle(35) }
        sendKey(activity, KeyEvent.KEYCODE_DPAD_LEFT, action = KeyEvent.ACTION_UP); settle(2500)
        assertTrue(position(grid) < stopped); assertVisibleFocus(grid)
        activity.finish()
    }

    @Test fun gridMovesOneCardAndOneRowAndClampsAtTheEnd() {
        val (activity, grid) = mount(true, 24)
        var top = 0; var bottom = 0
        grid.installCinemaGridKeys(4, { top++ }, { bottom++ })
        press(activity, KeyEvent.KEYCODE_DPAD_RIGHT); assertEquals(1, position(grid))
        press(activity, KeyEvent.KEYCODE_DPAD_DOWN); assertEquals(5, position(grid))
        press(activity, KeyEvent.KEYCODE_DPAD_UP); assertEquals(1, position(grid))
        press(activity, KeyEvent.KEYCODE_DPAD_UP); assertEquals(1, top); assertEquals(1, position(grid))
        grid.focusCinemaItem(23); settle()
        repeat(8) { sendKey(activity, KeyEvent.KEYCODE_DPAD_DOWN, it) }; settle()
        assertEquals(1, bottom); assertEquals(23, position(grid)); assertVisibleFocus(grid)
        press(activity, KeyEvent.KEYCODE_DPAD_RIGHT); assertEquals(23, position(grid))
        activity.finish()
    }

    @Test fun restoringARowDoesNotLeaveFocusOnItsContainer() {
        val (activity, grid) = mount(false, 45)
        grid.installCinemaShelfKeys({}, {})
        grid.focusCinemaItem(30); settle()
        assertEquals(30, position(grid)); assertVisibleFocus(grid)
        press(activity, KeyEvent.KEYCODE_DPAD_RIGHT)
        assertEquals(31, position(grid)); assertVisibleFocus(grid)
        activity.finish()
    }
}
