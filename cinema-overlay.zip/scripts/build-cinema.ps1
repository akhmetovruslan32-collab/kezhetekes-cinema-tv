#requires -Version 7.0
param(
    [ValidateSet('Debug', 'Release')][string]$Variant = 'Debug',
    [string]$JavaHome = $env:JAVA_HOME,
    [string]$AndroidHome = $env:ANDROID_HOME
)
$ErrorActionPreference = 'Stop'
$taskProject = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (-not $JavaHome -or -not (Test-Path -LiteralPath (Join-Path $JavaHome 'bin/java.exe'))) {
    throw 'Set JAVA_HOME to a JDK 21 installation, or pass -JavaHome.'
}
if (-not $AndroidHome -or -not (Test-Path -LiteralPath (Join-Path $AndroidHome 'platforms/android-36/android.jar'))) {
    throw 'Set ANDROID_HOME to an Android SDK with platform 36, or pass -AndroidHome.'
}
$env:JAVA_HOME = $JavaHome
$env:ANDROID_HOME = $AndroidHome
$env:ANDROID_SDK_ROOT = $AndroidHome
$taskLocal = Join-Path $taskProject 'local'
New-Item -ItemType Directory -Force -Path $taskLocal | Out-Null
$env:GRADLE_USER_HOME = Join-Path $taskLocal 'gradle'
$env:ANDROID_USER_HOME = Join-Path $taskLocal 'android-user'
$taskSigningPath = Join-Path $taskLocal 'signing.json'
$taskKeyPath = Join-Path $taskLocal 'cinema-release.p12'
$taskSigningEnvNames = @('KEYSTORE_FILE', 'KEYSTORE_PASSWORD', 'SIGNING_KEY_ALIAS', 'SIGNING_KEY_PASSWORD')
$taskPreviousSigningEnv = @{}
foreach ($taskName in $taskSigningEnvNames) {
    $taskPreviousSigningEnv[$taskName] = [Environment]::GetEnvironmentVariable($taskName, 'Process')
}
Push-Location $taskProject
try {
    if ($Variant -eq 'Release') {
        if (-not (Test-Path -LiteralPath $taskSigningPath)) {
            if (Test-Path -LiteralPath $taskKeyPath) { throw 'A signing key exists without its config. Restore signing.json; do not replace the key.' }
            $taskPassword = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
            $env:KEYSTORE_PASSWORD = $taskPassword
            $env:SIGNING_KEY_PASSWORD = $taskPassword
            & (Join-Path $JavaHome 'bin/keytool.exe') -genkeypair -storetype PKCS12 -keystore $taskKeyPath -alias cinema -keyalg RSA -keysize 3072 -validity 10000 -storepass:env KEYSTORE_PASSWORD -keypass:env SIGNING_KEY_PASSWORD -dname 'CN=Kezhetekes Cinema'
            if ($LASTEXITCODE -ne 0) { throw 'Signing key creation failed.' }
            @{ password = $taskPassword; alias = 'cinema' } | ConvertTo-Json | Set-Content -LiteralPath $taskSigningPath -Encoding utf8
        }
        if (-not (Test-Path -LiteralPath $taskKeyPath)) { throw 'The signing config exists, but its key is missing. Restore the key.' }
        $taskSigning = Get-Content -LiteralPath $taskSigningPath -Raw | ConvertFrom-Json
        $env:KEYSTORE_FILE = $taskKeyPath
        $env:KEYSTORE_PASSWORD = $taskSigning.password
        $env:SIGNING_KEY_PASSWORD = $taskSigning.password
        $env:SIGNING_KEY_ALIAS = $taskSigning.alias
        Write-Host 'Keep local/cinema-release.p12 and local/signing.json together in a private backup for future updates.'
    }
    & ./gradlew.bat "assemble$Variant" --no-daemon --console=plain
    if ($LASTEXITCODE -ne 0) { throw 'Build failed. No verified APK was produced.' }
    Get-ChildItem -Path (Join-Path $taskProject "app/build/outputs/apk/$($Variant.ToLowerInvariant())") -Filter '*.apk' | Select-Object FullName, Length
} finally {
    foreach ($taskName in $taskSigningEnvNames) {
        [Environment]::SetEnvironmentVariable($taskName, $taskPreviousSigningEnv[$taskName], 'Process')
    }
    Pop-Location
}
