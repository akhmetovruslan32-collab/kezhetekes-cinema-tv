#requires -Version 7.0
param(
    [Parameter(Mandatory)][string]$InputApk,
    [Parameter(Mandatory)][string]$OutputApk,
    [Parameter(Mandatory)][string]$JavaHome,
    [Parameter(Mandatory)][string]$AndroidHome
)
$ErrorActionPreference = 'Stop'
if (-not (Test-Path -LiteralPath $InputApk)) { throw 'Input APK is missing.' }
$signProject = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$signLocal = Join-Path $signProject 'local'
New-Item -ItemType Directory -Force -Path $signLocal | Out-Null
$signConfigPath = Join-Path $signLocal 'signing.json'
$signKeyPath = Join-Path $signLocal 'cinema-release.p12'
$signJar = Join-Path $AndroidHome 'build-tools/36.0.0/lib/apksigner.jar'
$previousPassword = [Environment]::GetEnvironmentVariable('CINEMA_SIGN_PASSWORD', 'Process')
try {
    if (-not (Test-Path -LiteralPath $signConfigPath)) {
        if (Test-Path -LiteralPath $signKeyPath) { throw 'Existing signing key has no config. Restore signing.json.' }
        $signPassword = [Convert]::ToHexString([Security.Cryptography.RandomNumberGenerator]::GetBytes(32))
        $env:CINEMA_SIGN_PASSWORD = $signPassword
        & (Join-Path $JavaHome 'bin/keytool.exe') -genkeypair -storetype PKCS12 -keystore $signKeyPath -alias cinema -keyalg RSA -keysize 3072 -validity 10000 -storepass:env CINEMA_SIGN_PASSWORD -keypass:env CINEMA_SIGN_PASSWORD -dname 'CN=Kezhetekes Cinema'
        if ($LASTEXITCODE -ne 0) { throw 'Signing key creation failed.' }
        @{ password = $signPassword; alias = 'cinema' } | ConvertTo-Json | Set-Content -LiteralPath $signConfigPath -Encoding utf8
    }
    if (-not (Test-Path -LiteralPath $signKeyPath)) { throw 'Signing key is missing. Restore it before signing.' }
    $signConfig = Get-Content -LiteralPath $signConfigPath -Raw | ConvertFrom-Json
    $env:CINEMA_SIGN_PASSWORD = $signConfig.password
    & (Join-Path $AndroidHome 'build-tools/36.0.0/zipalign.exe') -c -P 16 4 $InputApk
    if ($LASTEXITCODE -ne 0) { throw 'APK alignment verification failed.' }
    & (Join-Path $JavaHome 'bin/java.exe') -jar $signJar sign --ks $signKeyPath --ks-key-alias $signConfig.alias --ks-pass env:CINEMA_SIGN_PASSWORD --key-pass env:CINEMA_SIGN_PASSWORD --out $OutputApk $InputApk
    if ($LASTEXITCODE -ne 0) { throw 'APK signing failed.' }
    & (Join-Path $JavaHome 'bin/java.exe') -jar $signJar verify --verbose --print-certs $OutputApk
    if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
    (Get-FileHash -LiteralPath $OutputApk -Algorithm SHA256).Hash | Set-Content -LiteralPath ($OutputApk + '.sha256') -Encoding ascii
    Write-Host 'APK signed and verified. Keep local/cinema-release.p12 and local/signing.json privately for future updates.'
} finally {
    [Environment]::SetEnvironmentVariable('CINEMA_SIGN_PASSWORD', $previousPassword, 'Process')
}
